package httpresponse

import (
	"KirrhoAccounting/pkg/messages"
	"encoding/json"
	"errors"
	"net/http"
	"strings"

	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/proto"
)

const (
	contentTypeHeader   = "Content-Type"
	jsonContentType     = "application/json"
	protobufContentType = "application/x-protobuf"
	errMarshalProto     = "failed to marshal protobuf"
)

func WriteSuccess(w http.ResponseWriter, message messages.SuccessMessage, data interface{}, statusCode int) {
	w.Header().Set(contentTypeHeader, jsonContentType)
	w.WriteHeader(statusCode)

	resp := Response{
		IsSuccess: true,
		Message:   string(message),
		Data:      data,
	}

	if msg, ok := data.(proto.Message); ok {
		mo := protojson.MarshalOptions{
			EmitUnpopulated: true,
			UseProtoNames:   true,
			Indent:          "",
		}
		b, err := mo.Marshal(msg)
		if err == nil {
			_ = json.NewEncoder(w).Encode(Response{
				IsSuccess: resp.IsSuccess,
				Message:   resp.Message,
				Data:      json.RawMessage(b),
			})
			return
		}
	}

	enc := json.NewEncoder(w)
	enc.SetEscapeHTML(false)
	_ = enc.Encode(resp)
}

func WriteServiceError(w http.ResponseWriter, err error) {
	switch {
	case errors.Is(err, messages.NoDataFound), strings.Contains(err.Error(), messages.NoDataFound.Error()):
		WriteError(w, messages.NoDataFound, http.StatusNotFound)
	default:
		WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
	}
}

func WriteProtoBinary(w http.ResponseWriter, data proto.Message, statusCode int) {
	w.Header().Set(contentTypeHeader, protobufContentType)
	w.WriteHeader(statusCode)

	b, err := proto.Marshal(data)
	if err != nil {
		WriteError(w, errMarshalProto, http.StatusInternalServerError)
		return
	}
	_, _ = w.Write(b)
}

func WriteError(w http.ResponseWriter, message messages.ErrorMessage, statusCode int) {
	w.Header().Set(contentTypeHeader, jsonContentType)
	w.WriteHeader(statusCode)
	resp := Response{
		IsSuccess: false,
		Message:   string(message),
	}
	_ = json.NewEncoder(w).Encode(resp)
}
