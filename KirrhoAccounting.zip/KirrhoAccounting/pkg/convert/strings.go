package convert

import (
	"database/sql"
	"fmt"
)

func DerefString(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}

func WrapString(s string) *string {
	if s == "" {
		return nil
	}
	return &s
}

func SafeString(v interface{}) string {
	if v == nil {
		return ""
	}
	switch t := v.(type) {
	case string:
		return t
	case []byte:
		return string(t)
	case *string:
		if t == nil {
			return ""
		}
		return *t
	case sql.NullString:
		if t.Valid {
			return t.String
		}
		return ""
	default:
		return fmt.Sprintf("%v", t)
	}
}

func SafePtrString(value interface{}) *string {
	if value == nil {
		return nil
	}

	switch v := value.(type) {
	case *string:
		return v
	case string:
		if v == "" {
			return nil
		}
		return &v
	case []byte:
		s := string(v)
		if s == "" {
			return nil
		}
		return &s
	case sql.NullString:
		if v.Valid {
			return &v.String
		}
		return nil
	default:
		s := SafeString(v)
		if s == "" || s == "<nil>" {
			return nil
		}
		return &s
	}
}

func SafeOptionalString(v interface{}) *string {
	if v == nil {
		return nil
	}
	str := fmt.Sprintf("%v", v)
	if str == "" {
		return nil
	}
	return &str
}
