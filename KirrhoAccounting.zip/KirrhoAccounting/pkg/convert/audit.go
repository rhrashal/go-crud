package convert

import (
	"KirrhoAccounting/pkg/basemodel"
	"time"

	"google.golang.org/protobuf/types/known/timestamppb"
)

func ProtoToAudit(createdAt, updatedAt *timestamppb.Timestamp, createdBy, updatedBy string) basemodel.AuditFields {
	return basemodel.AuditFields{
		CreatedAt: createdAt.AsTime(),
		UpdatedAt: updatedAt.AsTime(),
		CreatedBy: createdBy,
		UpdatedBy: updatedBy,
	}
}

func AuditToProto(a basemodel.AuditFields) (createdAt, updatedAt *timestamppb.Timestamp, createdBy, updatedBy string) {
	return timestamppb.New(a.CreatedAt), timestamppb.New(a.UpdatedAt), a.CreatedBy, a.UpdatedBy
}

func NowAudit(user string) basemodel.AuditFields {
	now := time.Now().UTC()
	return basemodel.AuditFields{
		CreatedAt: now,
		UpdatedAt: now,
		CreatedBy: user,
		UpdatedBy: user,
	}
}
