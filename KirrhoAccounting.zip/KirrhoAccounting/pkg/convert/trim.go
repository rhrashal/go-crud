package convert

import "strings"

func TrimWhiteSpace(s string) *string {
	v := strings.TrimSpace(s)
	if v == "" {
		return nil
	}
	return &v
}

func NormalizeStringPtr(p *string) *string {
	if p == nil {
		return nil
	}

	v := strings.TrimSpace(*p)
	if v == "" {
		return nil
	}
	return &v
}

func NormalizeString(s string) *string {
	return NormalizeStringPtr(&s)
}
