package convert

import (
	"encoding/json"
	"net/http"
)

func ParseRequest[T any](r *http.Request) (*T, error) {
	var input T

	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()

	if err := decoder.Decode(&input); err != nil {
		return nil, err
	}

	if n, ok := any(&input).(Normalizer); ok {
		n.Normalize()
	}

	if v, ok := any(&input).(Validator); ok {
		if err := v.Validate(); err != nil {
			return nil, err
		}
	}

	return &input, nil
}

func ParseUpdateRequest[T any](r *http.Request) (map[string]interface{}, error) {
	var model T

	if err := json.NewDecoder(r.Body).Decode(&model); err != nil {
		return nil, err
	}

	// Normalize if implemented
	if n, ok := any(&model).(Normalizer); ok {
		n.Normalize()
	}

	// Validate if implemented
	if v, ok := any(&model).(Validator); ok {
		if err := v.Validate(); err != nil {
			return nil, err
		}
	}

	updates := make(map[string]interface{})
	updates, _ = StructToMap(&model)
	return updates, nil
}

func StructToMap(v any) (map[string]interface{}, error) {
	b, err := json.Marshal(v)
	if err != nil {
		return nil, err
	}

	var m map[string]interface{}
	err = json.Unmarshal(b, &m)
	return m, err
}
