package convert

type Normalizer interface {
	Normalize()
}
type Validator interface {
	Validate() error
}
