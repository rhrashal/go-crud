package convert

import "time"

func SafeFormatTime(v interface{}) string {
	if v == nil {
		return ""
	}

	t, ok := v.(time.Time)
	if !ok || t.IsZero() {
		return ""
	}

	return t.Format(time.RFC3339)
}

func SafeFormatAnyTime(v interface{}) time.Time {
	switch t := v.(type) {
	case time.Time:
		if t.IsZero() {
			return time.Time{}
		}
		return t

	case *time.Time:
		if t == nil || t.IsZero() {
			return time.Time{}
		}
		return *t

	case string:
		// Attempt to parse common time formats
		if parsed, err := time.Parse(time.RFC3339, t); err == nil {
			return parsed
		}
		if parsed, err := time.Parse("2006-01-02 15:04:05", t); err == nil {
			return parsed
		}
		return time.Time{}

	default:
		return time.Time{}
	}
}
