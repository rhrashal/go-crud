package convert

import (
	"reflect"
	"time"
)

func MapRow[T any](row map[string]interface{}) *T {
	var entity T
	v := reflect.ValueOf(&entity).Elem()
	t := v.Type()

	mapStructFields(v, t, row)

	return &entity
}

func mapStructFields(v reflect.Value, t reflect.Type, row map[string]interface{}) {
	for i := 0; i < v.NumField(); i++ {
		field := v.Field(i)
		fieldType := t.Field(i)

		// Handle embedded structs (AuditFields)
		if field.Kind() == reflect.Struct && fieldType.Anonymous {
			mapStructFields(field, field.Type(), row)
			continue
		}

		dbTag := fieldType.Tag.Get("db")
		if dbTag == "" {
			continue
		}

		val, ok := row[dbTag]
		if !ok || val == nil {
			continue
		}

		setFieldValue(field, val)
	}
}

func setFieldValue(field reflect.Value, val interface{}) {
	if !field.CanSet() || val == nil {
		return
	}

	fieldType := field.Type()

	// ===== HANDLE POINTER TYPES =====
	if field.Kind() == reflect.Ptr {
		elemType := fieldType.Elem()
		elemValue := reflect.New(elemType).Elem()

		setFieldValue(elemValue, val)
		field.Set(elemValue.Addr())
		return
	}

	switch field.Kind() {

	case reflect.String:
		field.SetString(SafeString(val))

	case reflect.Int:
		field.SetInt(SafeInt64(val))

	case reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		field.SetInt(SafeInt64(val))

	case reflect.Bool:
		field.SetBool(SafeBool(val))

	case reflect.Struct:
		// time.Time
		if fieldType == reflect.TypeOf(time.Time{}) {
			field.Set(reflect.ValueOf(SafeFormatAnyTime(val)))
		}
	}
}
