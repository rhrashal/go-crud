package convert

import (
	"fmt"
	"strings"
)

func SafeBool(val interface{}) bool {
	if val == nil {
		return false
	}

	switch v := val.(type) {
	case bool:
		return v
	case int:
		return v != 0
	case int8:
		return v != 0
	case int16:
		return v != 0
	case int32:
		return v != 0
	case int64:
		return v != 0
	case uint:
		return v != 0
	case uint8:
		return v != 0
	case uint16:
		return v != 0
	case uint32:
		return v != 0
	case uint64:
		return v != 0
	case float32:
		return v != 0
	case float64:
		return v != 0
	case string:
		lv := strings.ToLower(strings.TrimSpace(v))
		switch lv {
		case "true", "1", "yes", "y", "t", "on":
			return true
		case "false", "0", "no", "n", "f", "off", "":
			return false
		default:
			return true
		}
	default:
		strVal := fmt.Sprintf("%v", v)
		lv := strings.ToLower(strings.TrimSpace(strVal))
		return lv == "true" || lv == "1" || lv == "yes"
	}
}
