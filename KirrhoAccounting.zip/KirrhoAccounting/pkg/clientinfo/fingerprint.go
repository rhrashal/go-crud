package clientinfo

import (
	"net"
	"net/http"

	"github.com/mssola/user_agent"
)

type BrowserFingerprint struct {
	UserIP   string `json:"user_ip"`
	Browser  string `json:"browser"`
	Platform string `json:"platform"`
}

func GetBrowserFingerprint(r *http.Request) BrowserFingerprint {
	ip := r.Header.Get("X-Forwarded-For")
	if ip == "" {
		ip, _, _ = net.SplitHostPort(r.RemoteAddr)
	}

	ua := user_agent.New(r.UserAgent())
	browser, _ := ua.Browser()
	platform := ua.OS()

	return BrowserFingerprint{
		UserIP:   ip,
		Browser:  browser,
		Platform: platform,
	}
}
