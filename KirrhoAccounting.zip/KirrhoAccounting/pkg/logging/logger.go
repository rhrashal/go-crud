package logging

import (
	"log"
	"net/http"
	"time"
)

func LogSensitiveOperation(r *http.Request, operation string) {
	username := r.Header.Get("X-Username")

	if username == "" {
		username = "unknown"
	}

	log.Printf(
		"User: %s performed operation: %s at %s",
		username,
		operation,
		time.Now().Format(time.RFC3339),
	)
}
