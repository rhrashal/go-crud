package persistence

import (
	"KirrhoAccounting/pkg/httpresponse"
	"database/sql"
	"fmt"
	"strings"
	"time"
)

func DebugQuery(query string, args ...interface{}) string {
	var b strings.Builder
	argIndex := 0

	for _, ch := range query {
		if ch == '?' && argIndex < len(args) {
			switch v := args[argIndex].(type) {
			case string:
				b.WriteString(fmt.Sprintf("'%s'", v))
			case time.Time:
				b.WriteString(fmt.Sprintf("'%s'", v.Format(time.RFC3339)))
			case nil:
				b.WriteString("NULL")
			default:
				b.WriteString(fmt.Sprintf("%v", v))
			}
			argIndex++
		} else {
			b.WriteRune(ch)
		}
	}
	return b.String()
}

func fail(msg string) httpresponse.Response {
	return httpresponse.Response{
		IsSuccess: false,
		Message:   msg,
	}
}

func closeRows(rows *sql.Rows) {
	if err := rows.Close(); err != nil {
		fmt.Printf("failed to close rows: %v\n", err)
	}
}

func scanRows(rows *sql.Rows, columns []string) ([]map[string]interface{}, error) {
	var results []map[string]interface{}

	for rows.Next() {
		values := make([]interface{}, len(columns))
		for i := range values {
			values[i] = new(sql.RawBytes)
		}

		if err := rows.Scan(values...); err != nil {
			return nil, err
		}

		rowMap := make(map[string]interface{}, len(columns))
		for i, col := range columns {
			raw := *(values[i].(*sql.RawBytes))
			if raw == nil {
				rowMap[col] = nil
			} else {
				rowMap[col] = string(raw)
			}
		}
		results = append(results, rowMap)
	}

	if err := rows.Err(); err != nil {
		return nil, err
	}

	return results, nil
}
