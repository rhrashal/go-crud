package persistence

import (
	"KirrhoAccounting/pkg/httpresponse"
	"database/sql"
	"fmt"
)

type SqlHelper struct {
	db *sql.DB
}

func NewSqlHelper(db *sql.DB) *SqlHelper {
	return &SqlHelper{db: db}
}

func (h *SqlHelper) Execute(query string, args ...interface{}) httpresponse.Response {
	if _, err := h.db.Exec(query, args...); err != nil {
		return httpresponse.Response{
			IsSuccess: false,
			Message:   fmt.Sprintf("SQL Execute failed: %v | Query: %s", err, DebugQuery(query, args...)),
		}
	}
	return httpresponse.Response{IsSuccess: true, Message: "execution successful"}
}

func (h *SqlHelper) Insert(query string, args ...interface{}) httpresponse.Response {
	res, err := h.db.Exec(query, args...)
	if err != nil {
		return httpresponse.Response{
			IsSuccess: false,
			Message:   fmt.Sprintf("SQL Insert failed: %v | Query: %s", err, DebugQuery(query, args...)),
		}
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return httpresponse.Response{
			IsSuccess: false,
			Message:   fmt.Sprintf("Insert failed: could not fetch rows affected: %v", err),
		}
	}

	if rows != 1 {
		return httpresponse.Response{
			IsSuccess: false,
			Message:   fmt.Sprintf("Insert expected 1 row, got %d | Query: %s", rows, DebugQuery(query, args...)),
		}
	}

	return httpresponse.Response{IsSuccess: true, Message: "insert successful"}
}

func (h *SqlHelper) BulkInsert(baseQuery string, args [][]interface{}) httpresponse.Response {
	tx, err := h.db.Begin()
	if err != nil {
		return httpresponse.Response{
			IsSuccess: false,
			Message:   fmt.Sprintf("transaction begin failed: %v", err),
		}
	}
	defer func(tx *sql.Tx) {
		err := tx.Rollback()
		if err != nil {
			fmt.Printf("rollback failed: %v\n", err)
		}
	}(tx)

	stmt, err := tx.Prepare(baseQuery)
	if err != nil {
		return httpresponse.Response{
			IsSuccess: false,
			Message:   fmt.Sprintf("prepare failed: %v", err),
		}
	}
	defer func(stmt *sql.Stmt) {
		err := stmt.Close()
		if err != nil {
			fmt.Printf("failed to close statement: %v\n", err)
		}
	}(stmt)

	for _, params := range args {
		if _, err := stmt.Exec(params...); err != nil {
			return httpresponse.Response{
				IsSuccess: false,
				Message:   fmt.Sprintf("bulk insert failed: %v | Query: %s", err, DebugQuery(baseQuery, params...)),
			}
		}
	}

	if err := tx.Commit(); err != nil {
		return httpresponse.Response{
			IsSuccess: false,
			Message:   fmt.Sprintf("commit failed: %v", err),
		}
	}

	return httpresponse.Response{IsSuccess: true, Message: "bulk insert successful"}
}

func (h *SqlHelper) InsertWithID(query string, args ...interface{}) httpresponse.Response {
	var id int64
	if err := h.db.QueryRow(query, args...).Scan(&id); err != nil {
		return httpresponse.Response{
			IsSuccess: false,
			Message:   fmt.Sprintf("InsertWithID failed: %v | Query: %s", err, DebugQuery(query, args...)),
		}
	}
	return httpresponse.Response{
		IsSuccess: true,
		Message:   "insert successful",
		Data:      id,
	}
}

func (h *SqlHelper) Select(query string, args ...interface{}) httpresponse.Response {
	rows, err := h.db.Query(query, args...)
	if err != nil {
		return fail(fmt.Sprintf("Select query failed: %v | Query: %s", err, DebugQuery(query, args...)))
	}
	defer closeRows(rows)

	columns, err := rows.Columns()
	if err != nil {
		return fail(fmt.Sprintf("failed to get column names: %v", err))
	}

	results, err := scanRows(rows, columns)
	if err != nil {
		return fail(fmt.Sprintf("row scan failed: %v", err))
	}

	if len(results) == 0 {
		return httpresponse.Response{
			IsSuccess: true,
			Message:   "no data found",
			Data:      []map[string]interface{}{},
		}
	}

	return httpresponse.Response{IsSuccess: true, Message: "data retrieved", Data: results}
}
