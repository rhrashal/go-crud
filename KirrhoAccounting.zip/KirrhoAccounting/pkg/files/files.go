package files

import (
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"time"
)

func SaveFile(filename string, data []byte) error {
	if err := ensureDir(filepath.Dir(filename)); err != nil {
		return err
	}
	if err := os.WriteFile(filename, data, 0644); err != nil {
		return logErr("saving file", err)
	}
	return nil
}

func SaveTextFile(filename, content string) error {
	return SaveFile(filename, []byte(content))
}

func ReadFile(filename string) ([]byte, error) {
	data, err := os.ReadFile(filename)
	if err != nil {
		return nil, logErr("reading file", err)
	}
	return data, nil
}

func ReadTextFile(filename string) (string, error) {
	data, err := ReadFile(filename)
	if err != nil {
		return "", err
	}
	return string(data), nil
}

func DeleteFile(filename string) error {
	if !Exists(filename) {
		return nil
	}
	if err := os.Remove(filename); err != nil {
		return logErr("deleting file", err)
	}
	return nil
}

func MoveFile(src, dst string) error {
	if err := ensureDir(filepath.Dir(dst)); err != nil {
		return err
	}
	if err := os.Rename(src, dst); err != nil {
		return logErr("moving file", err)
	}
	return nil
}

func CopyFile(src, dst string) error {
	source, err := os.Open(src)
	if err != nil {
		return logErr("opening source", err)
	}
	defer source.Close()

	if err := ensureDir(filepath.Dir(dst)); err != nil {
		return err
	}

	dest, err := os.Create(dst)
	if err != nil {
		return logErr("creating destination", err)
	}
	defer dest.Close()

	if _, err := io.Copy(dest, source); err != nil {
		return logErr("copying file", err)
	}

	return dest.Sync()
}

func Exists(path string) bool {
	_, err := os.Stat(path)
	return err == nil
}

func GetFileInfo(path string) (os.FileInfo, error) {
	info, err := os.Stat(path)
	if err != nil {
		return nil, logErr("getting file info", err)
	}
	return info, nil
}

func GetString(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}

func ensureDir(dir string) error {
	if dir == "" {
		return nil
	}
	return os.MkdirAll(dir, 0755)
}

func logErr(action string, err error) error {
	if err != nil {
		log.Printf("Error %s: %v", action, err)
	}
	return err
}

func SafeString(v interface{}) string {
	switch t := v.(type) {
	case string:
		return t
	case []byte:
		return string(t)
	default:
		return ""
	}
}

func SafeOptionalString(v interface{}) *string {
	if str := SafeString(v); str != "" {
		return &str
	}
	return nil
}

func SafeBool(v interface{}) bool {
	switch t := v.(type) {
	case bool:
		return t
	case string:
		return t == "true" || t == "1"
	case int, int64:
		return fmt.Sprintf("%v", t) != "0"
	case []byte:
		s := string(t)
		return s == "true" || s == "1"
	default:
		return false
	}
}

func SafeTime(v interface{}) time.Time {
	if t, ok := v.(time.Time); ok {
		return t
	}
	return time.Time{}
}
