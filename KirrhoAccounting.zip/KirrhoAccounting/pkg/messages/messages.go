package messages

type SuccessMessage string

type ErrorMessage string

func (e ErrorMessage) Error() string {
	return string(e)
}

const (
	DataCreatedSuccessful SuccessMessage = "Data created successfully."
	DataUpdatedSuccessful SuccessMessage = "Data updated successfully."
	DataRetrieved         SuccessMessage = "Data retrieved successfully."
	RequestSuccessful     SuccessMessage = "Request successful."
	DeleteSuccessful      SuccessMessage = "Data deleted successfully."
	LoginSuccessful       SuccessMessage = "Login successful."
)

var successMessageMap = map[string]SuccessMessage{
	"DATA_CREATED_SUCCESSFUL": DataCreatedSuccessful,
	"DATA_UPDATED_SUCCESSFUL": DataUpdatedSuccessful,
	"DATA_RETRIEVED":          DataRetrieved,
	"REQUEST_SUCCESSFUL":      RequestSuccessful,
	"DELETE_SUCCESSFUL":       DeleteSuccessful,
	"LOGIN_SUCCESSFUL":        LoginSuccessful,
}

const (
	NoDataFound                 ErrorMessage = "No data found!"
	DataRetrievalFailed         ErrorMessage = "Data retrieval failed."
	InsertionFailed             ErrorMessage = "Could not insert data!"
	UpdateFailed                ErrorMessage = "Could not update data!"
	DeleteFailed                ErrorMessage = "Could not delete data!"
	SaveFailed                  ErrorMessage = "Failed to save record"
	AlreadyExists               ErrorMessage = "Data already exists!"
	RequestNone                 ErrorMessage = "Request is None!"
	TokenExpired                ErrorMessage = "Token expired!"
	RefreshTokenExpired         ErrorMessage = "Refresh Token expired!"
	TokenInvalid                ErrorMessage = "Token expired!"
	TokenMissing                ErrorMessage = "Access token is missing."
	UnauthorizedToken           ErrorMessage = "Unauthorized token."
	RefreshTokenNotAllowed      ErrorMessage = "Refresh tokens are not allowed for this operation."
	PermissionDenied            ErrorMessage = "You do not have permission to access this resource."
	AuthError                   ErrorMessage = "Authentication credentials were not provided."
	RequestFailed               ErrorMessage = "Request failed!"
	InvalidCredentials          ErrorMessage = "Invalid credentials"
	InactiveUser                ErrorMessage = "Sorry, your account has been deactivated."
	ExceptionMessage            ErrorMessage = "Something went wrong! Please try again later."
	InvalidData                 ErrorMessage = "Invalid data provided."
	DatabaseError               ErrorMessage = "Database error occurred."
	GeneralError                ErrorMessage = "An error occurred."
	ErrorDateInPast             ErrorMessage = "The provided date cannot be in the past."
	ErrorSlotNotAvailable       ErrorMessage = "Appointment slot is not available."
	ErrorSameStartEndTime       ErrorMessage = "Start time and end time cannot be the same"
	ErrorInvalidStartEndTime    ErrorMessage = "Invalid start_time or end_time format"
	ErrorStartTimeBeforeEndTime ErrorMessage = "Start time must be before end time"
	JWTTokenSecretKey           ErrorMessage = "Kirrhosoft"
)

var errorMessageMap = map[string]ErrorMessage{
	"NO_DATA_FOUND":                    NoDataFound,
	"DATA_RETRIEVAL_FAILED":            DataRetrievalFailed,
	"INSERTION_FAILED":                 InsertionFailed,
	"UPDATE_FAILED":                    UpdateFailed,
	"DELETE_FAILED":                    DeleteFailed,
	"SAVE_FAILED":                      SaveFailed,
	"ALREADY_EXISTS":                   AlreadyExists,
	"REQUEST_NONE":                     RequestNone,
	"TOKEN_EXPIRED":                    TokenExpired,
	"REFRESH_TOKEN_EXPIRED":            RefreshTokenExpired,
	"TOKEN_INVALID":                    TokenInvalid,
	"TOKEN_MISSING":                    TokenMissing,
	"UNAUTHORIZED_TOKEN":               UnauthorizedToken,
	"REFRESH_TOKEN_NOT_ALLOWED":        RefreshTokenNotAllowed,
	"PERMISSION_DENIED":                PermissionDenied,
	"AUTH_ERROR":                       AuthError,
	"REQUEST_FAILED":                   RequestFailed,
	"INVALID_CREDENTIALS":              InvalidCredentials,
	"INACTIVE_USER":                    InactiveUser,
	"EXCEPTION_MESSAGE":                ExceptionMessage,
	"INVALID_DATA":                     InvalidData,
	"DATABASE_ERROR":                   DatabaseError,
	"GENERAL_ERROR":                    GeneralError,
	"ERROR_DATE_IN_PAST":               ErrorDateInPast,
	"ERROR_SLOT_NOT_AVAILABLE":         ErrorSlotNotAvailable,
	"ERROR_SAME_START_END_TIME":        ErrorSameStartEndTime,
	"ERROR_INVALID_START_END_TIME":     ErrorInvalidStartEndTime,
	"ERROR_START_TIME_BEFORE_END_TIME": ErrorStartTimeBeforeEndTime,
	"JWT_TOKEN_SECRET_KEY":             JWTTokenSecretKey,
}
