package main

import (
	"KirrhoAccounting/kirrhosoft/di"
	healthpb "KirrhoAccounting/kirrhosoft/pb/healthcheck"
	planspb "KirrhoAccounting/kirrhosoft/pb/plans"
	superuserpb "KirrhoAccounting/kirrhosoft/pb/superuser"
	"context"
	"log"
	"net"
	"os"
	"os/signal"
	"syscall"

	"google.golang.org/grpc"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/peer"
)

func loggingInterceptor(
	ctx context.Context,
	req interface{},
	info *grpc.UnaryServerInfo,
	handler grpc.UnaryHandler,
) (interface{}, error) {
	p, _ := peer.FromContext(ctx)
	md, _ := metadata.FromIncomingContext(ctx)

	clientAddr := "unknown"
	if p != nil {
		clientAddr = p.Addr.String()
	}

	log.Printf("[gRPC] Method=%s | From=%s | Metadata=%v", info.FullMethod, clientAddr, md)
	return handler(ctx, req)
}

func main() {
	container, err := di.InitContainer()
	if err != nil {
		log.Fatalf("Failed to initialize container: %v", err)
	}

	port := os.Getenv("GRPC_PORT")
	if port == "" {
		port = "50051"
	}

	lis, err := net.Listen("tcp", ":"+port)
	if err != nil {
		log.Fatalf("Failed to listen on gRPC port %s: %v", port, err)
	}

	server := grpc.NewServer(
		grpc.ChainUnaryInterceptor(loggingInterceptor),
	)

	superuserpb.RegisterSuperUserServiceServer(server, container.SuperuserGRPCServer)
	planspb.RegisterPlanServiceServer(server, container.PlansGRPCServer)
	healthpb.RegisterSystemHealthServer(server, container.HealthGRPCServer)

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	go func() {
		log.Printf("gRPC server running on port %s", port)
		if err := server.Serve(lis); err != nil {
			log.Fatalf("Failed to serve gRPC: %v", err)
		}
	}()

	<-ctx.Done()
	log.Println("Shutting down gRPC server...")
	server.GracefulStop()
}
