package main

import (
	accDi "KirrhoAccounting/accounting/api/di"
	accRoute "KirrhoAccounting/accounting/api/routes"
	"KirrhoAccounting/accounting/pkg/logger"
	middleware "KirrhoAccounting/kirrhosoft/middlewares"
	ksRoute "KirrhoAccounting/kirrhosoft/routes"
	"path/filepath"

	"log"
	"net/http"
	"os"

	"github.com/gorilla/mux"

	ksDi "KirrhoAccounting/kirrhosoft/di"
)

func loggingMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		//log.Printf("HTTP %s %s", r.Method, r.RequestURI)
		logger.Info.Println("HTTP  " + r.Method + "  " + r.RequestURI)
		next.ServeHTTP(w, r)
	})
}

func main() {
	logger.Init()
	logger.Info.Println("Starting server...")

	logger.Debug.Println("Starting server...")
	logger.Warn.Println("Starting server...")
	logger.Error.Println("Starting server...")

	container, err := ksDi.InitContainer()
	if err != nil {
		logger.Error.Println("Failed to initialize accounting container: " + err.Error())
		log.Fatalf("Failed to initialize container: %v", err)
	}

	accContainer, err := accDi.InitContainer()
	if err != nil {
		logger.Error.Println("Failed to initialize kirrhosoft container: " + err.Error())
		log.Fatalf("Failed to initialize container: %v", err)
	}

	port := os.Getenv("HTTP_PORT")
	if port == "" {
		port = "8000"
	}

	r := mux.NewRouter()
	r.Use(loggingMiddleware)
	r.Use(middleware.TenantResolver)

	accRoute.RegisterAllRoutes(r, accContainer)
	ksRoute.RegisterAllKirrhosoftRoutes(r, container)

	mediaDir := filepath.Join(".", "kirrhosoft", "media")
	fs := http.FileServer(http.Dir(mediaDir))
	r.PathPrefix("/media/").Handler(http.StripPrefix("/media/", fs))

	logger.Info.Println("HTTP server running on port " + port)
	log.Printf("HTTP server running on 0.0.0.0:%s", port)

	if err := http.ListenAndServe("0.0.0.0:"+port, r); err != nil {
		log.Fatalf("Failed to serve HTTP: %v", err)
	}
}
