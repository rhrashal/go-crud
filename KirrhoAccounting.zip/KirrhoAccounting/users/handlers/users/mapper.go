package users

import (
	"KirrhoAccounting/pkg/basemodel"
	"KirrhoAccounting/pkg/convert"
	"KirrhoAccounting/pkg/files"
	core "KirrhoAccounting/users/models/users"
	"time"
)

func DerefString(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}

func WrapString(s string) *string {
	if s == "" {
		return nil
	}
	return &s
}

func MapRowToUser(row map[string]interface{}) *core.Users {
	lastLogin := files.SafeTime(row["last_login"])
	return &core.Users{
		ID:             convert.SafeInt64(row["id"]),
		Email:          files.SafeString(row["email"]),
		PasswordHash:   files.SafeString(row["password_hash"]),
		FullName:       files.SafeOptionalString(row["full_name"]),
		Role:           files.SafeString(row["role"]),
		IsActive:       files.SafeBool(row["is_active"]),
		LastLogin:      &lastLogin,
		ProfilePicture: files.SafeOptionalString(row["profile_picture"]),
		AuditFields: basemodel.AuditFields{
			CreatedAt: files.SafeTime(row["created_at"]),
			UpdatedAt: files.SafeTime(row["updated_at"]),
			CreatedBy: files.SafeString(row["created_by"]),
			UpdatedBy: files.SafeString(row["updated_by"]),
		},
	}
}

func MapUserResponse(u *core.Users) map[string]interface{} {
	createdAt, updatedAt, createdBy, updatedBy := convert.AuditToProto(u.AuditFields)

	var lastLogin string
	if u.LastLogin != nil {
		lastLogin = u.LastLogin.Format(time.RFC3339)
	}

	return map[string]interface{}{
		"id":              u.ID,
		"email":           u.Email,
		"full_name":       DerefString(u.FullName),
		"role":            u.Role,
		"is_active":       u.IsActive,
		"last_login":      lastLogin,
		"profile_picture": files.GetString(u.ProfilePicture),
		"created_at":      createdAt,
		"updated_at":      updatedAt,
		"created_by":      createdBy,
		"updated_by":      updatedBy,
	}
}

func MapUserListResponse(users []*core.Users, timeFormat string) []map[string]interface{} {
	if len(users) == 0 {
		return []map[string]interface{}{}
	}

	result := make([]map[string]interface{}, 0, len(users))
	for _, u := range users {
		result = append(result, MapUserResponse(u))
	}
	return result
}
