package users

type Role int

const (
	RoleOwner Role = iota + 1
	RoleAdmin
	RoleManager
	RoleMember
	RoleViewer
)

func EnumToRole(role Role) string {
	switch role {
	case RoleOwner:
		return "owner"
	case RoleAdmin:
		return "admin"
	case RoleManager:
		return "manager"
	case RoleMember:
		return "member"
	case RoleViewer:
		return "viewer"
	default:
		return "member"
	}
}

func RoleToEnum(role string) Role {
	switch role {
	case "owner":
		return RoleOwner
	case "admin":
		return RoleAdmin
	case "manager":
		return RoleManager
	case "member":
		return RoleMember
	case "viewer":
		return RoleViewer
	default:
		return RoleMember
	}
}

func ValidRoles() []string {
	return []string{"owner", "admin", "manager", "member", "viewer"}
}

func IsValidRole(role string) bool {
	switch role {
	case "owner", "admin", "manager", "member", "viewer":
		return true
	default:
		return false
	}
}
