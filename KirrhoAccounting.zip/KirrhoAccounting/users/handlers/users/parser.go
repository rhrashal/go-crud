package users

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"time"
)

type CreateUserInput struct {
	ID             string     `json:"id,omitempty"`
	Email          string     `json:"email"`
	PasswordHash   string     `json:"password_hash"`
	FullName       *string    `json:"full_name,omitempty"`
	Role           string     `json:"role,omitempty"`
	IsActive       *bool      `json:"is_active,omitempty"`
	LastLogin      *time.Time `json:"last_login,omitempty"`
	ProfilePicture *string    `json:"profile_picture,omitempty"`
	CreatedBy      string     `json:"created_by"`
}

func ParseCreateUserRequest(r *http.Request) (*CreateUserInput, error) {
	defer r.Body.Close()

	ct := r.Header.Get("Content-Type")
	input := &CreateUserInput{}

	if strings.HasPrefix(ct, "application/json") {
		if err := json.NewDecoder(r.Body).Decode(input); err != nil {
			return nil, errors.New("invalid JSON body")
		}
	} else {
		if err := parseFormRequest(r, input); err != nil {
			return nil, err
		}
	}

	input.Email = strings.TrimSpace(input.Email)
	input.PasswordHash = strings.TrimSpace(input.PasswordHash)
	input.CreatedBy = strings.TrimSpace(input.CreatedBy)

	if input.Email == "" {
		return nil, errors.New("email is required")
	}
	if input.PasswordHash == "" {
		return nil, errors.New("password_hash is required")
	}
	if input.CreatedBy == "" {
		return nil, errors.New("created_by is required")
	}

	if input.Role == "" {
		input.Role = "member"
	}
	if input.IsActive == nil {
		active := true
		input.IsActive = &active
	}

	return input, nil
}

func ParsePartialUpdateUserRequest(r *http.Request) (map[string]interface{}, error) {
	updates := make(map[string]interface{})

	if err := parseRequest(r, &updates); err != nil {
		return nil, err
	}

	if len(updates) == 0 {
		return nil, errors.New("no fields to update")
	}

	return updates, nil
}

func parseRequest(r *http.Request, target interface{}) error {
	ct := r.Header.Get("Content-Type")
	if strings.HasPrefix(ct, "application/json") {
		return json.NewDecoder(r.Body).Decode(target)
	}
	return parseFormRequest(r, target)
}

func parseFormRequest(r *http.Request, target interface{}) error {
	if err := r.ParseMultipartForm(10 << 20); err != nil {
		if err := r.ParseForm(); err != nil {
			return err
		}
	}

	switch t := target.(type) {
	case *CreateUserInput:
		return parseCreateUserForm(r, t)
	case *map[string]interface{}:
		return parsePartialUpdateUserForm(r, t)
	default:
		return errors.New("unsupported target type for form parsing")
	}
}

func parseCreateUserForm(r *http.Request, t *CreateUserInput) error {
	t.ID = strings.TrimSpace(r.FormValue("id"))
	t.Email = strings.TrimSpace(r.FormValue("email"))
	t.PasswordHash = strings.TrimSpace(r.FormValue("password_hash"))
	t.Role = strings.TrimSpace(r.FormValue("role"))
	t.CreatedBy = strings.TrimSpace(r.FormValue("created_by"))

	if fullName := r.FormValue("full_name"); fullName != "" {
		t.FullName = &fullName
	}
	if pic := r.FormValue("profile_picture"); pic != "" {
		t.ProfilePicture = &pic
	}
	if isActive := r.FormValue("is_active"); isActive != "" {
		val := parseBool(isActive)
		t.IsActive = &val
	}
	if lastLogin := r.FormValue("last_login"); lastLogin != "" {
		parsed, err := parseTimeRFC3339(lastLogin, "last_login")
		if err != nil {
			return err
		}
		t.LastLogin = &parsed
	}
	return nil
}

func parsePartialUpdateUserForm(r *http.Request, t *map[string]interface{}) error {
	if r.MultipartForm == nil {
		if err := r.ParseMultipartForm(10 << 20); err != nil {
			return err
		}
	}

	for key, values := range r.MultipartForm.Value {
		if len(values) == 0 {
			continue
		}
		val := values[0]
		if err := assignParsedValue(key, val, t); err != nil {
			return err
		}
	}
	return nil
}

func assignParsedValue(key, val string, t *map[string]interface{}) error {
	keyLower := strings.ToLower(key)

	switch {
	case keyLower == "is_active":
		(*t)[key] = parseBool(val)
	case keyLower == "last_login":
		return assignTimeField(key, val, t)
	case strings.Contains(keyLower, "date"):
		return assignTimeField(key, val, t)
	default:
		(*t)[key] = val
	}
	return nil
}

func assignTimeField(key, val string, t *map[string]interface{}) error {
	parsed, err := time.Parse(time.RFC3339, val)
	if err != nil {
		return fmt.Errorf("invalid %s format (expected RFC3339)", key)
	}
	(*t)[key] = parsed
	return nil
}

func parseBool(s string) bool {
	s = strings.ToLower(strings.TrimSpace(s))
	return s == "true" || s == "1" || s == "yes"
}

func parseTimeRFC3339(value, field string) (time.Time, error) {
	parsed, err := time.Parse(time.RFC3339, value)
	if err != nil {
		return time.Time{}, fmt.Errorf("invalid %s format (expected RFC3339)", field)
	}
	return parsed, nil
}
