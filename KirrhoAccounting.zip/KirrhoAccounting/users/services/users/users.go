package users

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	userModels "KirrhoAccounting/users/models/users"
	userRepo "KirrhoAccounting/users/repositories/users"
)

const (
	ErrNilUser   = "users cannot be nil"
	ErrMissingID = "users id is required"
)

type Service struct {
	DB       *sql.DB
	userRepo *userRepo.Repository
}

func NewUserService(db *sql.DB, repository *userRepo.Repository) *Service {
	return &Service{
		DB:       db,
		userRepo: repository,
	}
}

func (s *Service) CreateUser(ctx context.Context, u *userModels.Users) (*userModels.Users, error) {
	if u == nil {
		return nil, errors.New(ErrNilUser)
	}

	now := time.Now().UTC()
	u.CreatedAt = now
	u.UpdatedAt = now

	createdUser, err := s.userRepo.Create('public', u)
	if err != nil {
		return nil, fmt.Errorf("failed to create users: %w", err)
	}
	return createdUser, nil
}

func (s *Service) GetUser(ctx context.Context, id string) (*userModels.Users, error) {
	if id == "" {
		return nil, errors.New(ErrMissingID)
	}
	return s.userRepo.FindByPK(id)
}

func (s *Service) GetUserByEmail(ctx context.Context, email string) (*userModels.Users, error) {
	if email == "" {
		return nil, errors.New("email is required")
	}
	return s.userRepo.FindByEmail(email)
}

func (s *Service) ListUsers(ctx context.Context) ([]*userModels.Users, error) {
	return s.userRepo.FindAll()
}

func (s *Service) PartialUpdateUser(ctx context.Context, id string, updates map[string]interface{}) (*userModels.Users, error) {
	if id == "" {
		return nil, errors.New(ErrMissingID)
	}

	if len(updates) == 0 {
		return s.userRepo.FindByPK(id)
	}

	updates["updated_at"] = time.Now().UTC()

	if err := s.userRepo.PartialUpdate(id, updates); err != nil {
		return nil, fmt.Errorf("failed to update users: %w", err)
	}

	return s.userRepo.FindByPK(id)
}

func (s *Service) DeleteUser(ctx context.Context, id string) error {
	if id == "" {
		return errors.New(ErrMissingID)
	}
	return s.userRepo.Delete(id)
}
