package users

import (
	"KirrhoAccounting/pkg/persistence"
	userMapper "KirrhoAccounting/users/handlers/users"
	userModels "KirrhoAccounting/users/models/users"
	"database/sql"
	"fmt"
	"strings"
	"time"
)

type Repository struct {
	helper *persistence.SqlHelper
}

func NewUsersRepo(db *sql.DB) *Repository {
	return &Repository{helper: persistence.NewSqlHelper(db)}
}

func (r *Repository) Create(schemaName string, u *userModels.Users) (*userModels.Users, error) {
	query := fmt.Sprintf(`
		INSERT INTO %s.users (
			tenant_id, email, password_hash, full_name, role, is_active, last_login,
			profile_picture, created_at, created_by
		)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10);
	`, schemaName)

	resp := r.helper.Execute(
		query,
		u.TenantID,
		u.Email,
		u.PasswordHash,
		u.FullName,
		u.Role,
		u.IsActive,
		u.LastLogin,
		u.ProfilePicture,
		u.CreatedAt,
		u.CreatedBy,
	)

	if !resp.IsSuccess {
		return nil, fmt.Errorf(resp.Message)
	}

	return u, nil
}

func (r *Repository) FindByPK(id string) (*userModels.Users, error) {
	query := `SELECT * FROM "users" WHERE id=$1`
	resp := r.helper.Select(query, id)
	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows := resp.Data.([]map[string]interface{})
	if len(rows) == 0 {
		return nil, nil
	}

	return userMapper.MapRowToUser(rows[0]), nil
}

func (r *Repository) FindByEmail(email string) (*userModels.Users, error) {
	query := `SELECT * FROM "users" WHERE email=$1`
	resp := r.helper.Select(query, email)
	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows := resp.Data.([]map[string]interface{})
	if len(rows) == 0 {
		return nil, nil
	}

	return userMapper.MapRowToUser(rows[0]), nil
}

func (r *Repository) FindAll() ([]*userModels.Users, error) {
	query := `SELECT * FROM "users"`
	resp := r.helper.Select(query)
	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows := resp.Data.([]map[string]interface{})
	users := make([]*userModels.Users, 0, len(rows))
	for _, row := range rows {
		u := userMapper.MapRowToUser(row)
		users = append(users, u)
	}
	return users, nil
}

func (r *Repository) PartialUpdate(id string, updates map[string]interface{}) error {
	if len(updates) == 0 {
		return nil
	}

	allowed := map[string]bool{
		"email":           true,
		"password_hash":   true,
		"full_name":       true,
		"role":            true,
		"is_active":       true,
		"last_login":      true,
		"profile_picture": true,
		"updated_by":      true,
	}

	var setClauses []string
	var args []interface{}
	i := 1

	for field, value := range updates {
		if !allowed[field] {
			continue
		}
		setClauses = append(setClauses, fmt.Sprintf("%s = $%d", field, i))
		args = append(args, value)
		i++
	}

	if len(setClauses) == 0 {
		return nil
	}

	// Always update timestamp
	setClauses = append(setClauses, fmt.Sprintf("updated_at = $%d", i))
	args = append(args, time.Now().UTC())
	i++

	query := fmt.Sprintf(`UPDATE "users" SET %s WHERE id = $%d`,
		strings.Join(setClauses, ", "), i)
	args = append(args, id)

	resp := r.helper.Execute(query, args...)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}

	return nil
}

func (r *Repository) Delete(id string) error {
	query := `DELETE FROM "users" WHERE id=$1`
	resp := r.helper.Execute(query, id)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}
	return nil
}
