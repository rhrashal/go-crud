package users

import (
	"KirrhoAccounting/pkg/basemodel"
	"time"
)

type Users struct {
	ID             int64      `json:"id"`
	TenantID       int64      `json:"tenant_id"`
	Email          string     `json:"email"`
	PasswordHash   string     `json:"-"`
	FullName       *string    `json:"full_name,omitempty"`
	Role           string     `json:"role"`
	IsActive       bool       `json:"is_active"`
	LastLogin      *time.Time `json:"last_login,omitempty"`
	ProfilePicture *string    `json:"profile_picture,omitempty"`
	basemodel.AuditFields
}
