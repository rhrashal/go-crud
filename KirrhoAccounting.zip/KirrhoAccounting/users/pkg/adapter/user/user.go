package user

import (
	"context"
	"fmt"

	userModels "KirrhoAccounting/users/models/users"
	userService "KirrhoAccounting/users/services/users"
)

const (
	ErrUserNotFound = "users not found"
)

type HTTPUserAdapter struct {
	service *userService.Service
}

func NewHTTPUserAdapter(service *userService.Service) *HTTPUserAdapter {
	return &HTTPUserAdapter{service: service}
}

func (a *HTTPUserAdapter) CreateUser(ctx context.Context, u *userModels.Users) (*userModels.Users, error) {
	createdUser, err := a.service.CreateUser(ctx, u)
	if err != nil {
		return nil, fmt.Errorf("failed to create users: %w", err)
	}
	return createdUser, nil
}

func (a *HTTPUserAdapter) GetUser(ctx context.Context, id string) (*userModels.Users, error) {
	user, err := a.service.GetUser(ctx, id)
	if err != nil {
		return nil, fmt.Errorf("failed to get users: %w", err)
	}
	if user == nil {
		return nil, fmt.Errorf(ErrUserNotFound)
	}
	return user, nil
}

func (a *HTTPUserAdapter) GetUserByEmail(ctx context.Context, email string) (*userModels.Users, error) {
	user, err := a.service.GetUserByEmail(ctx, email)
	if err != nil {
		return nil, fmt.Errorf("failed to get users by email: %w", err)
	}
	if user == nil {
		return nil, fmt.Errorf(ErrUserNotFound)
	}
	return user, nil
}

func (a *HTTPUserAdapter) ListUsers(ctx context.Context) ([]*userModels.Users, error) {
	users, err := a.service.ListUsers(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to list users: %w", err)
	}
	return users, nil
}

func (a *HTTPUserAdapter) PartialUpdateUser(ctx context.Context, id string, updates map[string]interface{}) (*userModels.Users, error) {
	updatedUser, err := a.service.PartialUpdateUser(ctx, id, updates)
	if err != nil {
		return nil, fmt.Errorf("failed to update users: %w", err)
	}
	if updatedUser == nil {
		return nil, fmt.Errorf(ErrUserNotFound)
	}
	return updatedUser, nil
}

func (a *HTTPUserAdapter) DeleteUser(ctx context.Context, id string) error {
	if err := a.service.DeleteUser(ctx, id); err != nil {
		return fmt.Errorf("failed to delete users: %w", err)
	}
	return nil
}
