package user

import (
	auditModels "KirrhoAccounting/pkg/basemodel"
	"KirrhoAccounting/pkg/httpresponse"
	"KirrhoAccounting/pkg/messages"
	userHandler "KirrhoAccounting/users/handlers/users"
	userModels "KirrhoAccounting/users/models/users"
	userAdapter "KirrhoAccounting/users/pkg/adapter/user"
	"errors"
	"net/http"
	"strings"
	"time"

	"github.com/gorilla/mux"
)

type Handler struct {
	service *userAdapter.HTTPUserAdapter
}

func NewHandler(service *userAdapter.HTTPUserAdapter) *Handler {
	return &Handler{service: service}
}

func (h *Handler) CreateUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	input, err := userHandler.ParseCreateUserRequest(r)
	if err != nil {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	now := time.Now().UTC()
	isActive := true
	if input.IsActive != nil {
		isActive = *input.IsActive
	}

	u := &userModels.Users{
		Email:          input.Email,
		PasswordHash:   input.PasswordHash,
		FullName:       input.FullName,
		Role:           input.Role,
		IsActive:       isActive,
		LastLogin:      input.LastLogin,
		ProfilePicture: input.ProfilePicture,
		AuditFields: auditModels.AuditFields{
			CreatedAt: now,
			UpdatedAt: now,
			CreatedBy: input.CreatedBy,
		},
	}

	created, err := h.service.CreateUser(r.Context(), u)
	if err != nil {
		httpresponse.WriteError(w, messages.ExceptionMessage, http.StatusInternalServerError)
		return
	}

	httpresponse.WriteSuccess(
		w,
		messages.DataCreatedSuccessful,
		userHandler.MapUserResponse(created),
		http.StatusCreated,
	)
}

func (h *Handler) GetUser(w http.ResponseWriter, r *http.Request) {
	id := mux.Vars(r)["id"]
	if id == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	u, err := h.service.GetUser(r.Context(), id)
	if err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}
	if u == nil {
		httpresponse.WriteError(w, messages.NoDataFound, http.StatusNotFound)
		return
	}

	httpresponse.WriteSuccess(
		w,
		messages.DataRetrieved,
		userHandler.MapUserResponse(u),
		http.StatusOK,
	)
}

func (h *Handler) ListUsers(w http.ResponseWriter, r *http.Request) {
	users, err := h.service.ListUsers(r.Context())
	if err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}

	httpresponse.WriteSuccess(
		w,
		messages.DataRetrieved,
		userHandler.MapUserListResponse(users, time.RFC3339),
		http.StatusOK,
	)
}

func (h *Handler) PartialUpdateUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPatch {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	id := mux.Vars(r)["id"]
	if id == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	updates, err := userHandler.ParsePartialUpdateUserRequest(r)
	if err != nil {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	updated, err := h.service.PartialUpdateUser(r.Context(), id, updates)
	if err != nil {
		switch {
		case errors.Is(err, messages.NoDataFound),
			strings.Contains(err.Error(), messages.NoDataFound.Error()):
			httpresponse.WriteError(w, messages.NoDataFound, http.StatusNotFound)
		default:
			httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		}
		return
	}

	httpresponse.WriteSuccess(
		w,
		messages.DataUpdatedSuccessful,
		userHandler.MapUserResponse(updated),
		http.StatusOK,
	)
}

func (h *Handler) DeleteUser(w http.ResponseWriter, r *http.Request) {
	id := mux.Vars(r)["id"]
	if id == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	if err := h.service.DeleteUser(r.Context(), id); err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}

	httpresponse.WriteSuccess(w, messages.DeleteSuccessful, nil, http.StatusOK)
}
