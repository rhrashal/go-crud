# Kirrhosoft Restaurant Management Service

A robust and scalable microservice written in Go to power restaurant business operations — from POS to inventory, orders, and billing — as part of the **Kirrhosoft SaaS Platform**.

---

## 🚀 Features

- 🧾 **POS Operations** — Order entry, receipt printing, bill splitting
- 🍽️ **Kitchen Display (KOT)** — Real-time kitchen order tickets
- 🧺 **Inventory Management** — Stock control, purchase tracking, low-stock alerts
- 🗂️ **Menu Management** — Item catalog, pricing, variations
- 💳 **Billing & Payments** — Tax calculation, tips, multiple payment methods
- 📈 **Sales Reports** — Daily/weekly/monthly insights, staff & table analytics
- 🔐 **JWT-based Auth** — Integration with Kirrhosoft Orchestra service
- 🏪 **Multi-Tenant Support** — Isolated data per restaurant
- 🔁 **Offline Mode** *(optional)* — Syncing upon connectivity
- 🧠 **Metadata, Filtering, Search** — Rich API capabilities
- 📦 **File Uploads** — Invoices, customer receipts (max 2MB, compressed)
- 📊 **Monitoring & Metrics** — Prometheus-ready metrics, structured logs

---

## 🛠️ Tech Stack

| Layer             | Tool/Technology                  |
|------------------|----------------------------------|
| Language          | Go (Golang)                      |
| API               | REST + gRPC                      |
| Auth              | JWT via Orchestra Service        |
| DB                | PostgreSQL / MySQL               |
| Cache             | Redis                            |
| Messaging (opt)   | NATS / Kafka                     |
| DevOps            | Docker, Kubernetes, GitOps (ArgoCD) |
| Monitoring        | Prometheus, Grafana              |

---

## 🧱 Directory Structure

DB_HOST=localhost
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=abcd
DB_NAME=restaurant
GRPC_PORT=50051
HTTP_PORT=8000

#DATABASE_URL=postgres://postgres:postgres@localhost:5432/kirrho_db?sslmode=disable

DATABASE_URL=user=postgres password=abcd host=localhost port=5432 dbname=restaurant sslmode=disable
