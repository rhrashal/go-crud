-- +goose Up
CREATE TABLE IF NOT EXISTS subscriptions (
     id BIGSERIAL PRIMARY KEY,
     tenant_id BIGINT REFERENCES tenants(id) ON DELETE CASCADE,
     plan_id BIGINT REFERENCES plans(id) ON DELETE SET NULL,
     subscription_number TEXT UNIQUE,
     start_date TIMESTAMPTZ NOT NULL,
     end_date TIMESTAMPTZ,
     status TEXT NOT NULL CHECK (status IN ('active', 'pending', 'cancelled', 'expired', 'trial')),
     trial_start_date TIMESTAMPTZ,
     trial_end_date TIMESTAMPTZ,
     auto_renew BOOLEAN NOT NULL DEFAULT TRUE,
     renewal_date TIMESTAMPTZ,
     cancelled_at TIMESTAMPTZ,
     cancellation_reason TEXT,
     billing_cycle_days INT NOT NULL DEFAULT 30,
     next_billing_amount DECIMAL(10, 2) NOT NULL DEFAULT 0,
     currency TEXT NOT NULL DEFAULT 'USD',
     notes TEXT,
     metadata JSONB DEFAULT '{}'::jsonb,
     created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
     updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
     created_by TEXT,
     updated_by TEXT
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_subscriptions_tenant_id ON subscriptions(tenant_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_plan_id ON subscriptions(plan_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status);
CREATE INDEX IF NOT EXISTS idx_subscriptions_auto_renew ON subscriptions(auto_renew);
CREATE INDEX IF NOT EXISTS idx_subscriptions_billing_cycle_days ON subscriptions(billing_cycle_days);

-- Only ONE active subscription per tenant
CREATE UNIQUE INDEX IF NOT EXISTS uniq_active_subscription_per_tenant
    ON subscriptions (tenant_id)
    WHERE status = 'active';