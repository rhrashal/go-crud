-- +goose Up
CREATE TABLE IF NOT EXISTS plans (
     id BIGSERIAL PRIMARY KEY,
     code TEXT UNIQUE NOT NULL,
     name TEXT NOT NULL,
     description TEXT,
     price DECIMAL(10, 2) NOT NULL DEFAULT 0,
     currency TEXT NOT NULL DEFAULT 'USD',
     features JSONB DEFAULT '{}'::jsonb,
     trial_days INT NOT NULL DEFAULT 0,
     max_users INT NOT NULL DEFAULT 1,
     storage_limit_gb INT NOT NULL DEFAULT 1,
     api_limit INT NOT NULL DEFAULT 1000,
     is_active BOOLEAN NOT NULL DEFAULT TRUE,
     is_popular BOOLEAN NOT NULL DEFAULT FALSE,
     sort_order INT NOT NULL DEFAULT 0,
     created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
     updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
     created_by TEXT,
     updated_by TEXT
);

-- Indexes for efficient lookups
CREATE UNIQUE INDEX IF NOT EXISTS idx_plans_code ON plans(code);
CREATE INDEX IF NOT EXISTS idx_plans_is_active ON plans(is_active);
CREATE INDEX IF NOT EXISTS idx_plans_is_popular ON plans(is_popular);
CREATE INDEX IF NOT EXISTS idx_plans_sort_order ON plans(sort_order);