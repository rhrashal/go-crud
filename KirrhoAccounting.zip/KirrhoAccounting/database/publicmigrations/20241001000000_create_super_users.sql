-- +goose Up
CREATE TABLE IF NOT EXISTS super_users (
       id BIGSERIAL PRIMARY KEY,
       email TEXT UNIQUE NOT NULL,
       password_hash TEXT NOT NULL,
       role TEXT CHECK (
           role IN (
                    'super_admin',
                    'support',
                    'billing',
                    'sales',
                    'developer',
                    'auditor',
                    'marketing'
               )
           ) NOT NULL,
       is_active BOOLEAN NOT NULL DEFAULT TRUE,
       profile_picture TEXT,
       created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
       updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
       created_by TEXT,
       updated_by TEXT
);

-- Indexes
CREATE UNIQUE INDEX IF NOT EXISTS idx_super_users_email ON super_users(email);
CREATE INDEX IF NOT EXISTS idx_super_users_role ON super_users(role);