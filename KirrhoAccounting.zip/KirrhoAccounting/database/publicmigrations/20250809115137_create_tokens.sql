-- +goose Up
CREATE TABLE IF NOT EXISTS tokens (
  id BIGSERIAL PRIMARY KEY,
  super_user_id BIGINT NOT NULL REFERENCES super_users(id) ON DELETE CASCADE,
  token TEXT NOT NULL,
  token_type VARCHAR(50) NOT NULL DEFAULT 'refresh',
  user_agent VARCHAR(255),
  ip_address INET,
  platform VARCHAR(255),
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by TEXT,
  updated_by TEXT
);

CREATE INDEX IF NOT EXISTS idx_tokens_super_user_id ON tokens(super_user_id);
CREATE INDEX IF NOT EXISTS idx_tokens_token ON tokens(token);

-- +goose Down
DROP TABLE IF EXISTS tokens;
