-- +goose Up
CREATE TABLE IF NOT EXISTS payments (
    id BIGSERIAL PRIMARY KEY,
    subscription_id BIGINT NOT NULL REFERENCES subscriptions(id) ON DELETE CASCADE,
    invoice_number TEXT UNIQUE NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    currency TEXT NOT NULL DEFAULT 'USD',
    tax_amount DECIMAL(10, 2) DEFAULT 0,
    discount_amount DECIMAL(10, 2) DEFAULT 0,
    total_amount DECIMAL(10, 2)
        GENERATED ALWAYS AS (amount + tax_amount - discount_amount) STORED,
    payment_date TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    payment_due_date TIMESTAMPTZ,
    payment_method TEXT NOT NULL,
    transaction_id TEXT UNIQUE,
    status TEXT NOT NULL
        CHECK (status IN ('pending', 'completed', 'failed', 'refunded')),
    refund_id TEXT,
    retry_count INT DEFAULT 0,
    notes TEXT,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by TEXT,
    updated_by TEXT
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_payments_subscription_id ON payments(subscription_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_payments_payment_method ON payments(payment_method);
CREATE INDEX IF NOT EXISTS idx_payments_payment_date ON payments(payment_date);

-- +goose Down
DROP TABLE IF EXISTS payments;
