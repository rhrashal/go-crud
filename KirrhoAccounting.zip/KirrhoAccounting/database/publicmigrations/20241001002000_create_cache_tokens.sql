-- +goose Up
CREATE TABLE IF NOT EXISTS cache_tokens (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES super_users(id) ON DELETE CASCADE,
    token_key BIGINT NOT NULL UNIQUE,
    access_token TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by TEXT,
    updated_by TEXT
);

CREATE INDEX IF NOT EXISTS idx_cache_tokens_user_id ON cache_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_cache_tokens_token_key ON cache_tokens(token_key);

-- +goose Down
DROP TABLE IF EXISTS cache_tokens;
