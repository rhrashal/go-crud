-- +goose Up
CREATE TABLE IF NOT EXISTS tenants (
   id BIGSERIAL PRIMARY KEY,
   name TEXT NOT NULL,
   domain TEXT UNIQUE,
   email TEXT NOT NULL,
   phone TEXT,
   country TEXT,
   industry TEXT,
   plan_id BIGINT REFERENCES plans(id) ON DELETE SET NULL,
   schema_name TEXT UNIQUE,
   timezone TEXT NOT NULL DEFAULT 'UTC',
   is_active BOOLEAN NOT NULL DEFAULT TRUE,
   onboarding_completed BOOLEAN NOT NULL DEFAULT FALSE,
   metadata JSONB,
   created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
   updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
   created_by TEXT,
   updated_by TEXT
);

-- Indexes for efficient lookups
CREATE INDEX IF NOT EXISTS idx_tenants_domain ON tenants(domain);
CREATE INDEX IF NOT EXISTS idx_tenants_email ON tenants(email);
CREATE INDEX IF NOT EXISTS idx_tenants_plan_id ON tenants(plan_id);
CREATE INDEX IF NOT EXISTS idx_tenants_is_active ON tenants(is_active);

-- +goose Down
DROP TABLE IF EXISTS tenants;
