package database

import (
	"database/sql"
	"log"

	"github.com/joho/godotenv"
	"github.com/lib/pq"
	"github.com/pressly/goose/v3"

	"KirrhoAccounting/database"
)

func migrate(db *sql.DB, migrationDir string) error {
	if err := goose.SetDialect("postgres"); err != nil {
		return err
	}
	return goose.Up(db, migrationDir)
}

func migratePublicSchema(publicDB *sql.DB) {
	log.Println("Migrating public schema...")
	if err := migrate(publicDB, "./database/publicmigrations"); err != nil {
		log.Fatalf("failed to migrate public schema: %v", err)
	}
	log.Println("Public schema migrated successfully")
}

func migrateTenant(publicDB *sql.DB, tenantID, schemaName string) {
	log.Printf("Migrating tenants %s (schema: %s)...", tenantID, schemaName)

	_, err := publicDB.Exec("CREATE SCHEMA IF NOT EXISTS " + pq.QuoteIdentifier(schemaName))
	if err != nil {
		log.Printf("failed to create schema for tenants %s: %v", tenantID, err)
		return
	}

	_, err = publicDB.Exec("SET search_path TO " + pq.QuoteIdentifier(schemaName) + ", public")
	if err != nil {
		log.Printf("failed to set search_path for tenants %s: %v", tenantID, err)
		return
	}

	goose.SetTableName(schemaName + "_goose_db_version")

	if err := migrate(publicDB, "./database/tenantmigrations"); err != nil {
		log.Printf("failed to migrate tenants %s: %v", tenantID, err)
	} else {
		log.Printf("Tenant %s migrated successfully", tenantID)
	}

	_, _ = publicDB.Exec("SET search_path TO public")
}

func migrateTenants(publicDB *sql.DB) {
	rows, err := publicDB.Query(`SELECT id, schema_name FROM tenants`)
	if err != nil {
		log.Fatalf("failed to fetch tenants: %v", err)
	}
	defer func() {
		if err := rows.Close(); err != nil {
			log.Printf("error closing tenants rows: %v", err)
		}
	}()

	for rows.Next() {
		var tenantID, schemaName string
		if err := rows.Scan(&tenantID, &schemaName); err != nil {
			log.Printf("skip tenants scan error: %v", err)
			continue
		}
		migrateTenant(publicDB, tenantID, schemaName)
	}

	if err := rows.Err(); err != nil {
		log.Fatalf("error during tenants iteration: %v", err)
	}
}

func main() {
	if err := godotenv.Load(); err != nil {
		log.Println("No .env file found, using system environment variables")
	}

	publicDB, err := database.GetPostgresDB()
	if err != nil {
		log.Fatalf("failed to connect to public db: %v", err)
	}
	defer func() {
		if err := publicDB.Close(); err != nil {
			log.Printf("error closing public db: %v", err)
		}
	}()

	// Run migrations
	migratePublicSchema(publicDB)
	migrateTenants(publicDB)

	log.Println("All migrations complete")
}
