package database

import (
	"KirrhoAccounting/pkg/persistence"
	"database/sql"
	"fmt"
	"log"

	"github.com/lib/pq"
)

type TenantMigrator struct {
	DB     *sql.DB
	Helper *persistence.SqlHelper
}

func NewTenantMigrator(db *sql.DB) *TenantMigrator {
	return &TenantMigrator{
		DB:     db,
		Helper: persistence.NewSqlHelper(db),
	}
}

func (m *TenantMigrator) CreateSchemaAndTables(schema string) error {
	if schema == "" {
		return fmt.Errorf("schema name cannot be empty")
	}
	if m.Helper == nil {
		m.Helper = persistence.NewSqlHelper(m.DB)
	}

	if err := m.createSchema(schema); err != nil {
		return err
	}

	if err := m.verifySchema(schema); err != nil {
		return err
	}

	if err := m.createUsersTable(schema); err != nil {
		return err
	}

	if err := m.createTokensTable(schema); err != nil {
		return err
	}

	log.Printf("All tenants tables and indexes created successfully for schema %q", schema)
	return nil
}

func (m *TenantMigrator) createSchema(schema string) error {
	query := fmt.Sprintf(`CREATE SCHEMA IF NOT EXISTS %s;`, pq.QuoteIdentifier(schema))
	resp := m.Helper.Execute(query)
	if !resp.IsSuccess {
		return fmt.Errorf("failed to create schema %q: %s", schema, resp.Message)
	}
	log.Printf("Schema %q created or already exists", schema)
	return nil
}

func (m *TenantMigrator) verifySchema(schema string) error {
	query := `
		SELECT EXISTS (
			SELECT 1
			FROM information_schema.schemata
			WHERE schema_name = $1
		);
	`
	var exists bool
	if err := m.DB.QueryRow(query, schema).Scan(&exists); err != nil {
		return fmt.Errorf("failed to verify schema existence for %q: %w", schema, err)
	}
	if !exists {
		return fmt.Errorf("schema %q was not created successfully", schema)
	}
	log.Printf("Verified schema existence for %q", schema)
	return nil
}

func (m *TenantMigrator) createUsersTable(schema string) error {
	table := fmt.Sprintf(`%s.users`, pq.QuoteIdentifier(schema))

	createTable := fmt.Sprintf(`
	CREATE TABLE IF NOT EXISTS %s (
		id BIGSERIAL PRIMARY KEY,
		tenant_id BIGINT NOT NULL,
		email TEXT NOT NULL,
		password_hash TEXT NOT NULL,
		full_name TEXT,
		profile_picture TEXT NULL,
		role TEXT NOT NULL
			CHECK (role IN ('owner','admin','manager','member','viewer'))
			DEFAULT 'member',
		is_active BOOLEAN NOT NULL DEFAULT true,
		last_login TIMESTAMPTZ,
		created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
		updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
		created_by TEXT,
		updated_by TEXT,
		CONSTRAINT users_tenant_email_uniq UNIQUE (tenant_id, email)
	);`, table)

	if resp := m.Helper.Execute(createTable); !resp.IsSuccess {
		return fmt.Errorf("failed to create users table: %s", resp.Message)
	}

	indexes := []string{
		fmt.Sprintf(
			`CREATE INDEX IF NOT EXISTS %s_users_role_idx ON %s (role);`,
			schema, table,
		),
		fmt.Sprintf(
			`CREATE INDEX IF NOT EXISTS %s_users_is_active_idx ON %s (is_active);`,
			schema, table,
		),
	}

	for _, q := range indexes {
		if resp := m.Helper.Execute(q); !resp.IsSuccess {
			return fmt.Errorf("failed to create users index: %s", resp.Message)
		}
	}

	log.Printf("Users table and indexes created for schema %q", schema)
	return nil
}

func (m *TenantMigrator) createTokensTable(schema string) error {
	createTable := fmt.Sprintf(`
	CREATE TABLE IF NOT EXISTS %s.tokens (
		id BIGSERIAL PRIMARY KEY,
		user_id BIGINT NOT NULL REFERENCES %s.users(id) ON DELETE CASCADE,
		token TEXT NOT NULL,
		token_type VARCHAR(50) CHECK (token_type IN ('refresh','access','handlers','reset_password','verification')) NOT NULL DEFAULT 'refresh',
		user_agent TEXT,
		ip_address INET,
		expires_at TIMESTAMPTZ NOT NULL,
		created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
		updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
		revoked_at TIMESTAMPTZ
	);`, pq.QuoteIdentifier(schema), pq.QuoteIdentifier(schema))

	if resp := m.Helper.Execute(createTable); !resp.IsSuccess {
		return fmt.Errorf("failed to create tokens table: %s", resp.Message)
	}

	indexes := []string{
		fmt.Sprintf(`CREATE INDEX IF NOT EXISTS idx_tokens_user_id ON %s.tokens(user_id);`, pq.QuoteIdentifier(schema)),
		fmt.Sprintf(`CREATE INDEX IF NOT EXISTS idx_tokens_token ON %s.tokens(token);`, pq.QuoteIdentifier(schema)),
		fmt.Sprintf(`CREATE INDEX IF NOT EXISTS idx_tokens_token_type ON %s.tokens(token_type);`, pq.QuoteIdentifier(schema)),
		fmt.Sprintf(`CREATE INDEX IF NOT EXISTS idx_tokens_expires_at ON %s.tokens(expires_at);`, pq.QuoteIdentifier(schema)),
	}
	for _, q := range indexes {
		if resp := m.Helper.Execute(q); !resp.IsSuccess {
			return fmt.Errorf("failed creating tokens index: %s", resp.Message)
		}
	}
	log.Printf("Tokens table and indexes created for schema %q", schema)
	return nil
}

func SetSearchPath(tx *sql.Tx, schema string) error {
	query := fmt.Sprintf(
		`SET search_path TO %s, public`,
		pq.QuoteIdentifier(schema),
	)
	_, err := tx.Exec(query)
	return err
}

func ResetSearchPath(tx *sql.Tx) error {
	_, err := tx.Exec(`SET search_path TO public`)
	return err
}
