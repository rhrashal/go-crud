package database

import (
	tenantModels "KirrhoAccounting/kirrhosoft/models/tenants"
	baseModel "KirrhoAccounting/pkg/basemodel"
	userModels "KirrhoAccounting/users/models/users"
	userRepo "KirrhoAccounting/users/repositories/users"
	"context"
	"database/sql"
	"errors"
	"fmt"
	"log"
	"time"

	"github.com/lib/pq"
)

type TenantSeeder struct {
	DB       *sql.DB
	UserRepo *userRepo.Repository
}

func (s *TenantSeeder) SeedDefaults(
	ctx context.Context,
	tenant *tenantModels.Tenant,
) (*userModels.Users, error) {
	if tenant == nil {
		return nil, errors.New("tenant is nil")
	}
	if tenant.SchemaName == nil || *tenant.SchemaName == "" {
		return nil, errors.New("tenant schema name is missing")
	}
	if tenant.Email == "" {
		return nil, errors.New("tenant admin email is missing")
	}

	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to begin tx: %w", err)
	}

	committed := false
	defer func() {
		if !committed {
			_ = tx.Rollback()
		}
	}()
	schemaName := *tenant.SchemaName
	if _, err = tx.ExecContext(
		ctx,
		fmt.Sprintf("SET search_path TO %s, public", pq.QuoteIdentifier(schemaName)),
	); err != nil {
		return nil, fmt.Errorf("failed to set search_path: %w", err)
	}

	now := time.Now().UTC()
	fullName := "Default Admin"

	adminUser := &userModels.Users{
		TenantID:       tenant.ID,
		Email:          tenant.Email,
		PasswordHash:   "",
		FullName:       &fullName,
		Role:           "owner",
		IsActive:       true,
		LastLogin:      nil,
		ProfilePicture: nil,
		AuditFields: baseModel.AuditFields{
			CreatedAt: now,
			UpdatedAt: now,
			CreatedBy: "system",
			UpdatedBy: "system",
		},
	}

	createdUser, err := s.UserRepo.Create(schemaName, adminUser)
	if err != nil {
		return nil, fmt.Errorf("failed to create admin user: %w", err)
	}

	if _, err = tx.ExecContext(ctx, "SET search_path TO public"); err != nil {
		return nil, fmt.Errorf("failed to reset search_path: %w", err)
	}

	if err = tx.Commit(); err != nil {
		return nil, fmt.Errorf("failed to commit seed data: %w", err)
	}
	committed = true

	log.Printf("Seed data added successfully for tenant schema: %s", schemaName)
	return createdUser, nil
}
