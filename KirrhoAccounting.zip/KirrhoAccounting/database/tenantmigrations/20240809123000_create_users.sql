-- +goose Up
CREATE TABLE IF NOT EXISTS "user" (
     id BIGSERIAL PRIMARY KEY,
     tenant_id BIGINT NOT NULL,
     email TEXT NOT NULL,
     password_hash TEXT NOT NULL,
     full_name TEXT,
     profile_picture TEXT NULL,
     role TEXT NOT NULL
         CHECK (role IN ('owner','admin','manager','member','viewer'))
                                     DEFAULT 'member',
     is_active BOOLEAN NOT NULL DEFAULT true,
     last_login TIMESTAMPTZ,
     created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
     updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
     created_by TEXT,
     updated_by TEXT
);

-- Indexes
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_tenant_email
    ON users (tenant_id, email);

CREATE INDEX IF NOT EXISTS idx_users_tenant_role
    ON users (tenant_id, role);

CREATE INDEX IF NOT EXISTS idx_users_is_active
    ON users (is_active);

-- +goose Down
DROP TABLE IF EXISTS users;
