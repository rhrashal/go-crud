package repositories

type Repository[T any] interface {
	Create(entity *T) (*T, error)
	GetByID(id int64) (*T, error)
	GetList() ([]*T, error)
	PartialUpdate(id int64, updates map[string]interface{}) error
	Delete(id int64) error
}
