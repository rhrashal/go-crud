package repositories

import (
	"KirrhoAccounting/accounting/models"
	"KirrhoAccounting/accounting/pkg/logger"
	mapper "KirrhoAccounting/pkg/convert"
	"KirrhoAccounting/pkg/messages"
	"KirrhoAccounting/pkg/persistence"
	"database/sql"
	"errors"
	"fmt"
	"strings"
)

type CurrencyRepository interface {
	Repository[models.Currency]
	GetByCode(key string) (*models.Currency, error)
	InactiveCurrency() ([]*models.Currency, error)
}

type currencyRepository struct {
	helper *persistence.SqlHelper
}

func NewCurrencyRepository(db *sql.DB) CurrencyRepository {
	return &currencyRepository{helper: persistence.NewSqlHelper(db)}
}

func (r *currencyRepository) Create(t *models.Currency) (*models.Currency, error) {
	query := `
		INSERT INTO currency
		(code, name, symbol, decimal_places, is_active, is_crypto, created_at, created_by)
		VALUES ($1,$2,$3,$4,$5,$6,now(),'')
		RETURNING id
	`

	resp := r.helper.InsertWithID(
		query,
		t.Code,
		t.Name,
		t.Symbol,
		t.DecimalPlaces,
		t.IsActive,
		t.IsCrypto,
	)

	if !resp.IsSuccess {
		return nil, fmt.Errorf(resp.Message)
	}

	t.ID = resp.Data.(int64)
	return t, nil
}

func (r *currencyRepository) GetList() ([]*models.Currency, error) {
	query := `SELECT id, code, "name", symbol, decimal_places, is_active, is_crypto
    , created_at, updated_at, created_by, updated_by FROM currency WHERE is_active = true`

	resp := r.helper.Select(query)
	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows := resp.Data.([]map[string]interface{})
	currencies := make([]*models.Currency, 0, len(rows))
	for _, row := range rows {
		currencies = append(currencies, mapper.MapRow[models.Currency](row))
	}
	return currencies, nil
}

func (r *currencyRepository) GetByID(id int64) (*models.Currency, error) {
	query := `SELECT id, code, "name", symbol, decimal_places, is_active, is_crypto
    , created_at, updated_at, created_by, updated_by FROM currency WHERE id = $1`
	resp := r.helper.Select(query, id)
	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}
	rows, ok := resp.Data.([]map[string]interface{})
	if !ok || len(rows) == 0 {
		return nil, messages.NoDataFound
	}

	return mapper.MapRow[models.Currency](rows[0]), nil
}

func (r *currencyRepository) PartialUpdate(id int64, updates map[string]interface{}) error {
	if len(updates) == 0 {
		return nil
	}

	allowed := map[string]bool{
		"code":           true,
		"name":           true,
		"symbol":         true,
		"decimal_places": true,
		"is_active":      true,
		"is_crypto":      true,
		"updated_at":     true,
		"updated_by":     true,
	}
	setClauses := []string{}
	args := []interface{}{}
	i := 1

	for col, val := range updates {
		if !allowed[col] {
			continue
		}
		setClauses = append(setClauses, fmt.Sprintf("%s = $%d", col, i))
		args = append(args, val)
		i++
	}
	if len(setClauses) == 0 {
		return errors.New("no valid fields to update")
	}

	//setClauses = append(setClauses, fmt.Sprintf("updated_at = $%d", i))
	//args = append(args, time.Now().UTC())
	//i++

	query := fmt.Sprintf(`
		UPDATE currency SET %s WHERE id = $%d `, strings.Join(setClauses, ", "), i)
	args = append(args, id)

	resp := r.helper.Execute(query, args...)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}
	return nil
}

func (r *currencyRepository) Delete(id int64) error {
	query := `DELETE FROM currency WHERE id = $1`
	resp := r.helper.Execute(query, id)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}
	//rows, ok := resp.Data.([]map[string]interface{})
	//if !ok || len(rows) == 0 {
	//	return messages.NoDataFound
	//}
	return nil
}

func (r *currencyRepository) GetByCode(key string) (*models.Currency, error) {
	query := `SELECT id, code, "name", symbol, decimal_places, is_active, is_crypto
    , created_at, updated_at, created_by, updated_by FROM currency WHERE code = $1`
	resp := r.helper.Select(query, key)
	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}
	rows, ok := resp.Data.([]map[string]interface{})
	if !ok || len(rows) == 0 {
		return nil, messages.NoDataFound
	}
	return mapper.MapRow[models.Currency](rows[0]), nil
}

func (r *currencyRepository) InactiveCurrency() ([]*models.Currency, error) {
	query := `SELECT id, code, "name", symbol, decimal_places, is_active, is_crypto
    , created_at, updated_at, created_by, updated_by FROM currency WHERE is_active = false`

	resp := r.helper.Select(query)
	if !resp.IsSuccess {
		logger.Error.Println("%s", resp.Message)
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows := resp.Data.([]map[string]interface{})
	currencies := make([]*models.Currency, 0, len(rows))
	for _, row := range rows {
		currencies = append(currencies, mapper.MapRow[models.Currency](row))
	}
	return currencies, nil
}
