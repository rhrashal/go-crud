package routes

import (
	accDi "KirrhoAccounting/accounting/api/di"

	"github.com/gorilla/mux"
)

// RegisterAllRoutes registers all routes for the app
func RegisterAllRoutes(r *mux.Router, accContainer *accDi.Container) {

	// Accounting module routes
	RegisterCurrencyRoutes(r, accContainer.Currency.Handler)

}
