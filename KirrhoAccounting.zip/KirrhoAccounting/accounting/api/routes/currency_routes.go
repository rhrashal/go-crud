package routes

import (
	currencyHttp "KirrhoAccounting/accounting/api/handlers/http"
	"net/http"

	"github.com/gorilla/mux"
)

func RegisterCurrencyRoutes(r *mux.Router, handler *currencyHttp.Handler) {

	r.HandleFunc("/currency/create", handler.CreateCurrency).Methods(http.MethodPost)
	r.HandleFunc("/currency/list", handler.CurrencyList).Methods(http.MethodGet)
	r.HandleFunc("/currency/inactive_list", handler.InactiveCurrency).Methods(http.MethodGet)
	// Dynamic routes after
	r.HandleFunc("/currency/{id}", handler.GetCurrencyById).Methods(http.MethodGet)
	r.HandleFunc("/currency/code/{code}", handler.GetCurrencyByCode).Methods(http.MethodGet)
	r.HandleFunc("/currency/{id}/partial/update", handler.PartialUpldateCurrency).Methods(http.MethodPatch)
	r.HandleFunc("/currency/{id}/delete", handler.DeleteCurrency).Methods(http.MethodDelete)
}
