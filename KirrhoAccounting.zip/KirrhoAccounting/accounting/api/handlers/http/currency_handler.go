package http

import (
	"KirrhoAccounting/accounting/models"
	currencyService "KirrhoAccounting/accounting/services"
	parser "KirrhoAccounting/pkg/convert"

	"KirrhoAccounting/pkg/httpresponse"
	"KirrhoAccounting/pkg/messages"
	"log"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"
)

const errInvalidCurrencyID = "Invalid Currency ID"

type Handler struct {
	service currencyService.CurrencyService
}

func NewHandler(s currencyService.CurrencyService) *Handler {
	return &Handler{service: s}
}

func (h *Handler) CreateCurrency(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	input, err := parser.ParseRequest[models.Currency](r)
	if err != nil {
		httpresponse.WriteError(w, messages.ErrorMessage(err.Error()), http.StatusBadRequest)
		return
	}

	created, err := h.service.Create(r.Context(), input)
	if err != nil {
		log.Printf("CreateSetting failed: %v", err)
		httpresponse.WriteError(w, messages.ErrorMessage(err.Error()), http.StatusInternalServerError)
		return
	}
	httpresponse.WriteSuccess(w, messages.DataCreatedSuccessful, created, http.StatusCreated)
}

func (h *Handler) GetCurrencyById(w http.ResponseWriter, r *http.Request) {
	idStr := mux.Vars(r)["id"]
	if idStr == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil || id <= 0 {
		httpresponse.WriteError(w, errInvalidCurrencyID, http.StatusBadRequest)
		return
	}

	t, err := h.service.GetById(r.Context(), id)
	if err != nil {
		httpresponse.WriteServiceError(w, err)
		return
	}
	httpresponse.WriteSuccess(w, messages.DataRetrieved, t, http.StatusOK)
}

func (h *Handler) CurrencyList(w http.ResponseWriter, r *http.Request) {
	currencyList, err := h.service.GetList(r.Context())
	if err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}
	httpresponse.WriteSuccess(w, messages.DataRetrieved, currencyList, http.StatusOK)
}

func (h *Handler) PartialUpldateCurrency(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPatch {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	idStr := mux.Vars(r)["id"]
	id, err := strconv.ParseInt(idStr, 10, 64)

	if err != nil || id <= 0 {
		httpresponse.WriteError(w, errInvalidCurrencyID, http.StatusBadRequest)
		return
	}

	//updates, err := parser.ParseUpdateRequest[map[string]interface{}](r)
	updates, err := parser.ParseUpdateRequest[models.Currency](r)
	if err != nil {
		httpresponse.WriteError(w, messages.ErrorMessage(err.Error()), http.StatusBadRequest)
		return
	}

	updated, err := h.service.PartialUpdate(r.Context(), id, updates)
	if err != nil {
		httpresponse.WriteServiceError(w, err)
		return
	}
	httpresponse.WriteSuccess(w, messages.DataUpdatedSuccessful, updated, http.StatusOK)
}

func (h *Handler) DeleteCurrency(w http.ResponseWriter, r *http.Request) {
	idStr := mux.Vars(r)["id"]
	if idStr == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil || id <= 0 {
		httpresponse.WriteError(w, errInvalidCurrencyID, http.StatusBadRequest)
		return
	}

	if err := h.service.Delete(r.Context(), id); err != nil {
		httpresponse.WriteServiceError(w, err)
		return
	}

	httpresponse.WriteSuccess(w, messages.DeleteSuccessful, nil, http.StatusOK)
}

func (h *Handler) GetCurrencyByCode(w http.ResponseWriter, r *http.Request) {
	code := mux.Vars(r)["code"]
	if code == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	t, err := h.service.GetByCode(r.Context(), code)
	if err != nil {
		httpresponse.WriteServiceError(w, err)
		return
	}
	httpresponse.WriteSuccess(w, messages.DataRetrieved, t, http.StatusOK)
}

func (h *Handler) InactiveCurrency(w http.ResponseWriter, r *http.Request) {
	currencyList, err := h.service.InactiveCurrency(r.Context())
	if err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}
	httpresponse.WriteSuccess(w, messages.DataRetrieved, currencyList, http.StatusOK)
}
