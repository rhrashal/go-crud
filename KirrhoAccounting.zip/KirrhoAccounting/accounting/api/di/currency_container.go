package di

import (
	currencyhttp "KirrhoAccounting/accounting/api/handlers/http"
	currencyrepository "KirrhoAccounting/accounting/repositories"
	currencyservice "KirrhoAccounting/accounting/services"
	"database/sql"
)

type CurrencyContainer struct {
	Handler *currencyhttp.Handler
	Service *currencyservice.CurrencyService
	Repo    *currencyrepository.CurrencyRepository
}

func InitCurrencyContainer(db *sql.DB) *CurrencyContainer {
	repo := currencyrepository.NewCurrencyRepository(db)
	service := currencyservice.NewCurrencyService(repo)
	handler := currencyhttp.NewHandler(service)

	return &CurrencyContainer{
		Handler: handler,
	}
}
