package di

import (
	"KirrhoAccounting/database"
	"database/sql"

	"github.com/joho/godotenv"
)

type Container struct {
	DB *sql.DB

	Currency *CurrencyContainer
	//User     *UserContainer
	//Payroll  *PayrollContainer
}

func InitContainer() (*Container, error) {
	if err := godotenv.Load(); err != nil {
		return nil, err
	}

	db, err := database.GetPostgresDB()
	if err != nil {
		return nil, err
	}

	container := &Container{
		DB: db,
	}

	container.Currency = InitCurrencyContainer(db)
	//container.User = InitUserContainer(db)
	//container.Payroll = InitPayrollContainer(db)

	return container, nil
}
