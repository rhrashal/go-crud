package services

import (
	"KirrhoAccounting/accounting/models"
	repository "KirrhoAccounting/accounting/repositories"
	"context"
	"errors"
	"time"
)

type CurrencyService interface {
	Service[models.Currency]
	GetByCode(ctx context.Context, key string) (*models.Currency, error)
	InactiveCurrency(ctx context.Context) ([]*models.Currency, error)
}

type currencyService struct {
	repo repository.CurrencyRepository
}

func NewCurrencyService(r repository.CurrencyRepository) CurrencyService {
	return &currencyService{repo: r}
}

func (s currencyService) Create(ctx context.Context, currency *models.Currency) (*models.Currency, error) {
	//if currency.Code == "" {
	//	return nil, errors.New("Currency code is required")
	//}

	if currency.Name == "" {
		return nil, errors.New("Currency name is required")
	}
	now := time.Now().UTC()
	currency.CreatedAt = now
	currency.UpdatedAt = now
	createdCurrency, err := s.repo.Create(currency)
	if err != nil {
		return nil, err
	}
	return createdCurrency, nil
}

func (s currencyService) GetById(ctx context.Context, id int64) (*models.Currency, error) {
	if id <= 0 {
		return nil, errors.New("Invalid id")
	}
	return s.repo.GetByID(id)
}

func (s currencyService) GetList(ctx context.Context) ([]*models.Currency, error) {
	return s.repo.GetList()
}

func (s currencyService) PartialUpdate(ctx context.Context, id int64, updates map[string]interface{}) (*models.Currency, error) {
	if id <= 0 {
		return nil, errors.New("invalid currency id")
	}
	if len(updates) == 0 {
		return s.repo.GetByID(id)
	}
	updates["updated_at"] = time.Now().UTC()
	if err := s.repo.PartialUpdate(id, updates); err != nil {
		return nil, err
	}
	return s.repo.GetByID(id)
}

func (s currencyService) Delete(ctx context.Context, id int64) error {
	if id <= 0 {
		return errors.New("Invalid id")
	}
	return s.repo.Delete(id)
}

func (s currencyService) GetByCode(ctx context.Context, key string) (*models.Currency, error) {
	if key == "" {
		return nil, errors.New("Invalid Code")
	}
	return s.repo.GetByCode(key)
}

func (s currencyService) InactiveCurrency(ctx context.Context) ([]*models.Currency, error) {
	return s.repo.InactiveCurrency()
}
