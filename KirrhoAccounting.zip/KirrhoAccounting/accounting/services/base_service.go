package services

import "context"

type Service[T any] interface {
	Create(ctx context.Context, entity *T) (*T, error)
	GetById(ctx context.Context, id int64) (*T, error)
	GetList(ctx context.Context) ([]*T, error)
	PartialUpdate(ctx context.Context, id int64, updates map[string]interface{}) (*T, error)
	Delete(ctx context.Context, id int64) error
}
