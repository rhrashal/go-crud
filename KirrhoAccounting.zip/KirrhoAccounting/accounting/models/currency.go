package models

import (
	"KirrhoAccounting/pkg/basemodel"
	"errors"
	"strings"
)

type Currency struct {
	ID            int64   `json:"id" db:"id"`
	Code          string  `json:"code" db:"code"`
	Name          string  `json:"name" db:"name"`
	Symbol        *string `json:"symbol,omitempty" db:"symbol"`
	DecimalPlaces int16   `json:"decimal_places" db:"decimal_places"`
	IsActive      bool    `json:"is_active" db:"is_active"`
	IsCrypto      bool    `json:"is_crypto" db:"is_crypto"`
	basemodel.AuditFields
}

func (c *Currency) Normalize() {
	c.Code = strings.ToUpper(strings.TrimSpace(c.Code))
	c.Name = strings.TrimSpace(c.Name)
}

func (c *Currency) Validate() error {
	if c.Code == "" {
		return errors.New("key is required")
	}
	if c.Name == "" {
		return errors.New("name is required")
	}
	return nil
}
