package logger

import (
	"io"
	"log"
	"os"
	"path/filepath"
)

var (
	Debug *log.Logger
	Info  *log.Logger
	Warn  *log.Logger
	Error *log.Logger
)

func Init() {
	exePath, err := os.Executable()
	if err != nil {
		log.Fatalf("cannot get executable path: %v", err)
	}

	baseDir := filepath.Dir(exePath)
	logDir := filepath.Join(baseDir, "logs")

	// Ensure logs directory exists
	if err := os.MkdirAll(logDir, 0755); err != nil {
		log.Fatalf("cannot create log dir: %v", err)
	}

	debugFile := openLogFile(filepath.Join(logDir, "debug.log"))
	infoFile := openLogFile(filepath.Join(logDir, "info.log"))
	warnFile := openLogFile(filepath.Join(logDir, "warn.log"))
	errorFile := openLogFile(filepath.Join(logDir, "error.log"))

	Debug = log.New(
		io.MultiWriter(os.Stdout, debugFile),
		"[DEBUG] ",
		log.Ldate|log.Ltime|log.Lshortfile,
	)

	Info = log.New(
		io.MultiWriter(os.Stdout, infoFile),
		"[INFO] ",
		log.Ldate|log.Ltime|log.Lshortfile,
	)

	Warn = log.New(
		io.MultiWriter(os.Stdout, warnFile),
		"[WARN] ",
		log.Ldate|log.Ltime|log.Lshortfile,
	)

	Error = log.New(
		io.MultiWriter(os.Stderr, errorFile),
		"[ERROR] ",
		log.Ldate|log.Ltime|log.Lshortfile,
	)
}

func openLogFile(path string) *os.File {
	file, err := os.OpenFile(
		path,
		os.O_APPEND|os.O_CREATE|os.O_WRONLY,
		0644,
	)
	if err != nil {
		log.Fatalf("failed to open log file %s: %v", path, err)
	}
	return file
}
