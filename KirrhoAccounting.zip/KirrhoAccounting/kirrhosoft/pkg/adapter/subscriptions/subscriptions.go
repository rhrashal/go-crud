package subscriptions

import (
	"context"
	"fmt"

	subModels "KirrhoAccounting/kirrhosoft/models/subscriptions"
	subService "KirrhoAccounting/kirrhosoft/services/subscriptions"
)

type HTTPSubscriptionsAdapter struct {
	service *subService.Service
}

func NewHTTPSubscriptionsAdapter(service *subService.Service) *HTTPSubscriptionsAdapter {
	return &HTTPSubscriptionsAdapter{service: service}
}

func (a *HTTPSubscriptionsAdapter) CreateSubscription(ctx context.Context, s *subModels.Subscription) (*subModels.Subscription, error) {
	createdSub, err := a.service.CreateSubscription(ctx, s)
	if err != nil {
		return nil, fmt.Errorf("failed to create subscription: %w", err)
	}
	return createdSub, nil
}

func (a *HTTPSubscriptionsAdapter) GetSubscription(ctx context.Context, id string) (*subModels.Subscription, error) {
	sub, err := a.service.GetSubscription(ctx, id)
	if err != nil {
		return nil, fmt.Errorf("failed to get subscription: %w", err)
	}
	if sub == nil {
		return nil, fmt.Errorf("subscription not found")
	}
	return sub, nil
}

func (a *HTTPSubscriptionsAdapter) ListSubscriptions(ctx context.Context) ([]*subModels.Subscription, error) {
	subs, err := a.service.ListSubscriptions(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to list subscriptions: %w", err)
	}
	return subs, nil
}

func (a *HTTPSubscriptionsAdapter) PartialUpdateSubscription(ctx context.Context, id string, updates map[string]interface{}) (*subModels.Subscription, error) {
	updatedSub, err := a.service.PartialUpdateSubscription(ctx, id, updates)
	if err != nil {
		return nil, fmt.Errorf("failed to update subscription: %w", err)
	}
	if updatedSub == nil {
		return nil, fmt.Errorf("subscription not found")
	}
	return updatedSub, nil
}

func (a *HTTPSubscriptionsAdapter) DeleteSubscription(ctx context.Context, id string) error {
	if err := a.service.DeleteSubscription(ctx, id); err != nil {
		return fmt.Errorf("failed to delete subscription: %w", err)
	}
	return nil
}
