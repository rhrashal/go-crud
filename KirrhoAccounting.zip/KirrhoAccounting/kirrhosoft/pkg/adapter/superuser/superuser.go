package superuser

import (
	mapper "KirrhoAccounting/kirrhosoft/handlers/superuser"
	roleMapper "KirrhoAccounting/kirrhosoft/handlers/superuser"
	"KirrhoAccounting/kirrhosoft/models/superuser"
	superuserpb "KirrhoAccounting/kirrhosoft/pb/superuser"
	"KirrhoAccounting/pkg/convert"
	"context"
	"errors"
	"fmt"
)

type grpcServiceAdapter struct {
	client superuserpb.SuperUserServiceClient
}

func NewGRPCServiceAdapter(client superuserpb.SuperUserServiceClient) superuser.Service {
	return &grpcServiceAdapter{client: client}
}

func (a *grpcServiceAdapter) RegisterSuperUser(ctx context.Context, u *superuser.SuperUser, plainPassword string) (*superuser.SuperUser, error) {
	res, err := a.client.RegisterSuperUser(ctx, &superuserpb.RegisterSuperUserRequest{
		Email:          u.Email,
		Password:       plainPassword,
		Role:           roleMapper.RoleToEnum(u.Role),
		CreatedBy:      u.CreatedBy,
		ProfilePicture: convert.DerefString(u.ProfilePicture),
	})
	if err != nil {
		return nil, err
	}

	return mapper.MapFromProto(res), nil
}

func (a *grpcServiceAdapter) LoginSuperUser(ctx context.Context, email, password string) (*superuser.SuperUser, error) {
	res, err := a.client.LoginSuperUser(ctx, &superuserpb.LoginSuperUserRequest{
		Email:    email,
		Password: password,
	})
	if err != nil {
		return nil, err
	}
	if res == nil {
		return nil, errors.New("invalid credentials")
	}

	return mapper.MapFromProto(res), nil
}

func (a *grpcServiceAdapter) GetSuperUser(ctx context.Context, id int64) (*superuser.SuperUser, error) {
	res, err := a.client.GetSuperUser(ctx, &superuserpb.GetSuperUserRequest{Id: id})
	if err != nil {
		return nil, err
	}
	if res == nil {
		return nil, errors.New("superuser not found")
	}
	return mapper.MapFromProto(res), nil
}

func (a *grpcServiceAdapter) ListSuperUsers(ctx context.Context) ([]*superuser.SuperUser, error) {
	res, err := a.client.ListSuperUsers(ctx, &superuserpb.ListSuperUsersRequest{})
	if err != nil {
		return nil, err
	}
	return mapper.MapListFromProto(res), nil
}

func (a *grpcServiceAdapter) UpdateSuperUser(ctx context.Context, u *superuser.SuperUser) error {
	_, err := a.client.UpdateSuperUser(ctx, &superuserpb.UpdateSuperUserRequest{
		Id:             u.ID,
		Email:          convert.WrapString(u.Email),
		Role:           roleMapper.RoleToEnum(u.Role).Enum(),
		IsActive:       &u.IsActive,
		ProfilePicture: convert.WrapString(convert.DerefString(u.ProfilePicture)),
		UpdatedBy:      u.UpdatedBy,
	})
	return err
}

func (a *grpcServiceAdapter) PartialUpdateSuperUser(ctx context.Context, id int64, updates map[string]interface{}) error {
	stringUpdates := make(map[string]string, len(updates))
	for k, v := range updates {
		stringUpdates[k] = fmt.Sprintf("%v", v)
	}

	_, err := a.client.PartialUpdateSuperUser(ctx, &superuserpb.PartialUpdateSuperUserRequest{
		Id:      id,
		Updates: stringUpdates,
	})
	return err
}

func (a *grpcServiceAdapter) UpdateSuperUserPassword(ctx context.Context, id int64, oldPassword, newPassword, updatedBy string) error {
	_, err := a.client.UpdateSuperUserPassword(ctx, &superuserpb.UpdateSuperUserPasswordRequest{
		Id:          id,
		OldPassword: oldPassword,
		NewPassword: newPassword,
		UpdatedBy:   updatedBy,
	})
	return err
}

func (a *grpcServiceAdapter) DeactivateSuperUser(ctx context.Context, id int64, isActive bool, updatedBy string) error {
	_, err := a.client.DeactivateSuperUser(ctx, &superuserpb.DeactivateSuperUserRequest{
		Id:        id,
		IsActive:  isActive,
		UpdatedBy: updatedBy,
	})
	return err
}

func (a *grpcServiceAdapter) DeleteSuperUser(ctx context.Context, id int64) error {
	_, err := a.client.DeleteSuperUser(ctx, &superuserpb.DeleteSuperUserRequest{Id: id})
	return err
}
