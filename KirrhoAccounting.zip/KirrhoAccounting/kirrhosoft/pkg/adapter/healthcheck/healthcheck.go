package healthcheck

import (
	"context"
	"fmt"

	healthpb "KirrhoAccounting/kirrhosoft/pb/healthcheck"
)

type GRPCHealthAdapter struct {
	client healthpb.SystemHealthClient
}

func NewGRPCHealthAdapter(client healthpb.SystemHealthClient) *GRPCHealthAdapter {
	return &GRPCHealthAdapter{client: client}
}

func (a *GRPCHealthAdapter) GetSystemHealth(ctx context.Context) (map[string]interface{}, error) {
	res, err := a.client.GetHealthInfo(ctx, &healthpb.HealthRequest{})
	if err != nil {
		return nil, fmt.Errorf("failed to get system healthcheck: %w", err)
	}

	data := map[string]interface{}{
		"system":             res.System,
		"node_name":          res.NodeName,
		"boot_time":          res.BootTime,
		"server_start_time":  res.ServerStartTime,
		"server_uptime":      res.ServerUptime,
		"last_shutdown_time": res.LastShutdownTime,
		"disk_used_percent":  res.DiskUsedPercent,
		"disk_total_gb":      res.DiskTotalGb,
		"disk_used_gb":       res.DiskUsedGb,
		"disk_free_gb":       res.DiskFreeGb,
		"database_size":      res.DatabaseSize,
	}

	return data, nil
}
