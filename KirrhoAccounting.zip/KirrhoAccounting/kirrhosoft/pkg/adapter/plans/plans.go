package plans

import (
	"context"
	"fmt"

	plansHandler "KirrhoAccounting/kirrhosoft/handlers/plans"
	planModels "KirrhoAccounting/kirrhosoft/models/plans"
	planspb "KirrhoAccounting/kirrhosoft/pb/plans"

	"google.golang.org/protobuf/types/known/structpb"
)

type GRPCPlansAdapter struct {
	client planspb.PlanServiceClient
}

func NewGRPCServiceAdapter(client planspb.PlanServiceClient) planModels.Service {
	return &GRPCPlansAdapter{client: client}
}

func (a *GRPCPlansAdapter) CreatePlan(ctx context.Context, p *planModels.Plan) (*planModels.Plan, error) {
	var featuresStruct *structpb.Struct
	if p.Features != nil {
		featuresStruct, _ = structpb.NewStruct(p.Features)
	}

	req := &planspb.CreatePlanRequest{
		Code:           p.Code,
		Name:           p.Name,
		Description:    p.Description,
		Price:          p.Price,
		Currency:       p.Currency,
		Features:       featuresStruct,
		TrialDays:      int32(p.TrialDays),
		MaxUsers:       int32(p.MaxUsers),
		StorageLimitGb: int32(p.StorageLimitGB),
		ApiLimit:       int32(p.APILimit),
		IsActive:       p.IsActive,
		IsPopular:      p.IsPopular,
		SortOrder:      int32(p.SortOrder),
		CreatedBy:      p.CreatedBy,
	}

	res, err := a.client.CreatePlan(ctx, req)
	if err != nil {
		return nil, fmt.Errorf("failed to create plan: %w", err)
	}

	return plansHandler.MapProtoToPlan(res.Plan), nil
}

func (a *GRPCPlansAdapter) GetPlan(ctx context.Context, id int64) (*planModels.Plan, error) {
	res, err := a.client.GetPlan(ctx, &planspb.GetPlanRequest{Id: id})
	if err != nil {
		return nil, fmt.Errorf("failed to fetch plan: %w", err)
	}
	if res.Plan == nil {
		return nil, fmt.Errorf("plan not found")
	}
	return plansHandler.MapProtoToPlan(res.Plan), nil
}

func (a *GRPCPlansAdapter) ListPlans(ctx context.Context) ([]*planModels.Plan, error) {
	res, err := a.client.ListPlans(ctx, &planspb.ListPlansRequest{})
	if err != nil {
		return nil, fmt.Errorf("failed to list plans: %w", err)
	}

	result := make([]*planModels.Plan, 0, len(res.Plans))
	for _, p := range res.Plans {
		result = append(result, plansHandler.MapProtoToPlan(p))
	}
	return result, nil
}

func (a *GRPCPlansAdapter) UpdatePlan(ctx context.Context, p *planModels.Plan) error {
	var featuresStruct *structpb.Struct
	if p.Features != nil {
		featuresStruct, _ = structpb.NewStruct(p.Features)
	}

	req := &planspb.UpdatePlanRequest{
		Id:             p.ID,
		Code:           p.Code,
		Name:           p.Name,
		Description:    p.Description,
		Price:          p.Price,
		Currency:       p.Currency,
		Features:       featuresStruct,
		TrialDays:      int32(p.TrialDays),
		MaxUsers:       int32(p.MaxUsers),
		StorageLimitGb: int32(p.StorageLimitGB),
		ApiLimit:       int32(p.APILimit),
		IsActive:       p.IsActive,
		IsPopular:      p.IsPopular,
		SortOrder:      int32(p.SortOrder),
		UpdatedBy:      p.UpdatedBy,
	}

	_, err := a.client.UpdatePlan(ctx, req)
	if err != nil {
		return fmt.Errorf("failed to update plan: %w", err)
	}
	return nil
}

func (a *GRPCPlansAdapter) PartialUpdatePlan(ctx context.Context, id int64, updates map[string]interface{}) (*planModels.Plan, error) {
	var updatesStruct *structpb.Struct
	if updates != nil {
		updatesStruct, _ = structpb.NewStruct(updates)
	}

	res, err := a.client.PartialUpdatePlan(ctx, &planspb.PartialUpdatePlanRequest{
		Id:      id,
		Updates: updatesStruct,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to partially update plan: %w", err)
	}
	if res.Plan == nil {
		return nil, fmt.Errorf("no plan returned from update")
	}

	return plansHandler.MapProtoToPlan(res.Plan), nil
}

func (a *GRPCPlansAdapter) ActivatePlan(ctx context.Context, id int64, updatedBy string) error {
	res, err := a.client.ActivatePlan(ctx, &planspb.ActivatePlanRequest{
		Id:        id,
		UpdatedBy: updatedBy,
	})
	if err != nil {
		return fmt.Errorf("failed to activate plan: %w", err)
	}
	if res.Plan == nil {
		return fmt.Errorf("no plan returned after activation")
	}
	return nil
}

func (a *GRPCPlansAdapter) DeactivatePlan(ctx context.Context, id int64, updatedBy string) error {
	res, err := a.client.DeactivatePlan(ctx, &planspb.DeactivatePlanRequest{
		Id:        id,
		UpdatedBy: updatedBy,
	})
	if err != nil {
		return fmt.Errorf("failed to deactivate plan: %w", err)
	}
	if res.Plan == nil {
		return fmt.Errorf("no plan returned after deactivation")
	}
	return nil
}

func (a *GRPCPlansAdapter) DeletePlan(ctx context.Context, id int64) error {
	_, err := a.client.DeletePlan(ctx, &planspb.DeletePlanRequest{Id: id})
	if err != nil {
		return fmt.Errorf("failed to delete plan: %w", err)
	}
	return nil
}
