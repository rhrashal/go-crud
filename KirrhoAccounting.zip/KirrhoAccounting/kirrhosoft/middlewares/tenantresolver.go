package middlewares

import (
	"context"
	"net/http"
	"strings"
)

type tenantKeyType string

const TenantKey tenantKeyType = "tenants"

func TenantResolver(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		host := r.Host

		hostParts := strings.Split(host, ":")
		domain := hostParts[0]

		parts := strings.Split(domain, ".")
		var tenant string

		if domain == "localhost" {
			tenant = "public"
		} else if len(parts) >= 2 && parts[len(parts)-1] == "localhost" {
			tenant = parts[0]
		} else {
			http.Error(w, "invalid tenants host", http.StatusBadRequest)
			return
		}

		ctx := context.WithValue(r.Context(), TenantKey, tenant)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}
