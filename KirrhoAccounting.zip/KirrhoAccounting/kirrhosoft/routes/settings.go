package routes

import (
	"net/http"

	settingshttp "KirrhoAccounting/kirrhosoft/api/http/settings"

	"github.com/gorilla/mux"
)

func RegisterSettingRoutes(r *mux.Router, handler *settingshttp.Handler) {

	r.HandleFunc("/settings/create", handler.CreateSetting).Methods(http.MethodPost)
	r.HandleFunc("/settings/list", handler.ListSetting).Methods(http.MethodGet)

	// Dynamic routes after
	r.HandleFunc("/settings/{id}", handler.GetSetting).Methods(http.MethodGet)
	r.HandleFunc("/settings/{id}/partial/update", handler.PartialUpdateSetting).Methods(http.MethodPatch)
	r.HandleFunc("/settings/{id}/delete", handler.DeleteSetting).Methods(http.MethodDelete)
}
