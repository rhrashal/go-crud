package routes

import (
	"KirrhoAccounting/kirrhosoft/di"
	"KirrhoAccounting/kirrhosoft/handlers/home"
	"KirrhoAccounting/kirrhosoft/handlers/tenants"

	"github.com/gorilla/mux"
)

func RegisterAllKirrhosoftRoutes(r *mux.Router, container *di.Container) {

	r.HandleFunc("/", home.PingHandler).Methods("GET")
	r.HandleFunc("/tenants-info", tenants.HTTPTenantHandler).Methods("GET")

	RegisterSuperUserRoutes(r, container.SuperuserHTTPHandler)
	RegisterPlanRoutes(r, container.PlansHTTPHandler)
	RegisterTenantRoutes(r, container.TenantsHTTPHandler)
	RegisterSubscriptionRoutes(r, container.SubscriptionsHTTPHandler)
	RegisterHealthRoutes(r, container.HealthHTTPHandler)
	RegisterSettingRoutes(r, container.SettingsHTTPHandler)

}
