package routes

import (
	"net/http"

	subshttp "KirrhoAccounting/kirrhosoft/api/http/subscriptions"

	"github.com/gorilla/mux"
)

func RegisterSubscriptionRoutes(r *mux.Router, handler *subshttp.Handler) {
	// Specific routes first (to avoid being shadowed by dynamic {id} routes)
	r.HandleFunc("/subscriptions/create", handler.CreateSubscription).Methods(http.MethodPost)
	r.HandleFunc("/subscriptions/list", handler.ListSubscriptions).Methods(http.MethodGet)

	// Dynamic routes (for single subscription operations)
	r.HandleFunc("/subscriptions/{id}", handler.GetSubscription).Methods(http.MethodGet)
	r.HandleFunc("/subscriptions/{id}/partial/update", handler.PartialUpdateSubscription).Methods(http.MethodPatch)
	r.HandleFunc("/subscriptions/{id}/delete", handler.DeleteSubscription).Methods(http.MethodDelete)
}
