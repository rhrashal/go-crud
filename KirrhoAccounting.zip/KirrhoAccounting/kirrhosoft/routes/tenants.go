package routes

import (
	"net/http"

	tenantshttp "KirrhoAccounting/kirrhosoft/api/http/tenants"

	"github.com/gorilla/mux"
)

func RegisterTenantRoutes(r *mux.Router, handler *tenantshttp.Handler) {

	r.HandleFunc("/tenants/create", handler.CreateTenant).Methods(http.MethodPost)
	r.HandleFunc("/tenants/list", handler.ListTenants).Methods(http.MethodGet)

	// Dynamic routes after
	r.HandleFunc("/tenants/{id}", handler.GetTenant).Methods(http.MethodGet)
	r.HandleFunc("/tenants/{id}/partial/update", handler.PartialUpdateTenant).Methods(http.MethodPatch)
	r.HandleFunc("/tenants/{id}/delete", handler.DeleteTenant).Methods(http.MethodDelete)
}
