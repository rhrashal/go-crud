package routes

import (
	"net/http"

	healthhttp "KirrhoAccounting/kirrhosoft/api/http/healthcheck"

	"github.com/gorilla/mux"
)

func RegisterHealthRoutes(r *mux.Router, handler *healthhttp.Handler) {
	r.HandleFunc("/health", handler.GetSystemHealth).Methods(http.MethodGet)
}
