package routes

import (
	"net/http"

	superuserhttp "KirrhoAccounting/kirrhosoft/api/http/superuser"

	"github.com/gorilla/mux"
)

func RegisterSuperUserRoutes(r *mux.Router, handler *superuserhttp.Handler) {
	// Specific routes first
	r.HandleFunc("/superusers/register", handler.RegisterSuperUser).Methods(http.MethodPost)
	r.HandleFunc("/superusers/login", handler.LoginSuperUser).Methods(http.MethodPost)
	r.HandleFunc("/superusers/list", handler.ListSuperUsers).Methods(http.MethodGet)

	// Dynamic routes after
	r.HandleFunc("/superusers/{id}", handler.GetSuperUser).Methods(http.MethodGet)
	r.HandleFunc("/superusers/{id}/update", handler.UpdateSuperUser).Methods(http.MethodPut)
	r.HandleFunc("/superusers/{id}/partial/update", handler.PartialUpdateSuperUser).Methods(http.MethodPatch)
	r.HandleFunc("/superusers/{id}/password/update", handler.UpdateSuperUserPassword).Methods(http.MethodPut, http.MethodPatch)
	r.HandleFunc("/superusers/{id}/deactivate", handler.DeactivateSuperUser).Methods(http.MethodPatch)
	r.HandleFunc("/superusers/{id}/delete", handler.DeleteSuperUser).Methods(http.MethodDelete)
}
