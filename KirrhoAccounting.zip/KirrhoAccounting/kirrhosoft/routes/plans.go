package routes

import (
	"net/http"

	planshttp "KirrhoAccounting/kirrhosoft/api/http/plans"

	"github.com/gorilla/mux"
)

func RegisterPlanRoutes(r *mux.Router, handler *planshttp.Handler) {
	// Specific routes first
	r.HandleFunc("/plans/create", handler.CreatePlan).Methods(http.MethodPost)
	r.HandleFunc("/plans/list", handler.ListPlans).Methods(http.MethodGet)

	// Dynamic routes after
	r.HandleFunc("/plans/{id}", handler.GetPlan).Methods(http.MethodGet)
	r.HandleFunc("/plans/{id}/partial/update", handler.PartialUpdatePlan).Methods(http.MethodPatch)
	r.HandleFunc("/plans/{id}/delete", handler.DeletePlan).Methods(http.MethodDelete)
}
