package superuser

import (
	"KirrhoAccounting/kirrhosoft/models/superuser"
	"KirrhoAccounting/pkg/basemodel"
	"KirrhoAccounting/pkg/convert"
	"KirrhoAccounting/pkg/messages"
	"KirrhoAccounting/pkg/persistence"
	"database/sql"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"
)

var (
	ErrNotFound      = errors.New("not found")
	ErrAlreadyExists = errors.New("already exists")
)

type postgresUserRepo struct {
	helper *persistence.SqlHelper
}

func New(db *sql.DB) superuser.Repository {
	return &postgresUserRepo{helper: persistence.NewSqlHelper(db)}
}

func (r *postgresUserRepo) Create(u *superuser.SuperUser) (*superuser.SuperUser, error) {
	query := `
		INSERT INTO super_users (
			email, password_hash, role, is_active, profile_picture,
			created_at, updated_at, created_by, updated_by
		)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
		RETURNING id;
	`

	now := time.Now().UTC()
	u.CreatedAt = now
	u.UpdatedAt = now

	resp := r.helper.Select(query,
		u.Email,
		u.PasswordHash,
		u.Role,
		u.IsActive,
		u.ProfilePicture,
		u.CreatedAt,
		u.UpdatedAt,
		u.CreatedBy,
		u.UpdatedBy,
	)

	if !resp.IsSuccess {
		if resp.Message == "duplicate key" {
			return nil, ErrAlreadyExists
		}
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows, ok := resp.Data.([]map[string]interface{})
	if !ok || len(rows) == 0 {
		return nil, fmt.Errorf("failed to retrieve inserted users ID")
	}

	u.ID = convert.SafeInt64(rows[0]["id"])
	return u, nil
}

func (r *postgresUserRepo) FindByEmail(email string) (*superuser.SuperUser, error) {
	query := `SELECT * FROM super_users WHERE email=$1`
	resp := r.helper.Select(query, email)
	if !resp.IsSuccess {
		if resp.Message == "no data found" {
			return nil, nil
		}
		return nil, fmt.Errorf("%s", resp.Message)
	}
	rows := resp.Data.([]map[string]interface{})
	if len(rows) == 0 {
		return nil, nil
	}
	return mapToUser(rows[0]), nil
}

func (r *postgresUserRepo) FindByID(id int64) (*superuser.SuperUser, error) {
	query := `SELECT * FROM super_users WHERE id=$1`
	resp := r.helper.Select(query, id)
	if !resp.IsSuccess {
		if resp.Message == "no data found" {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("%s", resp.Message)
	}
	rows := resp.Data.([]map[string]interface{})
	if len(rows) == 0 {
		return nil, ErrNotFound
	}
	return mapToUser(rows[0]), nil
}

func (r *postgresUserRepo) FindAll() ([]*superuser.SuperUser, error) {
	query := `SELECT * FROM super_users`
	resp := r.helper.Select(query)

	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows, ok := resp.Data.([]map[string]interface{})
	if !ok || len(rows) == 0 {
		return []*superuser.SuperUser{}, nil
	}

	users := make([]*superuser.SuperUser, 0, len(rows))
	for _, row := range rows {
		users = append(users, mapToUser(row))
	}
	return users, nil
}

func (r *postgresUserRepo) Update(u *superuser.SuperUser) error {
	query := `
		UPDATE super_users
		SET email=$1, role=$2, is_active=$3, profile_picture=$4, updated_at=$5, updated_by=$6
		WHERE id=$7`
	resp := r.helper.Execute(query, u.Email, u.Role, u.IsActive, u.ProfilePicture, time.Now().UTC(), u.UpdatedBy, u.ID)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}
	return nil
}

func (r *postgresUserRepo) PartialUpdate(id int64, updates map[string]interface{}) error {
	if len(updates) == 0 {
		return nil
	}

	existing, err := r.FindByID(id)
	if err != nil {
		return err
	}
	if existing == nil {
		return messages.NoDataFound
	}

	if _, ok := updates["profile_picture"]; ok {
		if existing.ProfilePicture != nil && *existing.ProfilePicture != "" {
			oldPath := filepath.Join("kirrhosoft", (*existing.ProfilePicture)[1:])
			_ = os.Remove(oldPath)
		}
	}

	allowed := map[string]bool{
		"email":           true,
		"password_hash":   true,
		"role":            true,
		"is_active":       true,
		"profile_picture": true,
		"updated_by":      true,
	}

	var setClauses []string
	var args []interface{}
	i := 1

	for field, value := range updates {
		if !allowed[field] {
			continue
		}
		setClauses = append(setClauses, fmt.Sprintf("%s = $%d", field, i))
		args = append(args, value)
		i++
	}

	if len(setClauses) == 0 {
		return nil
	}

	setClauses = append(setClauses, fmt.Sprintf("updated_at = $%d", i))
	args = append(args, time.Now().UTC())
	i++

	query := fmt.Sprintf(`UPDATE super_users SET %s WHERE id = $%d`,
		strings.Join(setClauses, ", "), i)
	args = append(args, id)

	resp := r.helper.Execute(query, args...)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}
	return nil
}

func (r *postgresUserRepo) UpdatePassword(id int64, newPasswordHash string, updatedBy string) error {
	query := `UPDATE super_users SET password_hash=$1, updated_at=$2, updated_by=$3 WHERE id=$4`
	resp := r.helper.Execute(query, newPasswordHash, time.Now().UTC(), updatedBy, id)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}
	return nil
}

func (r *postgresUserRepo) Deactivate(id int64, isActive bool, updatedBy string) error {
	query := `UPDATE super_users SET is_active=$2, updated_at=NOW(), updated_by=$3 WHERE id=$1`
	resp := r.helper.Execute(query, id, isActive, updatedBy)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}
	return nil
}

func (r *postgresUserRepo) Delete(id int64) error {
	existing, err := r.FindByID(id)
	if err != nil {
		return err
	}
	if existing != nil && existing.ProfilePicture != nil && *existing.ProfilePicture != "" {
		oldPath := filepath.Join("kirrhosoft", (*existing.ProfilePicture)[1:])
		_ = os.Remove(oldPath)
	}
	query := `DELETE FROM super_users WHERE id=$1`
	resp := r.helper.Execute(query, id)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}
	return nil
}

func mapToUser(row map[string]interface{}) *superuser.SuperUser {
	return &superuser.SuperUser{
		ID:             convert.SafeInt64(row["id"]),
		Email:          convert.SafeString(row["email"]),
		PasswordHash:   convert.SafeString(row["password_hash"]),
		Role:           convert.SafeString(row["role"]),
		IsActive:       convert.SafeBool(row["is_active"]),
		ProfilePicture: convert.SafeOptionalString(row["profile_picture"]),
		AuditFields: basemodel.AuditFields{
			CreatedAt: convert.SafeFormatAnyTime(row["created_at"]),
			UpdatedAt: convert.SafeFormatAnyTime(row["updated_at"]),
			CreatedBy: convert.SafeString(row["created_by"]),
			UpdatedBy: convert.SafeString(row["updated_by"]),
		},
	}
}
