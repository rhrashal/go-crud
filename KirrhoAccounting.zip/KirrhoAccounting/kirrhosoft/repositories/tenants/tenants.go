package tenants

import (
	mapper "KirrhoAccounting/kirrhosoft/handlers/tenants"
	tenantModels "KirrhoAccounting/kirrhosoft/models/tenants"
	"KirrhoAccounting/pkg/convert"
	"KirrhoAccounting/pkg/messages"
	"KirrhoAccounting/pkg/persistence"
	"database/sql"
	"encoding/json"
	"fmt"
	"strings"
	"time"
)

type Repository struct {
	helper *persistence.SqlHelper
}

func NewTenantsRepo(db *sql.DB) *Repository {
	return &Repository{helper: persistence.NewSqlHelper(db)}
}

func (r *Repository) Create(t *tenantModels.Tenant) (*tenantModels.Tenant, error) {
	query := `
		INSERT INTO tenants (
			name, domain, email, phone, country, industry, plan_id,
			schema_name, timezone, is_active, onboarding_completed,
			metadata, created_at, updated_at, created_by
		)
		VALUES (
			$1,$2,$3,$4,$5,$6,$7,
			$8,$9,$10,$11,
			$12,$13,$14,$15
		)
		RETURNING id;
	`

	resp := r.helper.Select(query,
		t.Name,
		t.Domain,
		t.Email,
		t.Phone,
		t.Country,
		t.Industry,
		t.PlanID,
		t.SchemaName,
		t.Timezone,
		t.IsActive,
		t.OnboardingCompleted,
		t.Metadata,
		t.CreatedAt,
		t.UpdatedAt,
		t.CreatedBy,
	)

	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows := resp.Data.([]map[string]interface{})
	if len(rows) > 0 {
		t.ID = convert.SafeInt64(rows[0]["id"])
	}

	return t, nil
}

func (r *Repository) FindByPK(id int64) (*tenantModels.Tenant, error) {
	query := `SELECT * FROM tenants WHERE id = $1`
	resp := r.helper.Select(query, id)
	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows, ok := resp.Data.([]map[string]interface{})
	if !ok || len(rows) == 0 {
		return nil, messages.NoDataFound
	}

	return mapper.MapRowToTenant(rows[0]), nil
}

func (r *Repository) FindAll() ([]*tenantModels.Tenant, error) {
	query := `SELECT * FROM tenants ORDER BY created_at DESC`
	resp := r.helper.Select(query)
	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows := resp.Data.([]map[string]interface{})
	tenants := make([]*tenantModels.Tenant, 0, len(rows))
	for _, row := range rows {
		tenants = append(tenants, mapper.MapRowToTenant(row))
	}
	return tenants, nil
}

func (r *Repository) PartialUpdate(id int64, updates map[string]interface{}) error {
	if len(updates) == 0 {
		return nil
	}

	allowed := map[string]bool{
		"name":                 true,
		"domain":               true,
		"email":                true,
		"phone":                true,
		"country":              true,
		"industry":             true,
		"plan_id":              true,
		"schema_name":          true,
		"timezone":             true,
		"is_active":            true,
		"onboarding_completed": true,
		"metadata":             true,
		"updated_by":           true,
	}

	var setClauses []string
	var args []interface{}
	i := 1

	for field, value := range updates {
		if !allowed[field] {
			continue
		}

		if field == "metadata" {
			switch v := value.(type) {
			case map[string]interface{}:
				b, _ := json.Marshal(v)
				value = string(b)
			}
		}

		setClauses = append(setClauses, fmt.Sprintf("%s = $%d", field, i))
		args = append(args, value)
		i++
	}

	if len(setClauses) == 0 {
		return nil
	}

	setClauses = append(setClauses, fmt.Sprintf("updated_at = $%d", i))
	args = append(args, time.Now().UTC())
	i++

	query := fmt.Sprintf(`UPDATE tenants SET %s WHERE id = $%d`,
		strings.Join(setClauses, ", "), i)
	args = append(args, id)

	resp := r.helper.Execute(query, args...)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}

	rows, ok := resp.Data.([]map[string]interface{})
	if !ok || len(rows) == 0 {
		return messages.NoDataFound
	}
	return nil
}

func (r *Repository) Delete(id int64) error {
	query := `DELETE FROM tenants WHERE id = $1`
	resp := r.helper.Execute(query, id)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}
	rows, ok := resp.Data.([]map[string]interface{})
	if !ok || len(rows) == 0 {
		return messages.NoDataFound
	}
	return nil
}
