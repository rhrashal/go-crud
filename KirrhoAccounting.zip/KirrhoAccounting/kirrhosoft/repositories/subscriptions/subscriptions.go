package subscriptions

import (
	mapper "KirrhoAccounting/kirrhosoft/handlers/subscriptions"
	subModels "KirrhoAccounting/kirrhosoft/models/subscriptions"
	"KirrhoAccounting/pkg/persistence"
	"database/sql"
	"fmt"
	"strings"
	"time"
)

type Repository struct {
	helper *persistence.SqlHelper
}

func NewSubscriptionsRepo(db *sql.DB) *Repository {
	return &Repository{helper: persistence.NewSqlHelper(db)}
}

func (r *Repository) Create(s *subModels.Subscription) (*subModels.Subscription, error) {
	query := `
		INSERT INTO subscriptions (
			tenant_id, plan_id, start_date, end_date, status,
			created_at, updated_at, created_by
		)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8);
	`

	resp := r.helper.Execute(query,
		s.TenantID, s.PlanID, s.StartDate, s.EndDate, s.Status,
		s.CreatedAt, s.UpdatedAt, s.CreatedBy,
	)

	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	return s, nil
}

func (r *Repository) FindByPK(id string) (*subModels.Subscription, error) {
	query := `SELECT * FROM subscriptions WHERE id=$1`
	resp := r.helper.Select(query, id)
	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows := resp.Data.([]map[string]interface{})
	if len(rows) == 0 {
		return nil, nil
	}

	return mapper.MapRowToSubscription(rows[0])
}

func (r *Repository) FindAll() ([]*subModels.Subscription, error) {
	query := `SELECT * FROM subscriptions`
	resp := r.helper.Select(query)
	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows := resp.Data.([]map[string]interface{})
	subsList := make([]*subModels.Subscription, 0, len(rows))
	for _, row := range rows {
		s, _ := mapper.MapRowToSubscription(row)
		subsList = append(subsList, s)
	}
	return subsList, nil
}

func (r *Repository) PartialUpdate(id string, updates map[string]interface{}) error {
	if len(updates) == 0 {
		return nil
	}

	allowed := map[string]bool{
		"status":     true,
		"end_date":   true,
		"updated_by": true,
	}

	var setClauses []string
	var args []interface{}
	i := 1

	for field, value := range updates {
		if !allowed[field] {
			continue
		}
		setClauses = append(setClauses, fmt.Sprintf("%s = $%d", field, i))
		args = append(args, value)
		i++
	}

	if len(setClauses) == 0 {
		return nil
	}

	setClauses = append(setClauses, fmt.Sprintf("updated_at = $%d", i))
	args = append(args, time.Now().UTC())
	i++

	query := fmt.Sprintf(`UPDATE subscriptions SET %s WHERE id = $%d`,
		strings.Join(setClauses, ", "), i)
	args = append(args, id)

	resp := r.helper.Execute(query, args...)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}

	return nil
}

func (r *Repository) Delete(id string) error {
	query := `DELETE FROM subscriptions WHERE id=$1`
	resp := r.helper.Execute(query, id)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}
	return nil
}
