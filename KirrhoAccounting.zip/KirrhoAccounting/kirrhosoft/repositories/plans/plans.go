package plans

import (
	plansHandler "KirrhoAccounting/kirrhosoft/handlers/plans"
	planModels "KirrhoAccounting/kirrhosoft/models/plans"
	"KirrhoAccounting/pkg/convert"
	"KirrhoAccounting/pkg/persistence"
	"database/sql"
	"encoding/json"
	"fmt"
	"strings"
	"time"
)

type Repository struct {
	helper *persistence.SqlHelper
}

func NewPlansRepo(db *sql.DB) *Repository {
	return &Repository{helper: persistence.NewSqlHelper(db)}
}

func (r *Repository) Create(p *planModels.Plan) (*planModels.Plan, error) {
	featuresJSON, err := json.Marshal(p.Features)
	if err != nil {
		return nil, fmt.Errorf("invalid features JSON: %w", err)
	}

	query := `
		INSERT INTO plans (
			code, name, description, price, currency, features, trial_days, max_users,
			storage_limit_gb, api_limit, is_active, is_popular, sort_order,
			created_at, updated_at, created_by, updated_by
		)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)
		RETURNING id;
	`

	now := time.Now().UTC()
	p.CreatedAt = now
	p.UpdatedAt = now

	resp := r.helper.Select(query,
		p.Code, p.Name, p.Description, p.Price, p.Currency, featuresJSON,
		p.TrialDays, p.MaxUsers, p.StorageLimitGB, p.APILimit,
		p.IsActive, p.IsPopular, p.SortOrder,
		p.CreatedAt, p.UpdatedAt, p.CreatedBy, p.UpdatedBy,
	)
	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows := resp.Data.([]map[string]interface{})
	if len(rows) > 0 {
		p.ID = convert.SafeInt64(rows[0]["id"])
	}

	return p, nil
}

func (r *Repository) FindByPK(pk int64) (*planModels.Plan, error) {
	query := `SELECT * FROM plans WHERE id = $1`
	resp := r.helper.Select(query, pk)
	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}
	rows := resp.Data.([]map[string]interface{})
	if len(rows) == 0 {
		return nil, nil
	}
	return plansHandler.MapRowToPlan(rows[0]), nil
}

func (r *Repository) FindAll() ([]*planModels.Plan, error) {
	query := `SELECT * FROM plans ORDER BY sort_order ASC`
	resp := r.helper.Select(query)
	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows := resp.Data.([]map[string]interface{})
	plansList := make([]*planModels.Plan, 0, len(rows))
	for _, row := range rows {
		p := plansHandler.MapRowToPlan(row)
		plansList = append(plansList, p)
	}
	return plansList, nil
}

func (r *Repository) PartialUpdate(id int64, updates map[string]interface{}) error {
	if len(updates) == 0 {
		return nil
	}

	allowed := map[string]bool{
		"code":             true,
		"name":             true,
		"description":      true,
		"price":            true,
		"currency":         true,
		"features":         true,
		"trial_days":       true,
		"max_users":        true,
		"storage_limit_gb": true,
		"api_limit":        true,
		"is_active":        true,
		"is_popular":       true,
		"sort_order":       true,
		"updated_by":       true,
	}

	var setClauses []string
	var args []interface{}
	i := 1

	for field, value := range updates {
		if !allowed[field] {
			continue
		}
		if field == "features" {
			bytes, err := json.Marshal(value)
			if err != nil {
				return fmt.Errorf("invalid JSON in features: %w", err)
			}
			value = string(bytes)
		}
		setClauses = append(setClauses, fmt.Sprintf("%s = $%d", field, i))
		args = append(args, value)
		i++
	}

	if len(setClauses) == 0 {
		return nil
	}

	setClauses = append(setClauses, fmt.Sprintf("updated_at = $%d", i))
	args = append(args, time.Now().UTC())
	i++

	query := fmt.Sprintf(`UPDATE plans SET %s WHERE id = $%d`,
		strings.Join(setClauses, ", "), i)
	args = append(args, id)

	resp := r.helper.Execute(query, args...)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}
	return nil
}

func (r *Repository) Delete(id int64) error {
	query := `DELETE FROM plans WHERE id = $1`
	resp := r.helper.Execute(query, id)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}
	return nil
}
