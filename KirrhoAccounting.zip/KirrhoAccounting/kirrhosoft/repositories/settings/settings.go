package settings

import (
	mapper "KirrhoAccounting/kirrhosoft/handlers/settings"
	settingModels "KirrhoAccounting/kirrhosoft/models/settings"
	"KirrhoAccounting/pkg/convert"
	"KirrhoAccounting/pkg/messages"
	"KirrhoAccounting/pkg/persistence"
	"database/sql"
	"encoding/json"
	"fmt"
	"strings"
	"time"
)

type Repository struct {
	helper *persistence.SqlHelper
}

func NewSettingsRepo(db *sql.DB) *Repository {
	return &Repository{helper: persistence.NewSqlHelper(db)}
}

func (r *Repository) Create(t *settingModels.Setting) (*settingModels.Setting, error) {
	query := `
			insert into settings (
								  tenant_id, "key", "value", value_type, is_encrypted,
								  created_at, updated_at, created_by,updated_by)
			values (
					$1,$2,$3,$4,$5,$6,$7,$8,$9
					) returning id;		
	`

	resp := r.helper.Select(query,
		t.TenantID,
		t.Key,
		t.Value,
		t.ValueType,
		t.IsEncrypted,
		t.CreatedAt,
		t.UpdatedAt,
		t.CreatedBy,
		t.UpdatedBy,
	)

	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows := resp.Data.([]map[string]interface{})
	if len(rows) > 0 {
		t.ID = convert.SafeInt64(rows[0]["id"])
	}

	return t, nil
}

func (r *Repository) FindByPK(id int64) (*settingModels.Setting, error) {
	query := `SELECT * FROM settings WHERE id = $1`
	resp := r.helper.Select(query, id)
	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows, ok := resp.Data.([]map[string]interface{})
	if !ok || len(rows) == 0 {
		return nil, messages.NoDataFound
	}

	return mapper.MapRowToSetting(rows[0]), nil
}

func (r *Repository) FindAll() ([]*settingModels.Setting, error) {
	query := `SELECT * FROM settings ORDER BY created_at DESC`
	resp := r.helper.Select(query)
	if !resp.IsSuccess {
		return nil, fmt.Errorf("%s", resp.Message)
	}

	rows := resp.Data.([]map[string]interface{})
	settings := make([]*settingModels.Setting, 0, len(rows))
	for _, row := range rows {
		settings = append(settings, mapper.MapRowToSetting(row))
	}
	return settings, nil
}

func (r *Repository) PartialUpdate(id int64, updates map[string]interface{}) error {
	if len(updates) == 0 {
		return nil
	}

	allowed := map[string]bool{
		"tenant_id":    true,
		"key":          true,
		"value":        true,
		"value_type":   true,
		"is_encrypted": true,
		"updated_by":   true,
	}

	var setClauses []string
	var args []interface{}
	i := 1

	for field, value := range updates {
		if !allowed[field] {
			continue
		}

		if field == "metadata" {
			switch v := value.(type) {
			case map[string]interface{}:
				b, _ := json.Marshal(v)
				value = string(b)
			}
		}

		setClauses = append(setClauses, fmt.Sprintf("%s = $%d", field, i))
		args = append(args, value)
		i++
	}

	if len(setClauses) == 0 {
		return nil
	}

	setClauses = append(setClauses, fmt.Sprintf("updated_at = $%d", i))
	args = append(args, time.Now().UTC())
	i++

	query := fmt.Sprintf(`UPDATE settings SET %s WHERE id = $%d`,
		strings.Join(setClauses, ", "), i)
	args = append(args, id)

	resp := r.helper.Execute(query, args...)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}

	rows, ok := resp.Data.([]map[string]interface{})
	if !ok || len(rows) == 0 {
		return messages.NoDataFound
	}
	return nil
}

func (r *Repository) Delete(id int64) error {
	query := `DELETE FROM settings WHERE id = $1`
	resp := r.helper.Execute(query, id)
	if !resp.IsSuccess {
		return fmt.Errorf("%s", resp.Message)
	}
	rows, ok := resp.Data.([]map[string]interface{})
	if !ok || len(rows) == 0 {
		return messages.NoDataFound
	}
	return nil
}
