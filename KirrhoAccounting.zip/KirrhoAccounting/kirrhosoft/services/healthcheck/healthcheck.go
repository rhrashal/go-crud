package healthcheck

import (
	"time"

	"github.com/shirou/gopsutil/v3/disk"
	"github.com/shirou/gopsutil/v3/host"

	model "KirrhoAccounting/kirrhosoft/models/healthcheck"
)

type Service struct {
	startTime time.Time
}

func NewService() *Service {
	return &Service{startTime: time.Now()}
}

func (s *Service) GetSystemHealth() (*model.SystemHealth, error) {
	info, err := host.Info()
	if err != nil {
		return nil, err
	}

	diskUsage, err := disk.Usage("/")
	if err != nil {
		return nil, err
	}

	uptime := time.Since(s.startTime).Round(time.Second)

	return &model.SystemHealth{
		System:           info.OS,
		NodeName:         info.Hostname,
		BootTime:         time.Unix(int64(info.BootTime), 0).Format(time.RFC3339),
		ServerStartTime:  s.startTime.Format(time.RFC3339Nano),
		ServerUptime:     uptime.String(),
		LastShutdownTime: time.Now().Add(-uptime).Format(time.RFC3339Nano),
		DiskUsedPercent:  diskUsage.UsedPercent,
		DiskTotalGb:      float64(diskUsage.Total) / (1024 * 1024 * 1024),
		DiskUsedGb:       float64(diskUsage.Used) / (1024 * 1024 * 1024),
		DiskFreeGb:       float64(diskUsage.Free) / (1024 * 1024 * 1024),
		DatabaseSize:     9626403,
	}, nil
}
