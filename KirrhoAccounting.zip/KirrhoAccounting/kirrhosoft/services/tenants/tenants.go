package tenants

import (
	"context"
	"errors"
	"time"

	tenantModels "KirrhoAccounting/kirrhosoft/models/tenants"
	tenantRepo "KirrhoAccounting/kirrhosoft/repositories/tenants"
)

const (
	ErrTenantIDRequired   = "tenants id is required"
	ErrTenantNameRequired = "tenants name is required"
)

type Service struct {
	Repo *tenantRepo.Repository
}

func NewTenantService(repo *tenantRepo.Repository) *Service {
	return &Service{Repo: repo}
}

func (s *Service) CreateTenant(ctx context.Context, t *tenantModels.Tenant) (*tenantModels.Tenant, error) {
	if t == nil {
		return nil, errors.New("tenants cannot be nil")
	}

	if t.Name == "" {
		return nil, errors.New(ErrTenantNameRequired)
	}

	now := time.Now().UTC()
	t.CreatedAt = now
	t.UpdatedAt = now

	createdTenant, err := s.Repo.Create(t)
	if err != nil {
		return nil, err
	}

	return createdTenant, nil
}

func (s *Service) GetTenant(ctx context.Context, id int64) (*tenantModels.Tenant, error) {
	if id <= 0 {
		return nil, errors.New(ErrTenantIDRequired)
	}
	return s.Repo.FindByPK(id)
}

func (s *Service) ListTenants(ctx context.Context) ([]*tenantModels.Tenant, error) {
	return s.Repo.FindAll()
}

func (s *Service) PartialUpdateTenant(ctx context.Context, id int64, updates map[string]interface{}) (*tenantModels.Tenant, error) {
	if id <= 0 {
		return nil, errors.New(ErrTenantIDRequired)
	}

	if len(updates) == 0 {
		return s.Repo.FindByPK(id)
	}

	updates["updated_at"] = time.Now().UTC()

	if err := s.Repo.PartialUpdate(id, updates); err != nil {
		return nil, err
	}

	return s.Repo.FindByPK(id)
}

func (s *Service) DeleteTenant(ctx context.Context, id int64) error {
	if id <= 0 {
		return errors.New(ErrTenantIDRequired)
	}
	return s.Repo.Delete(id)
}
