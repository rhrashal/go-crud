package settings

import (
	settingModels "KirrhoAccounting/kirrhosoft/models/settings"
	settingRepo "KirrhoAccounting/kirrhosoft/repositories/settings"
	"context"
	"errors"
	"time"
)

const (
	ErrSettingIDRequired  = "setting id is required"
	ErrSettingKeyRequired = "settings name is required"
)

type Service struct {
	Repo *settingRepo.Repository
}

//func (s *Service) ListSetting(ctx context.Context) ([]*settingModels.Setting, error) {
//	//TODO implement me
//	panic("implement me")
//}

func NewSettingService(repo *settingRepo.Repository) *Service {
	return &Service{Repo: repo}
}

func (s *Service) CreateSetting(ctx context.Context, t *settingModels.Setting) (*settingModels.Setting, error) {
	if t == nil {
		return nil, errors.New("setting cannot be nil")
	}
	if t.Key == "" {
		return nil, errors.New(ErrSettingKeyRequired)
	}
	now := time.Now().UTC()
	t.CreatedAt = now
	t.UpdatedAt = now
	createdSetting, err := s.Repo.Create(t)
	if err != nil {
		return nil, err
	}

	return createdSetting, nil
}

func (s *Service) GetSetting(ctx context.Context, id int64) (*settingModels.Setting, error) {
	if id <= 0 {
		return nil, errors.New(ErrSettingIDRequired)
	}

	return s.Repo.FindByPK(id)
}

func (s *Service) ListSetting(ctx context.Context) ([]*settingModels.Setting, error) {
	return s.Repo.FindAll()
}

func (s *Service) PartialUpdateSetting(ctx context.Context, id int64, updates map[string]interface{}) (*settingModels.Setting, error) {
	if id <= 0 {
		return nil, errors.New(ErrSettingIDRequired)
	}
	if len(updates) == 0 {
		return s.Repo.FindByPK(id)
	}
	updates["updated_at"] = time.Now().UTC()
	if err := s.Repo.PartialUpdate(id, updates); err != nil {
		return nil, err
	}
	return s.Repo.FindByPK(id)
}

func (s *Service) DeleteSetting(ctx context.Context, id int64) error {
	if id <= 0 {
		return errors.New(ErrSettingIDRequired)
	}
	return s.Repo.Delete(id)
}
