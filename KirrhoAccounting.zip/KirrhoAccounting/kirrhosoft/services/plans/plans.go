package plans

import (
	"context"
	"errors"
	"fmt"
	"time"

	planModels "KirrhoAccounting/kirrhosoft/models/plans"
	planRepo "KirrhoAccounting/kirrhosoft/repositories/plans"
)

type Service struct {
	Repo *planRepo.Repository
}

func NewPlanService(repo *planRepo.Repository) *Service {
	return &Service{Repo: repo}
}

func (s *Service) CreatePlan(ctx context.Context, p *planModels.Plan) (*planModels.Plan, error) {
	if p.Name == "" {
		return nil, errors.New("plan name is required")
	}
	if p.Price <= 0 {
		return nil, errors.New("plan price must be greater than zero")
	}
	if p.Code == "" {
		return nil, errors.New("plan code is required")
	}
	if p.Currency == "" {
		p.Currency = "USD"
	}

	now := time.Now().UTC()
	p.CreatedAt = now
	p.UpdatedAt = now

	return s.Repo.Create(p)
}

func (s *Service) GetPlan(ctx context.Context, id int64) (*planModels.Plan, error) {
	return s.Repo.FindByPK(id)
}

func (s *Service) ListPlans(ctx context.Context) ([]*planModels.Plan, error) {
	return s.Repo.FindAll()
}

func (s *Service) PartialUpdatePlan(ctx context.Context, id int64, updates map[string]interface{}) (*planModels.Plan, error) {
	if id == 0 {
		return nil, errors.New("plan ID is required")
	}
	updates["updated_at"] = time.Now().UTC()

	if err := s.Repo.PartialUpdate(id, updates); err != nil {
		return nil, err
	}

	return s.Repo.FindByPK(id)
}

func (s *Service) ActivatePlan(ctx context.Context, id int64, updatedBy string) error {
	updates := map[string]interface{}{
		"is_active":  true,
		"updated_at": time.Now().UTC(),
		"updated_by": updatedBy,
	}
	return s.Repo.PartialUpdate(id, updates)
}

func (s *Service) DeactivatePlan(ctx context.Context, id int64, updatedBy string) error {
	updates := map[string]interface{}{
		"is_active":  false,
		"updated_at": time.Now().UTC(),
		"updated_by": updatedBy,
	}
	return s.Repo.PartialUpdate(id, updates)
}

func (s *Service) DeletePlan(ctx context.Context, id int64) error {
	if id == 0 {
		return fmt.Errorf("invalid plan ID")
	}
	return s.Repo.Delete(id)
}
