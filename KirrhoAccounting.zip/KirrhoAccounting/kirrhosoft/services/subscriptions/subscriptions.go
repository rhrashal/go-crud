package subscriptions

import (
	tenantRepo "KirrhoAccounting/kirrhosoft/repositories/tenants"
	userRepo "KirrhoAccounting/users/repositories/users"
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	tenantMigrate "KirrhoAccounting/database/migrate"
	subModels "KirrhoAccounting/kirrhosoft/models/subscriptions"
	subRepo "KirrhoAccounting/kirrhosoft/repositories/subscriptions"
)

const (
	ErrNilSubscription = "subscription cannot be nil"
	ErrMissingSubID    = "subscription id is required"
)

type Service struct {
	DB               *sql.DB
	subscriptionRepo *subRepo.Repository
	tenantRepo       *tenantRepo.Repository
	userRepo         *userRepo.Repository
}

func NewSubscriptionService(db *sql.DB, subRepository *subRepo.Repository, tenantRepository *tenantRepo.Repository, userRepository *userRepo.Repository) *Service {
	return &Service{
		DB:               db,
		subscriptionRepo: subRepository,
		tenantRepo:       tenantRepository,
		userRepo:         userRepository,
	}
}

func (s *Service) CreateSubscription(ctx context.Context, sub *subModels.Subscription) (*subModels.Subscription, error) {
	if sub == nil {
		return nil, errors.New(ErrNilSubscription)
	}
	now := time.Now().UTC()
	sub.CreatedAt = now
	sub.UpdatedAt = now
	if sub.StartDate.IsZero() {
		sub.StartDate = now
	}

	createdSub, err := s.subscriptionRepo.Create(sub)
	if err != nil {
		return nil, fmt.Errorf("failed to create subscription: %w", err)
	}
	tenant, err := s.tenantRepo.FindByPK(sub.TenantID)
	if err != nil {
		return nil, fmt.Errorf("failed to get tenants: %w", err)
	}
	if tenant == nil {
		return nil, fmt.Errorf("tenants not found for ID %s", sub.TenantID)
	}
	if tenant.SchemaName == nil || *tenant.SchemaName == "" {
		return nil, fmt.Errorf("tenants schema name is missing")
	}

	schema := *tenant.SchemaName
	migrator := tenantMigrate.NewTenantMigrator(s.DB)

	if err := migrator.CreateSchemaAndTables(schema); err != nil {
		return nil, fmt.Errorf("failed to create schema and tables for %q: %w", schema, err)
	}
	seeder := tenantMigrate.TenantSeeder{
		DB:       s.DB,
		UserRepo: s.userRepo,
	}

	if _, err := seeder.SeedDefaults(ctx, tenant); err != nil {
		return nil, fmt.Errorf("failed to seed tenants data for schema %q: %w", schema, err)
	}
	return createdSub, nil
}

func (s *Service) GetSubscription(ctx context.Context, id string) (*subModels.Subscription, error) {
	if id == "" {
		return nil, errors.New(ErrMissingSubID)
	}
	return s.subscriptionRepo.FindByPK(id)
}

func (s *Service) ListSubscriptions(ctx context.Context) ([]*subModels.Subscription, error) {
	return s.subscriptionRepo.FindAll()
}

func (s *Service) PartialUpdateSubscription(ctx context.Context, id string, updates map[string]interface{}) (*subModels.Subscription, error) {
	if id == "" {
		return nil, errors.New(ErrMissingSubID)
	}
	if len(updates) == 0 {
		return s.subscriptionRepo.FindByPK(id)
	}

	updates["updated_at"] = time.Now().UTC()

	if err := s.subscriptionRepo.PartialUpdate(id, updates); err != nil {
		return nil, err
	}

	return s.subscriptionRepo.FindByPK(id)
}

func (s *Service) DeleteSubscription(ctx context.Context, id string) error {
	if id == "" {
		return errors.New(ErrMissingSubID)
	}
	return s.subscriptionRepo.Delete(id)
}
