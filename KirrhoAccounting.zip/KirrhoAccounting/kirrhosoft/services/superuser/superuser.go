package superuser

import (
	"KirrhoAccounting/kirrhosoft/pkg/auth"
	"context"
	"errors"
	"time"

	core "KirrhoAccounting/kirrhosoft/models/superuser"
)

type service struct {
	repo core.Repository
}

func New(repo core.Repository) core.Service {
	return &service{repo: repo}
}

func (s *service) RegisterSuperUser(ctx context.Context, u *core.SuperUser, plainPassword string) (*core.SuperUser, error) {
	existing, _ := s.repo.FindByEmail(u.Email)
	if existing != nil {
		return nil, errors.New("superuser already exists")
	}

	if err := auth.ValidatePasswordStrength(plainPassword); err != nil {
		return nil, err
	}

	hashedPass, err := auth.Hash(plainPassword)
	if err != nil {
		return nil, err
	}

	now := time.Now().UTC()
	u.PasswordHash = hashedPass
	u.IsActive = true
	u.CreatedAt = now

	if u.ProfilePicture == nil {
		empty := ""
		u.ProfilePicture = &empty
	}

	return s.repo.Create(u)
}

func (s *service) GetSuperUser(ctx context.Context, id int64) (*core.SuperUser, error) {
	return s.repo.FindByID(id)
}

func (s *service) ListSuperUsers(ctx context.Context) ([]*core.SuperUser, error) {
	return s.repo.FindAll()
}

func (s *service) UpdateSuperUser(ctx context.Context, u *core.SuperUser) error {
	u.UpdatedAt = time.Now().UTC()
	return s.repo.Update(u)
}

func (s *service) PartialUpdateSuperUser(ctx context.Context, id int64, updates map[string]interface{}) error {
	updates["updated_at"] = time.Now().UTC()
	err := s.repo.PartialUpdate(id, updates)
	if err != nil {
		return err
	}

	return nil
}

func (s *service) UpdateSuperUserPassword(ctx context.Context, id int64, oldPassword, newPassword, updatedBy string) error {
	u, err := s.repo.FindByID(id)
	if err != nil {
		return errors.New("database error")
	}
	if u == nil {
		return errors.New("superuser not found")
	}

	if err := auth.Verify(u.PasswordHash, oldPassword); err != nil {
		return errors.New("invalid old password")
	}

	if err := auth.ValidatePasswordStrength(newPassword); err != nil {
		return err
	}

	hashedPass, err := auth.Hash(newPassword)
	if err != nil {
		return err
	}
	return s.repo.UpdatePassword(id, hashedPass, updatedBy)
}

func (s *service) DeactivateSuperUser(ctx context.Context, id int64, isActive bool, updatedBy string) error {
	users, err := s.repo.FindAll()
	if err != nil {
		return err
	}

	activeSuperAdmins := 0
	for _, u := range users {
		if u.Role == "super_admin" && u.IsActive {
			activeSuperAdmins++
		}
	}

	if activeSuperAdmins == 1 && !isActive {
		return errors.New("cannot deactivate the last active super admin")
	}

	return s.repo.Deactivate(id, isActive, updatedBy)
}

func (s *service) DeleteSuperUser(ctx context.Context, id int64) error {
	users, err := s.repo.FindAll()
	if err != nil {
		return err
	}

	activeSuperAdmins := 0
	for _, u := range users {
		if u.Role == "super_admin" && u.IsActive {
			activeSuperAdmins++
		}
	}

	if activeSuperAdmins == 1 {
		return errors.New("cannot delete the last active super admin")
	}

	return s.repo.Delete(id)
}

func (s *service) LoginSuperUser(ctx context.Context, email, plainPassword string) (*core.SuperUser, error) {
	u, err := s.repo.FindByEmail(email)
	if err != nil {
		return nil, errors.New("database error")
	}
	if u == nil {
		return nil, errors.New("superuser not found")
	}

	if err := auth.Verify(u.PasswordHash, plainPassword); err != nil {
		return nil, errors.New("invalid password")
	}

	return u, nil
}
