package settings

import (
	settingModels "KirrhoAccounting/kirrhosoft/models/settings"
	"KirrhoAccounting/pkg/basemodel"
	"KirrhoAccounting/pkg/convert"
)

func MapSettingToResponse(t *settingModels.Setting) map[string]interface{} {
	if t == nil {
		return nil
	}

	return map[string]interface{}{
		"id":           t.ID,
		"tenant_id":    t.TenantID,
		"key":          t.Key,
		"value":        t.Value,
		"value_type":   t.ValueType,
		"is_encrypted": t.IsEncrypted,
		"created_at":   t.CreatedAt,
		"updated_at":   t.UpdatedAt,
		"created_by":   t.CreatedBy,
		"updated_by":   t.UpdatedBy,
	}
}

func MapSettingToListResponse(list []*settingModels.Setting) []map[string]interface{} {
	res := make([]map[string]interface{}, 0, len(list))
	for _, t := range list {
		res = append(res, MapSettingToResponse(t))
	}
	return res
}

func MapCreateSettingResponse(t *settingModels.Setting) map[string]interface{} {
	return map[string]interface{}{
		"message": "Tenant created successfully",
		"tenant":  MapSettingToResponse(t),
	}
}

func MapUpdateSettingResponse(t *settingModels.Setting) map[string]interface{} {
	return map[string]interface{}{
		"message": "Tenant updated successfully",
		"tenant":  MapSettingToResponse(t),
	}
}

func MapRowToSetting(row map[string]interface{}) *settingModels.Setting {
	return &settingModels.Setting{
		ID:          convert.SafeInt64(row["id"]),
		TenantID:    convert.SafeInt64(row["tenant_id"]),
		Key:         convert.SafeString(row["key"]),
		Value:       convert.SafeString(row["value"]),
		ValueType:   convert.SafeString(row["value_type"]),
		IsEncrypted: convert.SafeBool(row["is_encrypted"]),
		AuditFields: basemodel.AuditFields{
			CreatedAt: convert.SafeFormatAnyTime(row["created_at"]),
			UpdatedAt: convert.SafeFormatAnyTime(row["updated_at"]),
			CreatedBy: convert.SafeString(row["created_by"]),
			UpdatedBy: convert.SafeString(row["updated_by"]),
		},
	}
}
