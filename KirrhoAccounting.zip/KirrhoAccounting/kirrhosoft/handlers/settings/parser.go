package settings

import (
	"KirrhoAccounting/pkg/convert"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"
)

type CreateSettingInput struct {
	TenantID    int64  `json:"tenant_id"`
	Key         string `json:"key,omitempty"`
	Value       string `json:"value,omitempty"`
	ValueType   string `json:"value_type,omitempty"`
	IsEncrypted bool   `json:"is_encrypted,omitempty"`
	CreatedBy   string `json:"created_by"`
}

func ParseCreateSettingRequest(r *http.Request) (*CreateSettingInput, error) {
	var input CreateSettingInput
	if err := parseRequest(r, &input); err != nil {
		return nil, err
	}
	input.TenantID = convert.SafeInt64(input.TenantID)
	input.Key = strings.TrimSpace(input.Key)
	input.Value = strings.TrimSpace(input.Value)
	input.ValueType = strings.TrimSpace(input.ValueType)
	input.IsEncrypted = convert.SafeBool(input.IsEncrypted)

	if input.Key == "" {
		return nil, errors.New("key is required")
	}
	if input.CreatedBy == "" {
		return nil, errors.New("created_by is required")
	}
	return &input, nil
}

func ParsePartialUpdateSettingRequest(r *http.Request) (map[string]interface{}, error) {
	updates := make(map[string]interface{})
	if err := parseRequest(r, &updates); err != nil {
		return nil, err
	}
	if len(updates) == 0 {
		return nil, errors.New("no fields to update")
	}
	return updates, nil
}

func parseRequest(r *http.Request, target interface{}) error {
	ct := r.Header.Get("Content-Type")
	if strings.HasPrefix(ct, "application/json") {
		return json.NewDecoder(r.Body).Decode(target)
	}
	return parseFormRequest(r, target)
}

func parseFormRequest(r *http.Request, target interface{}) error {
	if err := r.ParseMultipartForm(10 << 20); err != nil {
		if err := r.ParseForm(); err != nil {
			return err
		}
	}

	switch t := target.(type) {
	case *CreateSettingInput:
		return parseCreateSettingForm(r, t)
	case *map[string]interface{}:
		return parsePartialUpdateTenantForm(r, t)
	}
	return nil
}

func parseBoolField(r *http.Request, field string) bool {
	return strings.ToLower(r.FormValue(field)) == "true"
}

func parseCreateSettingForm(r *http.Request, t *CreateSettingInput) error {
	t.TenantID = convert.SafeInt64(r.FormValue("tenant_id"))
	t.Key = r.FormValue("key")
	t.Value = r.FormValue("value")
	t.ValueType = r.FormValue("value_type")
	t.IsEncrypted = convert.SafeBool(r.FormValue("is_encrypted"))
	t.CreatedBy = r.FormValue("created_by")

	//t.Phone = convert.NormalizeString(r.FormValue("phone"))
	//t.Country = convert.NormalizeString(r.FormValue("country"))
	//t.Industry = convert.NormalizeString(r.FormValue("industry"))
	//t.SchemaName = convert.NormalizeString(r.FormValue("schema_name"))
	//t.Metadata = convert.NormalizeString(r.FormValue("metadata"))
	if tenantid, ok := parseInt64Field(r, "tenant_id"); ok {
		t.TenantID = tenantid
	}

	//t.IsActive = parseBoolField(r, "is_active")
	//t.OnboardingCompleted = parseBoolField(r, "onboarding_completed")

	return nil
}

func parsePartialUpdateTenantForm(r *http.Request, t *map[string]interface{}) error {
	for key, values := range r.MultipartForm.Value {
		if len(values) == 0 {
			continue
		}
		setTenantUpdateField(t, key, values[0])
	}
	return nil
}

func setTenantUpdateField(t *map[string]interface{}, key, val string) {
	switch key {
	case "is_active", "onboarding_completed":
		(*t)[key] = convert.SafeBool(val)

	case "metadata":
		(*t)[key] = parseMetadataValue(val)

	case "plan_id":
		v := convert.SafeInt64(val)
		(*t)[key] = v

	case "phone", "country", "industry", "schema_name":
		(*t)[key] = convert.SafeString(val)

	default:
		(*t)[key] = val
	}
}

func parseMetadataValue(v string) interface{} {
	s := strings.TrimSpace(v)
	if s == "" {
		return nil
	}
	var obj map[string]any
	if json.Unmarshal([]byte(s), &obj) == nil {
		return obj
	}
	return s
}

func parseInt64Field(r *http.Request, field string) (int64, bool) {
	valStr := strings.TrimSpace(r.FormValue(field))
	if valStr == "" {
		return 0, false
	}
	val, err := strconv.ParseInt(valStr, 10, 64)
	if err != nil {
		return 0, false
	}
	return val, true
}
