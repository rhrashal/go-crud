package home

import (
	"fmt"
	"net/http"

	"KirrhoAccounting/database"
	"KirrhoAccounting/kirrhosoft/middlewares"
)

func PingHandler(w http.ResponseWriter, r *http.Request) {
	tenant, ok := r.Context().Value(middlewares.TenantKey).(string)
	if !ok || tenant == "" {
		http.Error(w, "tenants not resolved", http.StatusBadRequest)
		return
	}

	db, err := database.GetPostgresDB()
	if err != nil {
		http.Error(w, "db connection failed", http.StatusInternalServerError)
		return
	}
	defer func() {
		if err := db.Close(); err != nil {
			fmt.Printf("failed to close DB connection: %v\n", err)
		}
	}()

	_, err = db.Exec(fmt.Sprintf("SET search_path TO %s, public", tenant))
	if err != nil {
		http.Error(w, "failed to set schema", http.StatusInternalServerError)
		return
	}

	_, err = fmt.Fprintf(w, "Successful connection with KIRRHO schema: %s", tenant)
	if err != nil {
		fmt.Printf("failed to write response: %v\n", err)
	}
}
