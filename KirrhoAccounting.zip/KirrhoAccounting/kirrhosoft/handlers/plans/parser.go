package plans

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
)

type CreatePlanInput struct {
	Code           string         `json:"code,omitempty"`
	Name           string         `json:"name"`
	Description    string         `json:"description,omitempty"`
	Price          float64        `json:"price"`
	Currency       string         `json:"currency"`
	Features       map[string]any `json:"features"`
	TrialDays      int            `json:"trial_days,omitempty"`
	MaxUsers       int            `json:"max_users,omitempty"`
	StorageLimitGB int            `json:"storage_limit_gb,omitempty"`
	APILimit       int            `json:"api_limit,omitempty"`
	IsActive       bool           `json:"is_active,omitempty"`
	IsPopular      bool           `json:"is_popular,omitempty"`
	SortOrder      int            `json:"sort_order,omitempty"`
	CreatedBy      string         `json:"created_by"`
}

func ParseCreatePlanRequest(r *http.Request) (*CreatePlanInput, error) {
	var input CreatePlanInput
	if err := parseRequest(r, &input); err != nil {
		return nil, err
	}

	if input.Name == "" {
		return nil, errors.New("name is required")
	}
	if input.Price <= 0 {
		return nil, errors.New("price must be greater than 0")
	}
	if input.Currency == "" {
		return nil, errors.New("currency is required")
	}
	if input.CreatedBy == "" {
		return nil, errors.New("created_by is required")
	}

	return &input, nil
}

func ParsePartialUpdatePlanRequest(r *http.Request) (map[string]interface{}, error) {
	updates := make(map[string]interface{})
	if err := parseRequest(r, &updates); err != nil {
		return nil, err
	}

	if len(updates) == 0 {
		return nil, errors.New("no fields to update")
	}
	return updates, nil
}

func parseRequest(r *http.Request, target interface{}) error {
	ct := r.Header.Get("Content-Type")
	if strings.HasPrefix(ct, "application/json") {
		return json.NewDecoder(r.Body).Decode(target)
	}
	return parseFormRequest(r, target)
}

func parseFormRequest(r *http.Request, target interface{}) error {
	if err := r.ParseMultipartForm(10 << 20); err != nil {
		if err := r.ParseForm(); err != nil {
			return err
		}
	}

	switch t := target.(type) {
	case *CreatePlanInput:
		return parseCreatePlanForm(r, t)
	case *map[string]interface{}:
		return parsePartialUpdatePlanForm(r, t)
	}
	return nil
}

func parseIntField(r *http.Request, field string) (int, bool) {
	valStr := r.FormValue(field)
	if valStr == "" {
		return 0, false
	}
	val, err := strconv.Atoi(valStr)
	if err != nil {
		return 0, false
	}
	return val, true
}

func parseFloatField(r *http.Request, field string) (float64, bool, error) {
	valStr := r.FormValue(field)
	if valStr == "" {
		return 0, false, nil
	}
	val, err := strconv.ParseFloat(valStr, 64)
	if err != nil {
		return 0, false, fmt.Errorf("invalid %s: %s", field, valStr)
	}
	return val, true, nil
}

func parseBoolField(r *http.Request, field string) bool {
	return strings.ToLower(r.FormValue(field)) == "true"
}

func parseJSONField(r *http.Request, field string) (map[string]any, error) {
	valStr := r.FormValue(field)
	if valStr == "" {
		return nil, nil
	}
	var result map[string]any
	if err := json.Unmarshal([]byte(valStr), &result); err != nil {
		return nil, fmt.Errorf("invalid %s JSON format", field)
	}
	return result, nil
}

func parseCreatePlanForm(r *http.Request, t *CreatePlanInput) error {
	t.Code = r.FormValue("code")
	t.Name = r.FormValue("name")
	t.Description = r.FormValue("description")
	t.Currency = r.FormValue("currency")
	t.CreatedBy = r.FormValue("created_by")

	if price, ok, err := parseFloatField(r, "price"); err != nil {
		return err
	} else if ok {
		t.Price = price
	}

	if val, ok := parseIntField(r, "trial_days"); ok {
		t.TrialDays = val
	}
	if val, ok := parseIntField(r, "max_users"); ok {
		t.MaxUsers = val
	}
	if val, ok := parseIntField(r, "storage_limit_gb"); ok {
		t.StorageLimitGB = val
	}
	if val, ok := parseIntField(r, "api_limit"); ok {
		t.APILimit = val
	}
	if val, ok := parseIntField(r, "sort_order"); ok {
		t.SortOrder = val
	}

	t.IsActive = parseBoolField(r, "is_active")
	t.IsPopular = parseBoolField(r, "is_popular")

	if features, err := parseJSONField(r, "features"); err != nil {
		return err
	} else if features != nil {
		t.Features = features
	}

	return nil
}

func parsePartialUpdatePlanForm(r *http.Request, t *map[string]interface{}) error {
	for key, values := range r.MultipartForm.Value {
		if len(values) == 0 {
			continue
		}
		val := values[0]

		switch key {
		case "price":
			if f, err := strconv.ParseFloat(val, 64); err == nil {
				(*t)[key] = f
				continue
			}
		case "trial_days", "max_users", "storage_limit_gb", "api_limit", "sort_order":
			if i, err := strconv.Atoi(val); err == nil {
				(*t)[key] = i
				continue
			}
		case "is_active", "is_popular":
			(*t)[key] = strings.ToLower(val) == "true"
			continue
		case "features":
			var f map[string]any
			if err := json.Unmarshal([]byte(val), &f); err == nil {
				(*t)[key] = f
				continue
			}
		default:
			(*t)[key] = val
		}
	}
	return nil
}
