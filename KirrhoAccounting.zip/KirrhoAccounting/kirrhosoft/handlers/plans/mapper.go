package plans

import (
	planModels "KirrhoAccounting/kirrhosoft/models/plans"
	planspb "KirrhoAccounting/kirrhosoft/pb/plans"
	"KirrhoAccounting/pkg/basemodel"
	"KirrhoAccounting/pkg/convert"

	"encoding/json"

	"google.golang.org/protobuf/types/known/structpb"
	"google.golang.org/protobuf/types/known/timestamppb"
)

func MapProtoToPlan(p *planspb.Plan) *planModels.Plan {
	if p == nil {
		return nil
	}

	var features map[string]any
	if p.Features != nil {
		features = p.Features.AsMap()
	}

	return &planModels.Plan{
		ID:             p.Id,
		Code:           p.Code,
		Name:           p.Name,
		Description:    p.Description,
		Price:          p.Price,
		Currency:       p.Currency,
		Features:       features,
		TrialDays:      int(p.TrialDays),
		MaxUsers:       int(p.MaxUsers),
		StorageLimitGB: int(p.StorageLimitGb),
		APILimit:       int(p.ApiLimit),
		IsActive:       p.IsActive,
		IsPopular:      p.IsPopular,
		SortOrder:      int(p.SortOrder),
		AuditFields: basemodel.AuditFields{
			CreatedAt: convert.SafeFormatAnyTime(p.CreatedAt),
			UpdatedAt: convert.SafeFormatAnyTime(p.UpdatedAt),
			CreatedBy: p.CreatedBy,
			UpdatedBy: p.UpdatedBy,
		},
	}
}

func MapPlanToResponse(p *planModels.Plan) map[string]interface{} {
	if p == nil {
		return nil
	}

	return map[string]interface{}{
		"id":               p.ID,
		"code":             p.Code,
		"name":             p.Name,
		"description":      p.Description,
		"price":            p.Price,
		"currency":         p.Currency,
		"features":         p.Features,
		"trial_days":       p.TrialDays,
		"max_users":        p.MaxUsers,
		"storage_limit_gb": p.StorageLimitGB,
		"api_limit":        p.APILimit,
		"is_active":        p.IsActive,
		"is_popular":       p.IsPopular,
		"sort_order":       p.SortOrder,
		"created_at":       p.CreatedAt,
		"updated_at":       p.UpdatedAt,
		"created_by":       p.CreatedBy,
		"updated_by":       p.UpdatedBy,
	}
}

func MapPlanToProto(p *planModels.Plan) *planspb.Plan {
	if p == nil {
		return nil
	}

	var featuresStruct *structpb.Struct
	if p.Features != nil {
		featuresStruct, _ = structpb.NewStruct(p.Features)
	}

	return &planspb.Plan{
		Id:             p.ID,
		Code:           p.Code,
		Name:           p.Name,
		Description:    p.Description,
		Price:          p.Price,
		Currency:       p.Currency,
		Features:       featuresStruct,
		TrialDays:      int32(p.TrialDays),
		MaxUsers:       int32(p.MaxUsers),
		StorageLimitGb: int32(p.StorageLimitGB),
		ApiLimit:       int32(p.APILimit),
		IsActive:       p.IsActive,
		IsPopular:      p.IsPopular,
		SortOrder:      int32(p.SortOrder),
		CreatedAt:      timestamppb.New(p.CreatedAt),
		UpdatedAt:      timestamppb.New(p.UpdatedAt),
		CreatedBy:      p.CreatedBy,
		UpdatedBy:      p.UpdatedBy,
	}
}

func MapRowToPlan(row map[string]interface{}) *planModels.Plan {
	var features map[string]any
	if raw, ok := row["features"]; ok && raw != nil {
		switch v := raw.(type) {
		case []byte:
			_ = json.Unmarshal(v, &features)
		case string:
			_ = json.Unmarshal([]byte(v), &features)
		default:
			if b, err := json.Marshal(v); err == nil {
				_ = json.Unmarshal(b, &features)
			}
		}
	}

	return &planModels.Plan{
		ID:             convert.SafeInt64(row["id"]),
		Code:           convert.SafeString(row["code"]),
		Name:           convert.SafeString(row["name"]),
		Description:    convert.SafeString(row["description"]),
		Price:          convert.SafeFloat(row["price"]),
		Currency:       convert.SafeString(row["currency"]),
		Features:       features,
		TrialDays:      int(convert.SafeInt64(row["trial_days"])),
		MaxUsers:       int(convert.SafeInt64(row["max_users"])),
		StorageLimitGB: int(convert.SafeInt64(row["storage_limit_gb"])),
		APILimit:       int(convert.SafeInt64(row["api_limit"])),
		IsActive:       convert.SafeBool(row["is_active"]),
		IsPopular:      convert.SafeBool(row["is_popular"]),
		SortOrder:      int(convert.SafeInt64(row["sort_order"])),
		AuditFields: basemodel.AuditFields{
			CreatedAt: convert.SafeFormatAnyTime(row["created_at"]),
			UpdatedAt: convert.SafeFormatAnyTime(row["updated_at"]),
			CreatedBy: convert.SafeString(row["created_by"]),
			UpdatedBy: convert.SafeString(row["updated_by"]),
		},
	}
}

func MapPlansToListResponse(plans []*planModels.Plan) []map[string]interface{} {
	res := make([]map[string]interface{}, 0, len(plans))
	for _, p := range plans {
		res = append(res, MapPlanToResponse(p))
	}
	return res
}

func MapCreatePlanResponse(p *planModels.Plan) map[string]interface{} {
	return map[string]interface{}{
		"message": "Plan created successfully",
		"plan":    MapPlanToResponse(p),
	}
}

func MapUpdatePlanResponse(p *planModels.Plan) map[string]interface{} {
	return map[string]interface{}{
		"message": "Plan updated successfully",
		"plan":    MapPlanToResponse(p),
	}
}
