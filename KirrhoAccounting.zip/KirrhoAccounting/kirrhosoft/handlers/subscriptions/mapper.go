package subscriptions

import (
	subModels "KirrhoAccounting/kirrhosoft/models/subscriptions"
	"KirrhoAccounting/pkg/basemodel"
	"KirrhoAccounting/pkg/convert"
	"time"
)

func MapRowToSubscription(row map[string]interface{}) (*subModels.Subscription, error) {
	if row == nil {
		return nil, nil
	}

	var endDate *time.Time
	if v, ok := row["end_date"]; ok && v != nil {
		t := convert.SafeFormatAnyTime(v)
		endDate = &t
	}

	return &subModels.Subscription{
		ID:        convert.SafeInt64(row["id"]),
		TenantID:  convert.SafeInt64(row["tenant_id"]),
		PlanID:    convert.SafeInt64(row["plan_id"]),
		StartDate: convert.SafeFormatAnyTime(row["start_date"]),
		EndDate:   endDate,
		Status:    convert.SafeString(row["status"]),
		AuditFields: basemodel.AuditFields{
			CreatedAt: convert.SafeFormatAnyTime(row["created_at"]),
			UpdatedAt: convert.SafeFormatAnyTime(row["updated_at"]),
			CreatedBy: convert.SafeString(row["created_by"]),
			UpdatedBy: convert.SafeString(row["updated_by"]),
		},
	}, nil
}

type SubscriptionResponse struct {
	ID        int64   `json:"id"`
	TenantID  int64   `json:"tenant_id"`
	PlanID    int64   `json:"plan_id"`
	StartDate string  `json:"start_date"`
	EndDate   *string `json:"end_date,omitempty"`
	Status    string  `json:"status"`
	CreatedAt string  `json:"created_at"`
	UpdatedAt string  `json:"updated_at"`
	CreatedBy string  `json:"created_by"`
	UpdatedBy string  `json:"updated_by"`
}

func MapSubscriptionData[T *subModels.Subscription | []*subModels.Subscription](data T, format string) interface{} {
	if format == "" {
		format = time.RFC3339
	}

	switch v := any(data).(type) {
	case *subModels.Subscription:
		return MapSubscriptionToResponse(v, format)
	case []*subModels.Subscription:
		return MapSubscriptionsToResponse(v, format)
	default:
		return nil
	}
}

func MapSubscriptionToResponse(s *subModels.Subscription, format string) *SubscriptionResponse {
	if s == nil {
		return nil
	}

	format = normalizeFormat(format)

	var endDateStr *string
	if s.EndDate != nil {
		str := s.EndDate.Format(format)
		endDateStr = &str
	}

	return &SubscriptionResponse{
		ID:        s.ID,
		TenantID:  s.TenantID,
		PlanID:    s.PlanID,
		StartDate: s.StartDate.Format(format),
		EndDate:   endDateStr,
		Status:    s.Status,
		CreatedAt: s.CreatedAt.Format(format),
		UpdatedAt: s.UpdatedAt.Format(format),
		CreatedBy: s.CreatedBy,
		UpdatedBy: s.UpdatedBy,
	}
}

func MapSubscriptionsToResponse(subs []*subModels.Subscription, format string) []*SubscriptionResponse {
	format = normalizeFormat(format)

	responses := make([]*SubscriptionResponse, 0, len(subs))
	for _, s := range subs {
		responses = append(responses, MapSubscriptionToResponse(s, format))
	}
	return responses
}

func normalizeFormat(format string) string {
	if format == "" {
		format = time.RFC3339
	}
	return format
}
