package subscriptions

import (
	"KirrhoAccounting/pkg/convert"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"strings"
	"time"
)

type CreateSubscriptionInput struct {
	ID        int64      `json:"id,omitempty"`
	TenantID  int64      `json:"tenant_id"`
	PlanID    int64      `json:"plan_id"`
	StartDate *time.Time `json:"start_date,omitempty"`
	EndDate   *time.Time `json:"end_date,omitempty"`
	Status    string     `json:"status,omitempty"`
	CreatedBy string     `json:"created_by"`
}

func ParseCreateSubscriptionRequest(r *http.Request) (*CreateSubscriptionInput, error) {
	defer func() {
		if err := r.Body.Close(); err != nil {
			log.Printf("failed to close request body: %v", err)
		}
	}()

	var input CreateSubscriptionInput
	if err := json.NewDecoder(r.Body).Decode(&input); err != nil {
		log.Printf("invalid JSON body: %v", err)
		return nil, errors.New("invalid JSON body")
	}

	input.CreatedBy = strings.TrimSpace(input.CreatedBy)
	input.Status = strings.TrimSpace(input.Status)

	if input.TenantID <= 0 {
		return nil, errors.New("tenant_id is required")
	}
	if input.PlanID <= 0 {
		return nil, errors.New("plan_id is required")
	}

	if input.CreatedBy == "" {
		return nil, errors.New("created_by is required")
	}

	if input.Status == "" {
		input.Status = "active"
	}

	if input.StartDate == nil {
		now := time.Now().UTC()
		input.StartDate = &now
	}

	return &input, nil
}

func ParsePartialUpdateSubscriptionRequest(r *http.Request) (map[string]interface{}, error) {
	updates := make(map[string]interface{})
	if err := parseRequest(r, &updates); err != nil {
		return nil, err
	}

	if len(updates) == 0 {
		return nil, errors.New("no fields to update")
	}

	return updates, nil
}

func parseRequest(r *http.Request, target interface{}) error {
	ct := r.Header.Get("Content-Type")
	if strings.HasPrefix(ct, "application/json") {
		return json.NewDecoder(r.Body).Decode(target)
	}
	return parseFormRequest(r, target)
}

func parseFormRequest(r *http.Request, target interface{}) error {
	if err := r.ParseMultipartForm(10 << 20); err != nil {
		if err := r.ParseForm(); err != nil {
			return err
		}
	}

	switch t := target.(type) {
	case *CreateSubscriptionInput:
		return parseCreateSubscriptionForm(r, t)
	case *map[string]interface{}:
		return parsePartialUpdateSubscriptionForm(r, t)
	}
	return nil
}

func parseCreateSubscriptionForm(r *http.Request, t *CreateSubscriptionInput) error {
	if idStr := strings.TrimSpace(r.FormValue("id")); idStr != "" {
		id := convert.SafeInt64(idStr)
		if id <= 0 {
			return fmt.Errorf("invalid id")
		}
		t.ID = id
	}

	tenantID := convert.SafeInt64(strings.TrimSpace(r.FormValue("tenant_id")))
	if tenantID <= 0 {
		return fmt.Errorf("tenant_id is required")
	}
	t.TenantID = tenantID

	planID := convert.SafeInt64(strings.TrimSpace(r.FormValue("plan_id")))
	if planID <= 0 {
		return fmt.Errorf("plan_id is required")
	}
	t.PlanID = planID

	t.Status = strings.TrimSpace(r.FormValue("status"))
	t.CreatedBy = strings.TrimSpace(r.FormValue("created_by"))

	if t.CreatedBy == "" {
		return fmt.Errorf("created_by is required")
	}
	if t.Status == "" {
		t.Status = "active"
	}

	if startStr := strings.TrimSpace(r.FormValue("start_date")); startStr != "" {
		parsed := convert.SafeFormatAnyTime(startStr)
		if parsed.IsZero() {
			return fmt.Errorf("invalid start_date format (expected RFC3339)")
		}
		t.StartDate = &parsed
	}

	if endStr := strings.TrimSpace(r.FormValue("end_date")); endStr != "" {
		parsed := convert.SafeFormatAnyTime(endStr)
		if parsed.IsZero() {
			return fmt.Errorf("invalid end_date format (expected RFC3339)")
		}
		t.EndDate = &parsed
	}

	return nil
}

func parsePartialUpdateSubscriptionForm(r *http.Request, t *map[string]interface{}) error {
	for key, values := range r.MultipartForm.Value {
		if len(values) > 0 {
			val := values[0]

			if strings.Contains(key, "date") {
				if parsed, err := time.Parse(time.RFC3339, val); err == nil {
					(*t)[key] = parsed
					continue
				}
			}

			(*t)[key] = val
		}
	}
	return nil
}
