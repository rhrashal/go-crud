package superuser

import (
	"fmt"
	"io"
	"log"
	"mime/multipart"
	"os"
	"path/filepath"
	"time"
)

func SaveMediaFile(file multipart.File, filename string) (string, error) {
	mediaDir := "kirrhosoft/media"
	if err := os.MkdirAll(mediaDir, os.ModePerm); err != nil {
		return "", err
	}

	newName := fmt.Sprintf("%d_%s", time.Now().UnixNano(), filename)
	path := filepath.Join(mediaDir, newName)

	dst, err := os.Create(path)
	if err != nil {
		return "", err
	}
	defer func(dst *os.File) {
		err := dst.Close()
		if err != nil {
			log.Printf("failed to close file %s: %v", path, err)
		}
	}(dst)

	if _, err := io.Copy(dst, file); err != nil {
		return "", err
	}

	return "/media/" + newName, nil
}
