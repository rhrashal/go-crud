package superuser

import (
	"KirrhoAccounting/pkg/basemodel"
	"strings"
	"time"

	core "KirrhoAccounting/kirrhosoft/models/superuser"
	superuserpb "KirrhoAccounting/kirrhosoft/pb/superuser"
	"KirrhoAccounting/pkg/convert"
	"KirrhoAccounting/pkg/files"
)

type protoUserMeta struct {
	ID       int64
	Email    string
	RoleEnum superuserpb.Role
	Active   bool
	Profile  string
	Audit    basemodel.AuditFields
}

type SuperUserResponse struct {
	ID             int64  `json:"id"`
	Email          string `json:"email"`
	Role           string `json:"role"`
	IsActive       bool   `json:"is_active"`
	CreatedAt      string `json:"created_at"`
	UpdatedAt      string `json:"updated_at"`
	CreatedBy      string `json:"created_by"`
	UpdatedBy      string `json:"updated_by"`
	ProfilePicture string `json:"profile_picture"`
}

func protoToModel(meta protoUserMeta) *core.SuperUser {
	return &core.SuperUser{
		ID:             meta.ID,
		Email:          meta.Email,
		Role:           EnumToRole(meta.RoleEnum),
		IsActive:       meta.Active,
		ProfilePicture: convert.WrapString(meta.Profile),
		AuditFields:    meta.Audit,
	}
}

func MapListFromProto(resp *superuserpb.ListSuperUsersResponse) []*core.SuperUser {
	if resp == nil || len(resp.Users) == 0 {
		return []*core.SuperUser{}
	}

	users := make([]*core.SuperUser, 0, len(resp.Users))
	for _, u := range resp.Users {
		if u == nil {
			continue
		}

		users = append(users, protoToModel(protoUserMeta{
			ID:       u.Id,
			Email:    u.Email,
			RoleEnum: u.Role,
			Active:   u.IsActive,
			Profile:  u.ProfilePicture,
			Audit: basemodel.AuditFields{
				CreatedAt: u.CreatedAt.AsTime(),
				UpdatedAt: u.UpdatedAt.AsTime(),
				CreatedBy: u.CreatedBy,
				UpdatedBy: u.UpdatedBy,
			},
		}))
	}

	return users
}

func MapFromProto(u interface{}) *core.SuperUser {
	switch v := u.(type) {

	case *superuserpb.RegisterSuperUserResponse:
		return protoToModel(protoUserMeta{
			ID:       v.Id,
			Email:    v.Email,
			RoleEnum: v.Role,
			Active:   v.IsActive,
			Profile:  v.ProfilePicture,
			Audit: basemodel.AuditFields{
				CreatedAt: v.CreatedAt.AsTime(),
				UpdatedAt: v.UpdatedAt.AsTime(),
				CreatedBy: v.CreatedBy,
				UpdatedBy: v.UpdatedBy,
			},
		})

	case *superuserpb.GetSuperUserResponse:
		return protoToModel(protoUserMeta{
			ID:       v.Id,
			Email:    v.Email,
			RoleEnum: v.Role,
			Active:   v.IsActive,
			Profile:  v.ProfilePicture,
			Audit: basemodel.AuditFields{
				CreatedAt: v.CreatedAt.AsTime(),
				UpdatedAt: v.UpdatedAt.AsTime(),
				CreatedBy: v.CreatedBy,
				UpdatedBy: v.UpdatedBy,
			},
		})

	case *superuserpb.LoginSuperUserResponse:
		return protoToModel(protoUserMeta{
			ID:       v.Id,
			Email:    v.Email,
			RoleEnum: v.Role,
			Active:   v.IsActive,
			Profile:  v.ProfilePicture,
			Audit: basemodel.AuditFields{
				CreatedAt: v.CreatedAt.AsTime(),
				UpdatedAt: v.UpdatedAt.AsTime(),
				CreatedBy: v.CreatedBy,
				UpdatedBy: v.UpdatedBy,
			},
		})
	}

	return nil
}

func ToRegisterSuperUserResponse(u *core.SuperUser) *superuserpb.RegisterSuperUserResponse {
	createdAt, updatedAt, createdBy, updatedBy := convert.AuditToProto(u.AuditFields)

	return &superuserpb.RegisterSuperUserResponse{
		Id:             u.ID,
		Email:          u.Email,
		Role:           RoleToEnum(u.Role),
		IsActive:       u.IsActive,
		CreatedAt:      createdAt,
		UpdatedAt:      updatedAt,
		CreatedBy:      createdBy,
		UpdatedBy:      updatedBy,
		ProfilePicture: files.GetString(u.ProfilePicture),
	}
}

func ToGetSuperUserResponse(u *core.SuperUser) *superuserpb.GetSuperUserResponse {
	if u == nil {
		return nil
	}

	createdAt, updatedAt, createdBy, updatedBy := convert.AuditToProto(u.AuditFields)

	return &superuserpb.GetSuperUserResponse{
		Id:             u.ID,
		Email:          u.Email,
		Role:           RoleToEnum(u.Role),
		IsActive:       u.IsActive,
		CreatedAt:      createdAt,
		UpdatedAt:      updatedAt,
		CreatedBy:      createdBy,
		UpdatedBy:      updatedBy,
		ProfilePicture: files.GetString(u.ProfilePicture),
	}
}

func ToListSuperUsersResponse(users []*core.SuperUser) []SuperUserResponse {
	if len(users) == 0 {
		return nil
	}

	list := make([]SuperUserResponse, 0, len(users))
	for _, u := range users {
		if u == nil {
			continue
		}

		list = append(list, SuperUserResponse{
			ID:             u.ID,
			Email:          u.Email,
			Role:           strings.ToUpper("ROLE_" + u.Role),
			IsActive:       u.IsActive,
			CreatedAt:      convert.SafeFormatTime(u.CreatedAt),
			UpdatedAt:      convert.SafeFormatTime(u.UpdatedAt),
			CreatedBy:      u.CreatedBy,
			UpdatedBy:      u.UpdatedBy,
			ProfilePicture: files.GetString(u.ProfilePicture),
		})
	}

	return list
}

func ToUpdateSuperUserResponse(u *core.SuperUser) *superuserpb.UpdateSuperUserResponse {
	createdAt, updatedAt, createdBy, updatedBy := convert.AuditToProto(u.AuditFields)

	return &superuserpb.UpdateSuperUserResponse{
		Id:             u.ID,
		Email:          u.Email,
		Role:           RoleToEnum(u.Role),
		IsActive:       u.IsActive,
		CreatedAt:      createdAt,
		UpdatedAt:      updatedAt,
		CreatedBy:      createdBy,
		UpdatedBy:      updatedBy,
		ProfilePicture: files.GetString(u.ProfilePicture),
	}
}

func ToDeactivateSuperUserResponse(u *core.SuperUser) *superuserpb.DeactivateSuperUserResponse {
	_, updatedAt, _, updatedBy := convert.AuditToProto(u.AuditFields)

	return &superuserpb.DeactivateSuperUserResponse{
		Id:             u.ID,
		IsActive:       u.IsActive,
		UpdatedAt:      updatedAt,
		UpdatedBy:      updatedBy,
		ProfilePicture: files.GetString(u.ProfilePicture),
	}
}

func ToUpdateSuperUserPasswordResponse(id int64, updatedBy string, updatedAt time.Time) *superuserpb.UpdateSuperUserPasswordResponse {
	_, updatedAtProto, _, updatedByStr := convert.AuditToProto(basemodel.AuditFields{
		UpdatedAt: updatedAt,
		UpdatedBy: updatedBy,
	})

	return &superuserpb.UpdateSuperUserPasswordResponse{
		Id:        id,
		Success:   true,
		UpdatedAt: updatedAtProto,
		UpdatedBy: updatedByStr,
	}
}

func ToLoginSuperUserResponse(u *core.SuperUser) *superuserpb.LoginSuperUserResponse {
	createdAt, updatedAt, createdBy, updatedBy := convert.AuditToProto(u.AuditFields)

	return &superuserpb.LoginSuperUserResponse{
		Id:             u.ID,
		Email:          u.Email,
		Role:           RoleToEnum(u.Role),
		IsActive:       u.IsActive,
		CreatedAt:      createdAt,
		UpdatedAt:      updatedAt,
		CreatedBy:      createdBy,
		UpdatedBy:      updatedBy,
		ProfilePicture: files.GetString(u.ProfilePicture),
	}
}

type LoginResponse struct {
	AccessToken  string `json:"access_token"`
	RefreshToken string `json:"refresh_token"`
}

func ToLoginResponse(accessToken, refreshToken string) *LoginResponse {
	return &LoginResponse{
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
	}
}
