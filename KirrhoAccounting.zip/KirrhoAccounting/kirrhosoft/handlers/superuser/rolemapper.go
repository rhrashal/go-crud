package superuser

import superuserpb "KirrhoAccounting/kirrhosoft/pb/superuser"

func RoleToEnum(role string) superuserpb.Role {
	switch role {
	case "super_admin":
		return superuserpb.Role_ROLE_SUPER_ADMIN
	case "support":
		return superuserpb.Role_ROLE_SUPPORT
	case "billing":
		return superuserpb.Role_ROLE_BILLING
	case "sales":
		return superuserpb.Role_ROLE_SALES
	case "developer":
		return superuserpb.Role_ROLE_DEVELOPER
	case "auditor":
		return superuserpb.Role_ROLE_AUDITOR
	case "marketing":
		return superuserpb.Role_ROLE_MARKETING
	default:
		return superuserpb.Role_ROLE_UNSPECIFIED
	}
}

func EnumToRole(r superuserpb.Role) string {
	switch r {
	case superuserpb.Role_ROLE_SUPER_ADMIN:
		return "super_admin"
	case superuserpb.Role_ROLE_SUPPORT:
		return "support"
	case superuserpb.Role_ROLE_BILLING:
		return "billing"
	case superuserpb.Role_ROLE_SALES:
		return "sales"
	case superuserpb.Role_ROLE_DEVELOPER:
		return "developer"
	case superuserpb.Role_ROLE_AUDITOR:
		return "auditor"
	case superuserpb.Role_ROLE_MARKETING:
		return "marketing"
	default:
		return "unspecified"
	}
}
