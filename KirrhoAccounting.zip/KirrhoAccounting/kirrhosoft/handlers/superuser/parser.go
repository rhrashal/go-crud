package superuser

import (
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"mime/multipart"
	"net/http"
	"strconv"
	"strings"
)

type RegisterSuperUserInput struct {
	Email           string `json:"email"`
	Password        string `json:"password"`
	ConfirmPassword string `json:"confirm_password"`
	Role            string `json:"role,omitempty"`
	CreatedBy       string `json:"created_by,omitempty"`
	ProfilePicture  string `json:"profile_picture,omitempty"`
}

type PartialUpdateInput map[string]interface{}

type DeactivateSuperUserInput struct {
	IsActive  bool   `json:"is_active"`
	UpdatedBy string `json:"updated_by"`
}

type UpdateSuperUserPasswordInput struct {
	OldPassword string `json:"old_password"`
	NewPassword string `json:"new_password"`
	UpdatedBy   string `json:"updated_by"`
}

type LoginSuperUserInput struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

func ParseRegisterSuperUserRequest(r *http.Request) (*RegisterSuperUserInput, error) {
	var input RegisterSuperUserInput
	if err := parseRequest(r, &input); err != nil {
		return nil, err
	}

	if input.Email == "" || input.Password == "" || input.ConfirmPassword == "" {
		return nil, errors.New("email, password, and confirm_password are required")
	}
	if input.Password != input.ConfirmPassword {
		return nil, errors.New("password and confirm_password do not match")
	}
	return &input, nil
}

func ParsePartialUpdateSuperUserRequest(r *http.Request) (PartialUpdateInput, error) {
	updates := make(PartialUpdateInput)
	if err := parseRequest(r, &updates); err != nil {
		return nil, err
	}

	if len(updates) == 0 {
		return nil, errors.New("no fields to update")
	}
	return updates, nil
}

func ParseUpdateSuperUserPasswordRequest(r *http.Request) (*UpdateSuperUserPasswordInput, error) {
	var input UpdateSuperUserPasswordInput
	if err := parseRequest(r, &input); err != nil {
		return nil, err
	}

	if input.NewPassword == "" {
		return nil, errors.New("new_password is required")
	}
	if input.UpdatedBy == "" {
		return nil, errors.New("updated_by is required")
	}

	return &input, nil
}

func ParseDeactivateSuperUserRequest(r *http.Request) (*DeactivateSuperUserInput, error) {
	var input DeactivateSuperUserInput
	if err := parseRequest(r, &input); err != nil {
		return nil, err
	}

	if input.UpdatedBy == "" {
		return nil, errors.New("updated_by is required")
	}
	return &input, nil
}

func parseRequest(r *http.Request, target interface{}) error {
	ct := r.Header.Get("Content-Type")
	if strings.HasPrefix(ct, "application/json") {
		return json.NewDecoder(r.Body).Decode(target)
	}
	return parseMultipartRequest(r, target)
}

func parseMultipartRequest(r *http.Request, target interface{}) error {
	if err := r.ParseMultipartForm(10 << 20); err != nil {
		return err
	}

	switch t := target.(type) {
	case *RegisterSuperUserInput:
		return parseRegisterSuperUser(r, t)
	case *PartialUpdateInput:
		return parsePartialUpdate(r, t)
	case *DeactivateSuperUserInput:
		return parseDeactivateSuperUser(r, t)
	case *UpdateSuperUserPasswordInput:
		return parseUpdateSuperUserPassword(r, t)
	}
	return nil
}

func parseRegisterSuperUser(r *http.Request, t *RegisterSuperUserInput) error {
	t.Email = r.FormValue("email")
	t.Password = r.FormValue("password")
	t.ConfirmPassword = r.FormValue("confirm_password")
	t.Role = r.FormValue("role")
	t.CreatedBy = r.FormValue("created_by")

	if path, err := handleFileUpload(r); err == nil {
		t.ProfilePicture = path
	}
	return nil
}

func parsePartialUpdate(r *http.Request, t *PartialUpdateInput) error {
	for key, values := range r.MultipartForm.Value {
		if len(values) > 0 {
			(*t)[key] = values[0]
		}
	}
	if path, err := handleFileUpload(r); err == nil {
		(*t)["profile_picture"] = path
	}
	return nil
}

func parseUpdateSuperUserPassword(r *http.Request, t *UpdateSuperUserPasswordInput) error {
	t.OldPassword = r.FormValue("old_password")
	t.NewPassword = r.FormValue("new_password")
	t.UpdatedBy = r.FormValue("updated_by")
	return nil
}

func parseDeactivateSuperUser(r *http.Request, t *DeactivateSuperUserInput) error {
	isActiveStr := r.FormValue("is_active")
	if isActiveStr != "" {
		val, err := strconv.ParseBool(isActiveStr)
		if err != nil {
			return fmt.Errorf("invalid value for is_active: %s", isActiveStr)
		}
		t.IsActive = val
	}
	t.UpdatedBy = r.FormValue("updated_by")
	return nil
}

func handleFileUpload(r *http.Request) (string, error) {
	file, handler, err := r.FormFile("profile_picture")
	if err != nil {
		return "", err
	}
	defer safeClose(file)

	return SaveMediaFile(file, handler.Filename)
}

func safeClose(f multipart.File) {
	if err := f.Close(); err != nil {
		log.Printf("failed to close uploaded file: %v", err)
	}
}

func ParseLoginSuperUserRequest(r *http.Request) (*LoginSuperUserInput, error) {
	var input LoginSuperUserInput

	ct := r.Header.Get("Content-Type")
	if strings.HasPrefix(ct, "application/json") {
		if err := json.NewDecoder(r.Body).Decode(&input); err != nil {
			return nil, err
		}
	} else {
		if err := r.ParseMultipartForm(10 << 20); err != nil {
			return nil, err
		}
		input.Email = r.FormValue("email")
		input.Password = r.FormValue("password")
	}

	if input.Email == "" || input.Password == "" {
		return nil, errors.New("email and password are required")
	}

	return &input, nil
}
