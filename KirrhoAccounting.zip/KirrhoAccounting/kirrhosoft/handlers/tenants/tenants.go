package tenants

import (
	"KirrhoAccounting/database"
	middleware "KirrhoAccounting/kirrhosoft/middlewares"
	"database/sql"
	"errors"
	"fmt"
	"log"
	"net/http"
)

func validateTenant(db *sql.DB, tenant string) (bool, error) {
	if tenant == "public" {
		return true, nil
	}
	var isActive bool
	err := db.QueryRow("SELECT is_active FROM tenants WHERE schema_name = $1", tenant).Scan(&isActive)
	if errors.Is(err, sql.ErrNoRows) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	return isActive, nil
}

func setTenantSchema(db *sql.DB, tenant string) error {
	_, err := db.Exec(fmt.Sprintf("SET search_path TO %s, public", tenant))
	return err
}

func getTenantCount(db *sql.DB, tenant string) (int, error) {
	var count int
	var row *sql.Row

	if tenant == "public" {
		row = db.QueryRow("SELECT COUNT(*) FROM tenants")
	} else {
		row = db.QueryRow("SELECT COUNT(*) FROM users")
	}

	err := row.Scan(&count)
	return count, err
}

func HTTPTenantHandler(w http.ResponseWriter, r *http.Request) {
	tenantName, ok := r.Context().Value(middleware.TenantKey).(string)
	if !ok || tenantName == "" {
		http.Error(w, "tenants not resolved", http.StatusBadRequest)
		return
	}

	db, err := database.GetPostgresDB()
	if err != nil {
		http.Error(w, "db connection failed", http.StatusInternalServerError)
		return
	}
	defer func() {
		if err := db.Close(); err != nil {
			log.Printf("failed to close DB: %v", err)
		}
	}()

	isActive, err := validateTenant(db, tenantName)
	if err != nil {
		http.Error(w, "failed to validate tenants", http.StatusInternalServerError)
		return
	}
	if !isActive {
		log.Printf("tenants %s is either not found or inactive", tenantName)
		http.Error(w, "tenants not found or inactive", http.StatusNotFound)
		return
	}

	if err := setTenantSchema(db, tenantName); err != nil {
		log.Printf("failed to set search_path for tenants %s: %v", tenantName, err)
		http.Error(w, "schema switch failed", http.StatusInternalServerError)
		return
	}

	count, err := getTenantCount(db, tenantName)
	if err != nil {
		http.Error(w, "query failed", http.StatusInternalServerError)
		return
	}

	if tenantName == "public" {
		_, _ = fmt.Fprintf(w, "Public schema: %d tenants registered", count)
	} else {
		_, _ = fmt.Fprintf(w, "Tenant %s schema: %d users found", tenantName, count)
	}
}
