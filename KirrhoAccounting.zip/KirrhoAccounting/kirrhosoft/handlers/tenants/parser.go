package tenants

import (
	"KirrhoAccounting/pkg/convert"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"
)

type CreateTenantInput struct {
	Name                string  `json:"name"`
	Domain              string  `json:"domain,omitempty"`
	Email               string  `json:"email,omitempty"`
	Phone               *string `json:"phone,omitempty"`
	Country             *string `json:"country,omitempty"`
	Industry            *string `json:"industry,omitempty"`
	PlanID              int64   `json:"plan_id,omitempty"`
	SchemaName          *string `json:"schema_name,omitempty"`
	Timezone            string  `json:"timezone"`
	IsActive            bool    `json:"is_active,omitempty"`
	OnboardingCompleted bool    `json:"onboarding_completed,omitempty"`
	Metadata            *string `json:"metadata,omitempty"`
	CreatedBy           string  `json:"created_by"`
}

func ParseCreateTenantRequest(r *http.Request) (*CreateTenantInput, error) {
	var input CreateTenantInput
	if err := parseRequest(r, &input); err != nil {
		return nil, err
	}

	input.Name = strings.TrimSpace(input.Name)
	input.Domain = strings.TrimSpace(input.Domain)
	input.Email = strings.TrimSpace(input.Email)
	input.Timezone = strings.TrimSpace(input.Timezone)
	input.CreatedBy = strings.TrimSpace(input.CreatedBy)

	input.Phone = convert.NormalizeStringPtr(input.Phone)
	input.Country = convert.NormalizeStringPtr(input.Country)
	input.Industry = convert.NormalizeStringPtr(input.Industry)
	input.SchemaName = convert.NormalizeStringPtr(input.SchemaName)
	input.Metadata = convert.NormalizeStringPtr(input.Metadata)

	if input.Name == "" {
		return nil, errors.New("name is required")
	}
	if input.CreatedBy == "" {
		return nil, errors.New("created_by is required")
	}
	if input.Timezone == "" {
		input.Timezone = "UTC"
	}

	return &input, nil
}

func ParsePartialUpdateTenantRequest(r *http.Request) (map[string]interface{}, error) {
	updates := make(map[string]interface{})
	if err := parseRequest(r, &updates); err != nil {
		return nil, err
	}
	if len(updates) == 0 {
		return nil, errors.New("no fields to update")
	}
	return updates, nil
}

func parseRequest(r *http.Request, target interface{}) error {
	ct := r.Header.Get("Content-Type")
	if strings.HasPrefix(ct, "application/json") {
		return json.NewDecoder(r.Body).Decode(target)
	}
	return parseFormRequest(r, target)
}

func parseFormRequest(r *http.Request, target interface{}) error {
	if err := r.ParseMultipartForm(10 << 20); err != nil {
		if err := r.ParseForm(); err != nil {
			return err
		}
	}

	switch t := target.(type) {
	case *CreateTenantInput:
		return parseCreateTenantForm(r, t)
	case *map[string]interface{}:
		return parsePartialUpdateTenantForm(r, t)
	}
	return nil
}

func parseBoolField(r *http.Request, field string) bool {
	return strings.ToLower(r.FormValue(field)) == "true"
}

func parseCreateTenantForm(r *http.Request, t *CreateTenantInput) error {
	t.Name = r.FormValue("name")
	t.Domain = r.FormValue("domain")
	t.Email = r.FormValue("email")
	t.Timezone = r.FormValue("timezone")
	t.CreatedBy = r.FormValue("created_by")

	t.Phone = convert.NormalizeString(r.FormValue("phone"))
	t.Country = convert.NormalizeString(r.FormValue("country"))
	t.Industry = convert.NormalizeString(r.FormValue("industry"))
	t.SchemaName = convert.NormalizeString(r.FormValue("schema_name"))
	t.Metadata = convert.NormalizeString(r.FormValue("metadata"))
	if planID, ok := parseInt64Field(r, "plan_id"); ok {
		t.PlanID = planID
	}

	t.IsActive = parseBoolField(r, "is_active")
	t.OnboardingCompleted = parseBoolField(r, "onboarding_completed")

	return nil
}

func parsePartialUpdateTenantForm(r *http.Request, t *map[string]interface{}) error {
	for key, values := range r.MultipartForm.Value {
		if len(values) == 0 {
			continue
		}
		setTenantUpdateField(t, key, values[0])
	}
	return nil
}

func setTenantUpdateField(t *map[string]interface{}, key, val string) {
	switch key {
	case "is_active", "onboarding_completed":
		(*t)[key] = convert.SafeBool(val)

	case "metadata":
		(*t)[key] = parseMetadataValue(val)

	case "plan_id":
		v := convert.SafeInt64(val)
		(*t)[key] = v

	case "phone", "country", "industry", "schema_name":
		(*t)[key] = convert.SafeString(val)

	default:
		(*t)[key] = val
	}
}

func parseMetadataValue(v string) interface{} {
	s := strings.TrimSpace(v)
	if s == "" {
		return nil
	}
	var obj map[string]any
	if json.Unmarshal([]byte(s), &obj) == nil {
		return obj
	}
	return s
}

func parseInt64Field(r *http.Request, field string) (int64, bool) {
	valStr := strings.TrimSpace(r.FormValue(field))
	if valStr == "" {
		return 0, false
	}
	val, err := strconv.ParseInt(valStr, 10, 64)
	if err != nil {
		return 0, false
	}
	return val, true
}
