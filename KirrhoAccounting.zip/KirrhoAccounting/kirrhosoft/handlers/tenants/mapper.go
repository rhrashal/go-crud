package tenants

import (
	tenantModels "KirrhoAccounting/kirrhosoft/models/tenants"
	"KirrhoAccounting/pkg/basemodel"
	"KirrhoAccounting/pkg/convert"
)

func MapTenantToResponse(t *tenantModels.Tenant) map[string]interface{} {
	if t == nil {
		return nil
	}

	return map[string]interface{}{
		"id":                   t.ID,
		"name":                 t.Name,
		"domain":               t.Domain,
		"email":                t.Email,
		"phone":                t.Phone,
		"country":              t.Country,
		"industry":             t.Industry,
		"plan_id":              t.PlanID,
		"schema_name":          t.SchemaName,
		"timezone":             t.Timezone,
		"is_active":            t.IsActive,
		"onboarding_completed": t.OnboardingCompleted,
		"metadata":             t.Metadata,
		"created_at":           t.CreatedAt,
		"updated_at":           t.UpdatedAt,
		"created_by":           t.CreatedBy,
		"updated_by":           t.UpdatedBy,
	}
}

func MapTenantsToListResponse(list []*tenantModels.Tenant) []map[string]interface{} {
	res := make([]map[string]interface{}, 0, len(list))
	for _, t := range list {
		res = append(res, MapTenantToResponse(t))
	}
	return res
}

func MapCreateTenantResponse(t *tenantModels.Tenant) map[string]interface{} {
	return map[string]interface{}{
		"message": "Tenant created successfully",
		"tenant":  MapTenantToResponse(t),
	}
}

func MapUpdateTenantResponse(t *tenantModels.Tenant) map[string]interface{} {
	return map[string]interface{}{
		"message": "Tenant updated successfully",
		"tenant":  MapTenantToResponse(t),
	}
}

func MapRowToTenant(row map[string]interface{}) *tenantModels.Tenant {
	return &tenantModels.Tenant{
		ID:                  convert.SafeInt64(row["id"]),
		Name:                convert.SafeString(row["name"]),
		Domain:              convert.SafeString(row["domain"]),
		Email:               convert.SafeString(row["email"]),
		Phone:               convert.SafePtrString(row["phone"]),
		Country:             convert.SafePtrString(row["country"]),
		Industry:            convert.SafePtrString(row["industry"]),
		PlanID:              convert.SafeInt64(row["plan_id"]),
		SchemaName:          convert.SafePtrString(row["schema_name"]),
		Timezone:            convert.SafeString(row["timezone"]),
		IsActive:            convert.SafeBool(row["is_active"]),
		OnboardingCompleted: convert.SafeBool(row["onboarding_completed"]),
		Metadata:            convert.SafePtrString(row["metadata"]),
		AuditFields: basemodel.AuditFields{
			CreatedAt: convert.SafeFormatAnyTime(row["created_at"]),
			UpdatedAt: convert.SafeFormatAnyTime(row["updated_at"]),
			CreatedBy: convert.SafeString(row["created_by"]),
			UpdatedBy: convert.SafeString(row["updated_by"]),
		},
	}
}
