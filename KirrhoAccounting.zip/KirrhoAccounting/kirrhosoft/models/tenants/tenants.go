package tenants

import (
	"KirrhoAccounting/pkg/basemodel"
	"context"
)

type Tenant struct {
	ID                  int64   `json:"id"`
	PlanID              int64   `json:"plan_id,omitempty"`
	Name                string  `json:"name"`
	Domain              string  `json:"domain"`
	Email               string  `json:"email"`
	Phone               *string `json:"phone,omitempty"`
	Country             *string `json:"country,omitempty"`
	Industry            *string `json:"industry,omitempty"`
	SchemaName          *string `json:"schema_name,omitempty"`
	Timezone            string  `json:"timezone"`
	IsActive            bool    `json:"is_active"`
	OnboardingCompleted bool    `json:"onboarding_completed"`
	Metadata            *string `json:"metadata,omitempty"`
	basemodel.AuditFields
}

type Repository interface {
	Create(t *Tenant) (*Tenant, error)
	FindByPK(id int64) (*Tenant, error)
	FindAll() ([]*Tenant, error)
	PartialUpdate(id int64, updates map[string]interface{}) error
	Delete(id int64) error
}

type Service interface {
	CreateTenant(ctx context.Context, t *Tenant) (*Tenant, error)
	GetTenant(ctx context.Context, id int64) (*Tenant, error)
	ListTenants(ctx context.Context) ([]*Tenant, error)
	PartialUpdateTenant(ctx context.Context, id int64, updates map[string]interface{}) (*Tenant, error)
	DeleteTenant(ctx context.Context, id int64) error
}
