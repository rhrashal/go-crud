package plans

import (
	"KirrhoAccounting/pkg/basemodel"
	"context"
)

type Plan struct {
	ID             int64          `json:"id"`
	Code           string         `json:"code"`
	Name           string         `json:"name"`
	Description    string         `json:"description"`
	Price          float64        `json:"price"`
	Currency       string         `json:"currency"`
	Features       map[string]any `json:"features"`
	TrialDays      int            `json:"trial_days"`
	MaxUsers       int            `json:"max_users"`
	StorageLimitGB int            `json:"storage_limit_gb"`
	APILimit       int            `json:"api_limit"`
	IsActive       bool           `json:"is_active"`
	IsPopular      bool           `json:"is_popular"`
	SortOrder      int            `json:"sort_order"`
	basemodel.AuditFields
}

type Repository interface {
	Create(plan *Plan) (*Plan, error)
	FindByID(id int64) (*Plan, error)
	FindAll() ([]*Plan, error)
	Update(plan *Plan) error
	PartialUpdate(id int64, updates map[string]interface{}) (*Plan, error)
	Activate(id int64, updatedBy string) error
	Deactivate(id int64, updatedBy string) error
	Delete(id int64) error
}

type Service interface {
	CreatePlan(ctx context.Context, p *Plan) (*Plan, error)
	GetPlan(ctx context.Context, id int64) (*Plan, error)
	ListPlans(ctx context.Context) ([]*Plan, error)
	UpdatePlan(ctx context.Context, p *Plan) error
	PartialUpdatePlan(ctx context.Context, id int64, updates map[string]interface{}) (*Plan, error)
	ActivatePlan(ctx context.Context, id int64, updatedBy string) error
	DeactivatePlan(ctx context.Context, id int64, updatedBy string) error
	DeletePlan(ctx context.Context, id int64) error
}
