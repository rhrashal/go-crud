package cachetokens

import (
	"KirrhoAccounting/pkg/basemodel"
)

type CacheToken struct {
	ID          int64  `json:"id"`
	UserID      string `db:"user_id" json:"user_id"`
	TokenKey    int64  `db:"token_key" json:"token_key"`
	AccessToken string `db:"access_token" json:"access_token"`
	basemodel.AuditFields
}
