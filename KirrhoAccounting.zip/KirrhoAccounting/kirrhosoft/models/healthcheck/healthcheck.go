package healthcheck

type SystemHealth struct {
	System           string
	NodeName         string
	BootTime         string
	ServerStartTime  string
	ServerUptime     string
	LastShutdownTime string
	DiskUsedPercent  float64
	DiskTotalGb      float64
	DiskUsedGb       float64
	DiskFreeGb       float64
	DatabaseSize     int64
}
