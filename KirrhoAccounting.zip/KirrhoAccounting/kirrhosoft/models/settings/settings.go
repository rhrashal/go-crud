package settings

import (
	"KirrhoAccounting/pkg/basemodel"
	"context"
)

type Setting struct {
	ID          int64  `json:"id"`
	TenantID    int64  `json:"tenant_id"`
	Key         string `json:"key"`
	Value       string `json:"value"`
	ValueType   string `json:"value_type"`
	IsEncrypted bool   `json:"is_encrypted"`
	basemodel.AuditFields
}

type Repository interface {
	Create(t *Setting) (*Setting, error)
	FindByPK(id int64) (*Setting, error)
	FindAll() ([]*Setting, error)
	PartialUpdate(id int64, updates map[string]interface{}) error
	Delete(id int64) error
}

type Service interface {
	CreateSetting(ctx context.Context, t *Setting) (*Setting, error)
	GetSetting(ctx context.Context, id int64) (*Setting, error)
	ListSetting(ctx context.Context) ([]*Setting, error)
	PartialUpdateSetting(ctx context.Context, id int64, updates map[string]interface{}) (*Setting, error)
	DeleteSetting(ctx context.Context, id int64) error
}
