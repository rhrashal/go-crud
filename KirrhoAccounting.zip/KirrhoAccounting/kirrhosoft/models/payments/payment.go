package payments

import (
	"KirrhoAccounting/pkg/basemodel"
	"time"
)

type Payment struct {
	ID             int64      `json:"id"`
	SubscriptionID int64      `json:"subscription_id"`
	InvoiceNumber  string     `json:"invoice_number"`
	Amount         float64    `json:"amount"`
	Currency       string     `json:"currency"`
	TaxAmount      float64    `json:"tax_amount"`
	DiscountAmount float64    `json:"discount_amount"`
	TotalAmount    float64    `json:"total_amount"`
	PaymentDate    time.Time  `json:"payment_date"`
	PaymentDueDate *time.Time `json:"payment_due_date,omitempty"`
	PaymentMethod  string     `json:"payment_method"`
	TransactionID  string     `json:"transaction_id"`
	Status         string     `json:"status"`
	RefundID       *string    `json:"refund_id,omitempty"`
	RetryCount     int        `json:"retry_count"`
	Notes          *string    `json:"notes,omitempty"`
	Metadata       *string    `json:"metadata,omitempty"`
	basemodel.AuditFields
}
