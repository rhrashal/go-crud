package tokens

import (
	"KirrhoAccounting/pkg/basemodel"
	"time"
)

type Token struct {
	ID          int64     `json:"id"`
	SuperUserID string    `db:"super_user_id" json:"super_user_id"`
	Token       string    `db:"token" json:"token"`
	TokenType   string    `db:"token_type" json:"token_type"`
	UserAgent   *string   `db:"user_agent" json:"user_agent,omitempty"`
	IPAddress   *string   `db:"ip_address" json:"ip_address,omitempty"`
	Platform    *string   `db:"platform" json:"platform,omitempty"`
	ExpiresAt   time.Time `db:"expires_at" json:"expires_at"`
	basemodel.AuditFields
}
