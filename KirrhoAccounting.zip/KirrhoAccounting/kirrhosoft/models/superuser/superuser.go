package superuser

import (
	"KirrhoAccounting/pkg/basemodel"
	"context"
)

type SuperUser struct {
	ID             int64   `json:"id"`
	Email          string  `json:"email"`
	PasswordHash   string  `json:"-"`
	Role           string  `json:"role"`
	IsActive       bool    `json:"is_active"`
	ProfilePicture *string `json:"profile_picture,omitempty"`
	basemodel.AuditFields
}

type Repository interface {
	Create(user *SuperUser) (*SuperUser, error)
	FindByEmail(email string) (*SuperUser, error)
	FindByID(id int64) (*SuperUser, error)
	FindAll() ([]*SuperUser, error)
	Update(user *SuperUser) error
	PartialUpdate(id int64, updates map[string]interface{}) error
	UpdatePassword(id int64, newPasswordHash string, updatedBy string) error
	Deactivate(id int64, isActive bool, updatedBy string) error
	Delete(id int64) error
}

type Service interface {
	RegisterSuperUser(ctx context.Context, u *SuperUser, plainPassword string) (*SuperUser, error)
	LoginSuperUser(ctx context.Context, email, password string) (*SuperUser, error)
	GetSuperUser(ctx context.Context, id int64) (*SuperUser, error)
	ListSuperUsers(ctx context.Context) ([]*SuperUser, error)
	UpdateSuperUser(ctx context.Context, u *SuperUser) error
	PartialUpdateSuperUser(ctx context.Context, id int64, updates map[string]interface{}) error
	UpdateSuperUserPassword(ctx context.Context, id int64, oldPassword, newPassword, updatedBy string) error
	DeactivateSuperUser(ctx context.Context, id int64, isActive bool, updatedBy string) error
	DeleteSuperUser(ctx context.Context, id int64) error
}
