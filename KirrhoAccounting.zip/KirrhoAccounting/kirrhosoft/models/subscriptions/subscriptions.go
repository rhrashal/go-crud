package subscriptions

import (
	"KirrhoAccounting/pkg/basemodel"
	"time"
)

type Subscription struct {
	ID                 int64      `json:"id"`
	TenantID           int64      `json:"tenant_id"`
	PlanID             int64      `json:"plan_id"`
	SubscriptionNumber string     `json:"subscription_number,omitempty"`
	StartDate          time.Time  `json:"start_date"`
	EndDate            *time.Time `json:"end_date,omitempty"`
	Status             string     `json:"status"`
	TrialStartDate     *time.Time `json:"trial_start_date,omitempty"`
	TrialEndDate       *time.Time `json:"trial_end_date,omitempty"`
	AutoRenew          bool       `json:"auto_renew"`
	RenewalDate        *time.Time `json:"renewal_date,omitempty"`
	CancelledAt        *time.Time `json:"cancelled_at,omitempty"`
	CancellationReason *string    `json:"cancellation_reason,omitempty"`
	BillingCycleDays   int        `json:"billing_cycle_days"`
	NextBillingAmount  float64    `json:"next_billing_amount"`
	Currency           string     `json:"currency"`
	Notes              *string    `json:"notes,omitempty"`
	Metadata           *string    `json:"metadata,omitempty"`
	basemodel.AuditFields
}
