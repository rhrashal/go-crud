package healthcheck

import (
	healthpb "KirrhoAccounting/kirrhosoft/pb/healthcheck"
	healthService "KirrhoAccounting/kirrhosoft/services/healthcheck"
	"context"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

type grpcServer struct {
	healthpb.UnimplementedSystemHealthServer
	service *healthService.Service
}

func NewGRPCServer(service *healthService.Service) healthpb.SystemHealthServer {
	return &grpcServer{service: service}
}

func (s *grpcServer) GetHealthInfo(ctx context.Context, req *healthpb.HealthRequest) (*healthpb.HealthResponse, error) {
	data, err := s.service.GetSystemHealth()
	if err != nil {
		return nil, status.Errorf(codes.Internal, "failed to fetch system healthcheck: %v", err)
	}

	return &healthpb.HealthResponse{
		System:           data.System,
		NodeName:         data.NodeName,
		BootTime:         data.BootTime,
		ServerStartTime:  data.ServerStartTime,
		ServerUptime:     data.ServerUptime,
		LastShutdownTime: data.LastShutdownTime,
		DiskUsedPercent:  data.DiskUsedPercent,
		DiskTotalGb:      data.DiskTotalGb,
		DiskUsedGb:       data.DiskUsedGb,
		DiskFreeGb:       data.DiskFreeGb,
		DatabaseSize:     data.DatabaseSize,
	}, nil
}
