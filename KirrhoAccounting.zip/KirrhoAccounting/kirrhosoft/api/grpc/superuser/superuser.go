package superuser

import (
	roleMapper "KirrhoAccounting/kirrhosoft/handlers/superuser"
	"KirrhoAccounting/kirrhosoft/models/superuser"
	superuserpb "KirrhoAccounting/kirrhosoft/pb/superuser"
	"KirrhoAccounting/pkg/basemodel"
	"KirrhoAccounting/pkg/files"
	"context"
	"fmt"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/timestamppb"
)

const errSuperUserNotFound = "superuser with email %s not found"

type grpcServer struct {
	superuserpb.UnimplementedSuperUserServiceServer
	service superuser.Service
}

func New(service superuser.Service) superuserpb.SuperUserServiceServer {
	return &grpcServer{service: service}
}

func (s *grpcServer) RegisterSuperUser(ctx context.Context, req *superuserpb.RegisterSuperUserRequest) (*superuserpb.RegisterSuperUserResponse, error) {
	u := &superuser.SuperUser{
		Email: req.Email,
		Role:  roleMapper.EnumToRole(req.Role),
		AuditFields: basemodel.AuditFields{
			CreatedBy: req.CreatedBy,
		},
	}
	if req.ProfilePicture != "" {
		u.ProfilePicture = &req.ProfilePicture
	}

	created, err := s.service.RegisterSuperUser(ctx, u, req.Password)
	if err != nil {
		return nil, status.Errorf(codes.InvalidArgument, err.Error())
	}

	return &superuserpb.RegisterSuperUserResponse{
		Id:             created.ID,
		Email:          created.Email,
		Role:           roleMapper.RoleToEnum(created.Role),
		IsActive:       created.IsActive,
		CreatedAt:      timestamppb.New(created.CreatedAt),
		UpdatedAt:      timestamppb.New(created.UpdatedAt),
		CreatedBy:      created.CreatedBy,
		UpdatedBy:      created.UpdatedBy,
		ProfilePicture: files.GetString(created.ProfilePicture),
	}, nil
}

func (s *grpcServer) LoginSuperUser(ctx context.Context, req *superuserpb.LoginSuperUserRequest) (*superuserpb.LoginSuperUserResponse, error) {
	u, err := s.service.LoginSuperUser(ctx, req.Email, req.Password)
	if err != nil {
		return nil, status.Errorf(codes.Unauthenticated, err.Error())
	}
	return &superuserpb.LoginSuperUserResponse{
		Id:             u.ID,
		Email:          u.Email,
		Role:           roleMapper.RoleToEnum(u.Role),
		IsActive:       u.IsActive,
		CreatedAt:      timestamppb.New(u.CreatedAt),
		UpdatedAt:      timestamppb.New(u.UpdatedAt),
		CreatedBy:      u.CreatedBy,
		UpdatedBy:      u.UpdatedBy,
		ProfilePicture: files.GetString(u.ProfilePicture),
	}, nil
}

func (s *grpcServer) GetSuperUser(ctx context.Context, req *superuserpb.GetSuperUserRequest) (*superuserpb.GetSuperUserResponse, error) {
	u, err := s.service.GetSuperUser(ctx, req.Id)
	if err != nil {
		return nil, status.Errorf(codes.Internal, err.Error())
	}
	if u == nil {
		return nil, status.Errorf(codes.NotFound, errSuperUserNotFound, req.Id)
	}
	return &superuserpb.GetSuperUserResponse{
		Id:             u.ID,
		Email:          u.Email,
		Role:           roleMapper.RoleToEnum(u.Role),
		IsActive:       u.IsActive,
		CreatedAt:      timestamppb.New(u.CreatedAt),
		UpdatedAt:      timestamppb.New(u.UpdatedAt),
		CreatedBy:      u.CreatedBy,
		UpdatedBy:      u.UpdatedBy,
		ProfilePicture: files.GetString(u.ProfilePicture),
	}, nil
}

func (s *grpcServer) ListSuperUsers(ctx context.Context, req *superuserpb.ListSuperUsersRequest) (*superuserpb.ListSuperUsersResponse, error) {
	users, err := s.service.ListSuperUsers(ctx)
	if err != nil {
		fmt.Printf("ListSuperUsers failed: %v\n", err)
		return nil, err
	}

	fmt.Printf("ListSuperUsers returned %d users\n", len(users))

	resp := &superuserpb.ListSuperUsersResponse{}
	for _, u := range users {
		resp.Users = append(resp.Users, &superuserpb.GetSuperUserResponse{
			Id:             u.ID,
			Email:          u.Email,
			Role:           roleMapper.RoleToEnum(u.Role),
			IsActive:       u.IsActive,
			CreatedAt:      timestamppb.New(u.CreatedAt),
			UpdatedAt:      timestamppb.New(u.UpdatedAt),
			CreatedBy:      u.CreatedBy,
			UpdatedBy:      u.UpdatedBy,
			ProfilePicture: files.GetString(u.ProfilePicture),
		})
	}
	return resp, nil
}

func (s *grpcServer) UpdateSuperUser(ctx context.Context, req *superuserpb.UpdateSuperUserRequest) (*superuserpb.UpdateSuperUserResponse, error) {
	u := &superuser.SuperUser{
		ID:       req.Id,
		Email:    req.GetEmail(),
		Role:     roleMapper.EnumToRole(req.GetRole()),
		IsActive: req.GetIsActive(),
		AuditFields: basemodel.AuditFields{
			UpdatedBy: req.UpdatedBy,
		},
	}
	if req.ProfilePicture != nil && *req.ProfilePicture != "" {
		u.ProfilePicture = req.ProfilePicture
	}

	if err := s.service.UpdateSuperUser(ctx, u); err != nil {
		return nil, status.Errorf(codes.InvalidArgument, err.Error())
	}

	return &superuserpb.UpdateSuperUserResponse{
		Id:             u.ID,
		Email:          u.Email,
		Role:           roleMapper.RoleToEnum(u.Role),
		IsActive:       u.IsActive,
		CreatedAt:      timestamppb.New(u.CreatedAt),
		UpdatedAt:      timestamppb.New(u.UpdatedAt),
		CreatedBy:      u.CreatedBy,
		UpdatedBy:      u.UpdatedBy,
		ProfilePicture: files.GetString(u.ProfilePicture),
	}, nil
}

func (s *grpcServer) PartialUpdateSuperUser(ctx context.Context, req *superuserpb.PartialUpdateSuperUserRequest) (*superuserpb.PartialUpdateSuperUserResponse, error) {
	updates := make(map[string]interface{}, len(req.Updates))
	for k, v := range req.Updates {
		updates[k] = v
	}

	if err := s.service.PartialUpdateSuperUser(ctx, req.Id, updates); err != nil {
		return nil, status.Errorf(codes.InvalidArgument, err.Error())
	}

	u, err := s.service.GetSuperUser(ctx, req.Id)
	if err != nil {
		return nil, status.Errorf(codes.Internal, err.Error())
	}
	if u == nil {
		return nil, status.Errorf(codes.NotFound, errSuperUserNotFound, req.Id)
	}

	return &superuserpb.PartialUpdateSuperUserResponse{
		Id:             u.ID,
		Email:          u.Email,
		Role:           roleMapper.RoleToEnum(u.Role),
		IsActive:       u.IsActive,
		CreatedAt:      timestamppb.New(u.CreatedAt),
		UpdatedAt:      timestamppb.New(u.UpdatedAt),
		CreatedBy:      u.CreatedBy,
		UpdatedBy:      u.UpdatedBy,
		ProfilePicture: files.GetString(u.ProfilePicture),
	}, nil
}

func (s *grpcServer) UpdateSuperUserPassword(ctx context.Context, req *superuserpb.UpdateSuperUserPasswordRequest) (*superuserpb.UpdateSuperUserPasswordResponse, error) {
	if err := s.service.UpdateSuperUserPassword(ctx, req.Id, req.OldPassword, req.NewPassword, req.UpdatedBy); err != nil {
		return nil, status.Errorf(codes.InvalidArgument, err.Error())
	}
	return &superuserpb.UpdateSuperUserPasswordResponse{
		Id:        req.Id,
		Success:   true,
		UpdatedAt: timestamppb.Now(),
		UpdatedBy: req.UpdatedBy,
	}, nil
}

func (s *grpcServer) DeactivateSuperUser(ctx context.Context, req *superuserpb.DeactivateSuperUserRequest) (*superuserpb.DeactivateSuperUserResponse, error) {
	if err := s.service.DeactivateSuperUser(ctx, req.Id, req.IsActive, req.UpdatedBy); err != nil {
		return nil, status.Errorf(codes.InvalidArgument, err.Error())
	}

	u, err := s.service.GetSuperUser(ctx, req.Id)
	if err != nil {
		return nil, status.Errorf(codes.Internal, err.Error())
	}
	if u == nil {
		return nil, status.Errorf(codes.NotFound, errSuperUserNotFound, req.Id)
	}

	return &superuserpb.DeactivateSuperUserResponse{
		Id:             u.ID,
		IsActive:       u.IsActive,
		UpdatedAt:      timestamppb.New(u.UpdatedAt),
		UpdatedBy:      u.UpdatedBy,
		ProfilePicture: files.GetString(u.ProfilePicture),
	}, nil
}

func (s *grpcServer) DeleteSuperUser(ctx context.Context, req *superuserpb.DeleteSuperUserRequest) (*superuserpb.DeleteSuperUserResponse, error) {
	if err := s.service.DeleteSuperUser(ctx, req.Id); err != nil {
		return &superuserpb.DeleteSuperUserResponse{Success: false}, status.Errorf(codes.InvalidArgument, err.Error())
	}
	return &superuserpb.DeleteSuperUserResponse{Success: true}, nil
}
