package plans

import (
	plansMapper "KirrhoAccounting/kirrhosoft/handlers/plans"
	planModels "KirrhoAccounting/kirrhosoft/models/plans"
	planspb "KirrhoAccounting/kirrhosoft/pb/plans"
	plansService "KirrhoAccounting/kirrhosoft/services/plans"
	"KirrhoAccounting/pkg/basemodel"
	"context"
	"fmt"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

const (
	errPlanNotFound = "plan with id %d not found"
)

type grpcServer struct {
	planspb.UnimplementedPlanServiceServer
	service *plansService.Service
}

func New(service *plansService.Service) planspb.PlanServiceServer {
	return &grpcServer{service: service}
}

func (s *grpcServer) CreatePlan(ctx context.Context, req *planspb.CreatePlanRequest) (*planspb.CreatePlanResponse, error) {
	var features map[string]any
	if req.Features != nil {
		features = req.Features.AsMap()
	}

	p := &planModels.Plan{
		Code:           req.Code,
		Name:           req.Name,
		Description:    req.Description,
		Price:          req.Price,
		Currency:       req.Currency,
		Features:       features,
		TrialDays:      int(req.TrialDays),
		MaxUsers:       int(req.MaxUsers),
		StorageLimitGB: int(req.StorageLimitGb),
		APILimit:       int(req.ApiLimit),
		IsActive:       req.IsActive,
		IsPopular:      req.IsPopular,
		SortOrder:      int(req.SortOrder),
		AuditFields: basemodel.AuditFields{
			CreatedBy: req.CreatedBy,
		},
	}

	created, err := s.service.CreatePlan(ctx, p)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "failed to create plan: %v", err)
	}

	return &planspb.CreatePlanResponse{Plan: plansMapper.MapPlanToProto(created)}, nil
}

func (s *grpcServer) GetPlan(ctx context.Context, req *planspb.GetPlanRequest) (*planspb.GetPlanResponse, error) {
	p, err := s.service.GetPlan(ctx, req.Id)
	if err != nil {
		return nil, status.Errorf(codes.Internal, err.Error())
	}
	if p == nil {
		return nil, status.Errorf(codes.NotFound, errPlanNotFound, req.Id)
	}
	return &planspb.GetPlanResponse{Plan: plansMapper.MapPlanToProto(p)}, nil
}

func (s *grpcServer) ListPlans(ctx context.Context, req *planspb.ListPlansRequest) (*planspb.ListPlansResponse, error) {
	plans, err := s.service.ListPlans(ctx)
	if err != nil {
		return nil, status.Errorf(codes.Internal, err.Error())
	}

	resp := &planspb.ListPlansResponse{}
	for _, p := range plans {
		resp.Plans = append(resp.Plans, plansMapper.MapPlanToProto(p))
	}
	return resp, nil
}

func (s *grpcServer) PartialUpdatePlan(ctx context.Context, req *planspb.PartialUpdatePlanRequest) (*planspb.PartialUpdatePlanResponse, error) {
	var updates map[string]any
	if req.Updates != nil {
		updates = req.Updates.AsMap()
	}

	updated, err := s.service.PartialUpdatePlan(ctx, req.Id, updates)
	if err != nil {
		return nil, status.Errorf(codes.Internal, fmt.Sprintf("failed to update plan: %v", err))
	}
	if updated == nil {
		return nil, status.Errorf(codes.NotFound, errPlanNotFound, req.Id)
	}

	return &planspb.PartialUpdatePlanResponse{Plan: plansMapper.MapPlanToProto(updated)}, nil
}

func (s *grpcServer) DeletePlan(ctx context.Context, req *planspb.DeletePlanRequest) (*planspb.DeletePlanResponse, error) {
	if err := s.service.DeletePlan(ctx, req.Id); err != nil {
		return &planspb.DeletePlanResponse{Success: false}, status.Errorf(codes.Internal, err.Error())
	}
	return &planspb.DeletePlanResponse{Success: true}, nil
}

func (s *grpcServer) ActivatePlan(ctx context.Context, req *planspb.ActivatePlanRequest) (*planspb.ActivatePlanResponse, error) {
	if err := s.service.ActivatePlan(ctx, req.Id, req.UpdatedBy); err != nil {
		return nil, status.Errorf(codes.Internal, err.Error())
	}
	p, _ := s.service.GetPlan(ctx, req.Id)
	return &planspb.ActivatePlanResponse{Plan: plansMapper.MapPlanToProto(p)}, nil
}

func (s *grpcServer) DeactivatePlan(ctx context.Context, req *planspb.DeactivatePlanRequest) (*planspb.DeactivatePlanResponse, error) {
	if err := s.service.DeactivatePlan(ctx, req.Id, req.UpdatedBy); err != nil {
		return nil, status.Errorf(codes.Internal, err.Error())
	}
	p, _ := s.service.GetPlan(ctx, req.Id)
	return &planspb.DeactivatePlanResponse{Plan: plansMapper.MapPlanToProto(p)}, nil
}
