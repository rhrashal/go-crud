package settings

import (
	settingHandlers "KirrhoAccounting/kirrhosoft/handlers/settings"
	settingModels "KirrhoAccounting/kirrhosoft/models/settings"
	auditModels "KirrhoAccounting/pkg/basemodel"
	"KirrhoAccounting/pkg/httpresponse"
	"KirrhoAccounting/pkg/messages"

	"log"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"
)

const errInvalidSettingID = "invalid setting ID"

type Handler struct {
	service settingModels.Service
}

func NewHandler(service settingModels.Service) *Handler {
	return &Handler{service: service}
}

func (h *Handler) CreateSetting(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	input, err := settingHandlers.ParseCreateSettingRequest(r)
	if err != nil {
		httpresponse.WriteError(w, messages.ErrorMessage(err.Error()), http.StatusBadRequest)
		return
	}

	//timezone := input.Timezone
	//if strings.TrimSpace(timezone) == "" {
	//	timezone = "UTC"
	//}

	t := &settingModels.Setting{
		TenantID:    input.TenantID,
		Key:         input.Key,
		Value:       input.Value,
		ValueType:   input.ValueType,
		IsEncrypted: input.IsEncrypted,
		AuditFields: auditModels.AuditFields{
			CreatedBy: input.CreatedBy,
		},
	}

	created, err := h.service.CreateSetting(r.Context(), t)
	if err != nil {
		log.Printf("CreateSetting failed: %v", err)
		httpresponse.WriteError(w, messages.ErrorMessage(err.Error()), http.StatusInternalServerError)
		return
	}

	httpresponse.WriteSuccess(w, messages.DataCreatedSuccessful, settingHandlers.MapSettingToResponse(created), http.StatusCreated)
}

func (h *Handler) GetSetting(w http.ResponseWriter, r *http.Request) {
	idStr := mux.Vars(r)["id"]
	if idStr == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil || id <= 0 {
		httpresponse.WriteError(w, errInvalidSettingID, http.StatusBadRequest)
		return
	}

	t, err := h.service.GetSetting(r.Context(), id)
	if err != nil {
		httpresponse.WriteServiceError(w, err)
		return
	}

	httpresponse.WriteSuccess(w, messages.DataRetrieved, settingHandlers.MapSettingToResponse(t), http.StatusOK)
}

func (h *Handler) ListSetting(w http.ResponseWriter, r *http.Request) {
	settingList, err := h.service.ListSetting(r.Context())
	if err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}

	httpresponse.WriteSuccess(w, messages.DataRetrieved, settingHandlers.MapSettingToListResponse(settingList), http.StatusOK)
}

func (h *Handler) PartialUpdateSetting(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPatch {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	idStr := mux.Vars(r)["id"]
	if idStr == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil || id <= 0 {
		httpresponse.WriteError(w, errInvalidSettingID, http.StatusBadRequest)
		return
	}

	updates, err := settingHandlers.ParsePartialUpdateSettingRequest(r)
	if err != nil {
		httpresponse.WriteError(w, messages.ErrorMessage(err.Error()), http.StatusBadRequest)
		return
	}

	updated, err := h.service.PartialUpdateSetting(r.Context(), id, updates)
	if err != nil {
		httpresponse.WriteServiceError(w, err)
		return
	}

	httpresponse.WriteSuccess(w, messages.DataUpdatedSuccessful, settingHandlers.MapSettingToResponse(updated), http.StatusOK)
}

func (h *Handler) DeleteSetting(w http.ResponseWriter, r *http.Request) {
	idStr := mux.Vars(r)["id"]
	if idStr == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil || id <= 0 {
		httpresponse.WriteError(w, errInvalidSettingID, http.StatusBadRequest)
		return
	}

	if err := h.service.DeleteSetting(r.Context(), id); err != nil {
		httpresponse.WriteServiceError(w, err)
		return
	}

	httpresponse.WriteSuccess(w, messages.DeleteSuccessful, nil, http.StatusOK)
}
