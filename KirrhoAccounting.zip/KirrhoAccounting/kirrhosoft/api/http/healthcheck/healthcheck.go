package healthcheck

import (
	"KirrhoAccounting/kirrhosoft/pkg/adapter/healthcheck"
	"KirrhoAccounting/pkg/httpresponse"
	"KirrhoAccounting/pkg/messages"
	"net/http"
)

type Handler struct {
	service *healthcheck.GRPCHealthAdapter
}

func NewHandler(s *healthcheck.GRPCHealthAdapter) *Handler {
	return &Handler{service: s}
}

func (h *Handler) GetSystemHealth(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	data, err := h.service.GetSystemHealth(r.Context())
	if err != nil {
		httpresponse.WriteError(w, messages.ExceptionMessage, http.StatusInternalServerError)
		return
	}

	httpresponse.WriteSuccess(w, messages.DataRetrieved, data, http.StatusOK)
}
