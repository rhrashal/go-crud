package superuser

import (
	handlers "KirrhoAccounting/kirrhosoft/handlers/superuser"
	core "KirrhoAccounting/kirrhosoft/models/superuser"
	"KirrhoAccounting/kirrhosoft/pkg/auth"
	"KirrhoAccounting/pkg/basemodel"
	"KirrhoAccounting/pkg/convert"
	"KirrhoAccounting/pkg/httpresponse"
	"KirrhoAccounting/pkg/messages"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/gorilla/mux"
)

type Handler struct {
	service core.Service
}

func NewHandler(service core.Service) *Handler {
	return &Handler{service: service}
}

func (h *Handler) RegisterSuperUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	input, err := handlers.ParseRegisterSuperUserRequest(r)
	if err != nil {
		httpresponse.WriteError(w, messages.ErrorMessage(err.Error()), http.StatusBadRequest)
		return
	}

	u := &core.SuperUser{
		Email:    input.Email,
		Role:     input.Role,
		IsActive: true,
		AuditFields: basemodel.AuditFields{
			CreatedBy: input.CreatedBy,
			CreatedAt: time.Now().UTC(),
		},
	}
	if input.ProfilePicture != "" {
		u.ProfilePicture = &input.ProfilePicture
	}

	created, err := h.service.RegisterSuperUser(r.Context(), u, input.Password)

	if err != nil {
		if err.Error() == "superuser already exists" {
			httpresponse.WriteError(w, messages.AlreadyExists, http.StatusConflict)
			return
		}
		httpresponse.WriteError(w, messages.ExceptionMessage, http.StatusInternalServerError)
		return
	}

	resp := handlers.ToRegisterSuperUserResponse(created)
	httpresponse.WriteSuccess(w, messages.DataCreatedSuccessful, resp, http.StatusCreated)
}

func (h *Handler) GetSuperUser(w http.ResponseWriter, r *http.Request) {
	id := convert.SafeInt64(mux.Vars(r)["id"])

	if id == 0 {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	u, err := h.service.GetSuperUser(r.Context(), id)
	if err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}
	if u == nil {
		httpresponse.WriteError(w, messages.NoDataFound, http.StatusNotFound)
		return
	}

	resp := handlers.ToListSuperUsersResponse([]*core.SuperUser{u})[0]
	httpresponse.WriteSuccess(w, messages.DataRetrieved, resp, http.StatusOK)
}

func (h *Handler) ListSuperUsers(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	users, err := h.service.ListSuperUsers(r.Context())
	if err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}

	if len(users) == 0 {
		httpresponse.WriteError(w, messages.NoDataFound, http.StatusNotFound)
		return
	}

	resp := handlers.ToListSuperUsersResponse(users)
	httpresponse.WriteSuccess(w, messages.DataRetrieved, resp, http.StatusOK)
}

func (h *Handler) UpdateSuperUser(w http.ResponseWriter, r *http.Request) {
	var u core.SuperUser
	if err := json.NewDecoder(r.Body).Decode(&u); err != nil {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	if err := h.service.UpdateSuperUser(r.Context(), &u); err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}

	resp := handlers.ToUpdateSuperUserResponse(&u)
	httpresponse.WriteSuccess(w, messages.DataUpdatedSuccessful, resp, http.StatusOK)
}

func (h *Handler) PartialUpdateSuperUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPatch {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	id := convert.SafeInt64(mux.Vars(r)["id"])

	updates, err := handlers.ParsePartialUpdateSuperUserRequest(r)
	if err != nil {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	if err := h.service.PartialUpdateSuperUser(r.Context(), id, updates); err != nil {
		switch {
		case errors.Is(err, messages.NoDataFound), strings.Contains(err.Error(), messages.NoDataFound.Error()):
			httpresponse.WriteError(w, messages.NoDataFound, http.StatusNotFound)
		default:
			httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		}
		return
	}

	superuser, err := h.service.GetSuperUser(r.Context(), id)
	if err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}
	if superuser == nil {
		httpresponse.WriteError(w, messages.NoDataFound, http.StatusNotFound)
		return
	}

	resp := handlers.ToUpdateSuperUserResponse(superuser)
	httpresponse.WriteSuccess(w, messages.DataCreatedSuccessful, resp, http.StatusCreated)
}

func (h *Handler) UpdateSuperUserPassword(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPut && r.Method != http.MethodPatch {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	id := convert.SafeInt64(mux.Vars(r)["id"])
	if id == 0 {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	input, err := handlers.ParseUpdateSuperUserPasswordRequest(r)
	if err != nil {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	if err := h.service.UpdateSuperUserPassword(
		r.Context(),
		id,
		input.OldPassword,
		input.NewPassword,
		input.UpdatedBy,
	); err != nil {
		if strings.Contains(err.Error(), "invalid password") {
			httpresponse.WriteError(w, messages.InvalidCredentials, http.StatusUnauthorized)
			return
		}
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}

	resp := handlers.ToUpdateSuperUserPasswordResponse(id, input.UpdatedBy, time.Now().UTC())
	httpresponse.WriteSuccess(w, messages.DataUpdatedSuccessful, resp, http.StatusOK)
}

func (h *Handler) DeactivateSuperUser(w http.ResponseWriter, r *http.Request) {
	id := convert.SafeInt64(mux.Vars(r)["id"])

	input, err := handlers.ParseDeactivateSuperUserRequest(r)
	if err != nil {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	if err := h.service.DeactivateSuperUser(r.Context(), id, input.IsActive, input.UpdatedBy); err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}

	u, err := h.service.GetSuperUser(r.Context(), id)
	if err != nil || u == nil {
		httpresponse.WriteError(w, messages.NoDataFound, http.StatusNotFound)
		return
	}

	resp := handlers.ToDeactivateSuperUserResponse(u)
	httpresponse.WriteSuccess(w, messages.DataUpdatedSuccessful, resp, http.StatusOK)
}

func (h *Handler) DeleteSuperUser(w http.ResponseWriter, r *http.Request) {
	id := convert.SafeInt64(mux.Vars(r)["id"])

	if err := h.service.DeleteSuperUser(r.Context(), id); err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}
	httpresponse.WriteSuccess(w, messages.DeleteSuccessful, nil, http.StatusOK)
}

func (h *Handler) LoginSuperUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	input, err := handlers.ParseLoginSuperUserRequest(r)
	if err != nil {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	u, err := h.service.LoginSuperUser(r.Context(), input.Email, input.Password)
	if err != nil {
		httpresponse.WriteError(w, messages.InvalidCredentials, http.StatusUnauthorized)
		return
	}
	accessToken, err := auth.GenerateAccessToken(strconv.FormatInt(u.ID, 10), u.Email)
	if err != nil {
		httpresponse.WriteError(w, messages.ExceptionMessage, http.StatusInternalServerError)
		return
	}

	refreshToken, err := auth.GenerateRefreshToken(strconv.FormatInt(u.ID, 10), u.Email)
	if err != nil {
		httpresponse.WriteError(w, messages.ExceptionMessage, http.StatusInternalServerError)
		return
	}

	resp := handlers.ToLoginResponse(accessToken, refreshToken)
	httpresponse.WriteSuccess(w, messages.LoginSuccessful, resp, http.StatusOK)
}
