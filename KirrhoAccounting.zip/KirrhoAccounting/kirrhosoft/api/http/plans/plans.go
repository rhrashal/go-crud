package plans

import (
	"KirrhoAccounting/kirrhosoft/handlers/plans"
	planModels "KirrhoAccounting/kirrhosoft/models/plans"
	auditModels "KirrhoAccounting/pkg/basemodel"
	"KirrhoAccounting/pkg/httpresponse"
	"KirrhoAccounting/pkg/messages"
	"errors"
	"net/http"
	"strconv"
	"strings"

	"github.com/gorilla/mux"
)

const errInvalidPlanID = "invalid plan ID"

type Handler struct {
	service planModels.Service
}

func NewHandler(service planModels.Service) *Handler {
	return &Handler{service: service}
}

func (h *Handler) CreatePlan(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	input, err := plans.ParseCreatePlanRequest(r)
	if err != nil {
		httpresponse.WriteError(w, messages.ErrorMessage(err.Error()), http.StatusBadRequest)
		return
	}

	p := &planModels.Plan{
		Code:           input.Code,
		Name:           input.Name,
		Description:    input.Description,
		Price:          input.Price,
		Currency:       input.Currency,
		Features:       input.Features,
		TrialDays:      input.TrialDays,
		MaxUsers:       input.MaxUsers,
		StorageLimitGB: input.StorageLimitGB,
		APILimit:       input.APILimit,
		IsActive:       input.IsActive,
		IsPopular:      input.IsPopular,
		SortOrder:      input.SortOrder,
		AuditFields: auditModels.AuditFields{
			CreatedBy: input.CreatedBy,
		},
	}

	created, err := h.service.CreatePlan(r.Context(), p)
	if err != nil {
		httpresponse.WriteError(w, messages.ExceptionMessage, http.StatusInternalServerError)
		return
	}

	httpresponse.WriteSuccess(w, messages.DataCreatedSuccessful, plans.MapCreatePlanResponse(created), http.StatusCreated)
}

func (h *Handler) GetPlan(w http.ResponseWriter, r *http.Request) {
	idStr := mux.Vars(r)["id"]
	if idStr == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		httpresponse.WriteError(w, errInvalidPlanID, http.StatusBadRequest)
		return
	}

	p, err := h.service.GetPlan(r.Context(), id)
	if err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}
	if p == nil {
		httpresponse.WriteError(w, messages.NoDataFound, http.StatusNotFound)
		return
	}

	httpresponse.WriteSuccess(w, messages.DataRetrieved, plans.MapPlanToResponse(p), http.StatusOK)
}

func (h *Handler) ListPlans(w http.ResponseWriter, r *http.Request) {
	planList, err := h.service.ListPlans(r.Context())
	if err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}

	httpresponse.WriteSuccess(w, messages.DataRetrieved, plans.MapPlansToListResponse(planList), http.StatusOK)
}

func (h *Handler) PartialUpdatePlan(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPatch {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	idStr := mux.Vars(r)["id"]
	if idStr == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		httpresponse.WriteError(w, errInvalidPlanID, http.StatusBadRequest)
		return
	}

	updates, err := plans.ParsePartialUpdatePlanRequest(r)
	if err != nil {
		httpresponse.WriteError(w, messages.ErrorMessage(err.Error()), http.StatusBadRequest)
		return
	}

	updated, err := h.service.PartialUpdatePlan(r.Context(), id, updates)
	if err != nil {
		switch {
		case errors.Is(err, messages.NoDataFound), strings.Contains(err.Error(), messages.NoDataFound.Error()):
			httpresponse.WriteError(w, messages.NoDataFound, http.StatusNotFound)
		default:
			httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		}
		return
	}

	httpresponse.WriteSuccess(w, messages.DataUpdatedSuccessful, plans.MapUpdatePlanResponse(updated), http.StatusOK)
}

func (h *Handler) DeletePlan(w http.ResponseWriter, r *http.Request) {
	idStr := mux.Vars(r)["id"]
	if idStr == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		httpresponse.WriteError(w, errInvalidPlanID, http.StatusBadRequest)
		return
	}

	if err := h.service.DeletePlan(r.Context(), id); err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}

	httpresponse.WriteSuccess(w, messages.DeleteSuccessful, nil, http.StatusOK)
}
