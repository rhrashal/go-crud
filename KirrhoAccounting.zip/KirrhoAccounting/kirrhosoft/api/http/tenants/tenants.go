package tenants

import (
	tenantHandlers "KirrhoAccounting/kirrhosoft/handlers/tenants"
	tenantModels "KirrhoAccounting/kirrhosoft/models/tenants"
	auditModels "KirrhoAccounting/pkg/basemodel"
	"KirrhoAccounting/pkg/httpresponse"
	"KirrhoAccounting/pkg/messages"
	"net/http"
	"strconv"
	"strings"

	"github.com/gorilla/mux"
)

const errInvalidTenantID = "invalid tenant ID"

type Handler struct {
	service tenantModels.Service
}

func NewHandler(service tenantModels.Service) *Handler {
	return &Handler{service: service}
}

func (h *Handler) CreateTenant(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	input, err := tenantHandlers.ParseCreateTenantRequest(r)
	if err != nil {
		httpresponse.WriteError(w, messages.ErrorMessage(err.Error()), http.StatusBadRequest)
		return
	}

	timezone := input.Timezone
	if strings.TrimSpace(timezone) == "" {
		timezone = "UTC"
	}

	t := &tenantModels.Tenant{
		Name:                input.Name,
		Domain:              input.Domain,
		Email:               input.Email,
		Phone:               input.Phone,
		Country:             input.Country,
		Industry:            input.Industry,
		PlanID:              input.PlanID,
		SchemaName:          input.SchemaName,
		Timezone:            timezone,
		IsActive:            input.IsActive,
		OnboardingCompleted: input.OnboardingCompleted,
		Metadata:            input.Metadata,
		AuditFields: auditModels.AuditFields{
			CreatedBy: input.CreatedBy,
		},
	}

	created, err := h.service.CreateTenant(r.Context(), t)
	if err != nil {
		httpresponse.WriteError(w, messages.ExceptionMessage, http.StatusInternalServerError)
		return
	}

	httpresponse.WriteSuccess(w, messages.DataCreatedSuccessful, tenantHandlers.MapTenantToResponse(created), http.StatusCreated)
}

func (h *Handler) GetTenant(w http.ResponseWriter, r *http.Request) {
	idStr := mux.Vars(r)["id"]
	if idStr == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil || id <= 0 {
		httpresponse.WriteError(w, errInvalidTenantID, http.StatusBadRequest)
		return
	}

	t, err := h.service.GetTenant(r.Context(), id)
	if err != nil {
		httpresponse.WriteServiceError(w, err)
		return
	}

	httpresponse.WriteSuccess(w, messages.DataRetrieved, t, http.StatusOK)
}

func (h *Handler) ListTenants(w http.ResponseWriter, r *http.Request) {
	tenantList, err := h.service.ListTenants(r.Context())
	if err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}

	httpresponse.WriteSuccess(w, messages.DataRetrieved, tenantHandlers.MapTenantsToListResponse(tenantList), http.StatusOK)
}

func (h *Handler) PartialUpdateTenant(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPatch {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	idStr := mux.Vars(r)["id"]
	if idStr == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil || id <= 0 {
		httpresponse.WriteError(w, errInvalidTenantID, http.StatusBadRequest)
		return
	}

	updates, err := tenantHandlers.ParsePartialUpdateTenantRequest(r)
	if err != nil {
		httpresponse.WriteError(w, messages.ErrorMessage(err.Error()), http.StatusBadRequest)
		return
	}

	updated, err := h.service.PartialUpdateTenant(r.Context(), id, updates)
	if err != nil {
		httpresponse.WriteServiceError(w, err)
		return
	}

	httpresponse.WriteSuccess(w, messages.DataUpdatedSuccessful, tenantHandlers.MapTenantToResponse(updated), http.StatusOK)
}

func (h *Handler) DeleteTenant(w http.ResponseWriter, r *http.Request) {
	idStr := mux.Vars(r)["id"]
	if idStr == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil || id <= 0 {
		httpresponse.WriteError(w, errInvalidTenantID, http.StatusBadRequest)
		return
	}

	if err := h.service.DeleteTenant(r.Context(), id); err != nil {
		httpresponse.WriteServiceError(w, err)
		return
	}

	httpresponse.WriteSuccess(w, messages.DeleteSuccessful, nil, http.StatusOK)
}
