package subscriptions

import (
	"KirrhoAccounting/kirrhosoft/handlers/subscriptions"
	subModels "KirrhoAccounting/kirrhosoft/models/subscriptions"
	subAdapter "KirrhoAccounting/kirrhosoft/pkg/adapter/subscriptions"
	auditModels "KirrhoAccounting/pkg/basemodel"
	"KirrhoAccounting/pkg/httpresponse"
	"KirrhoAccounting/pkg/messages"
	"errors"
	"net/http"
	"strings"
	"time"

	"github.com/gorilla/mux"
)

type Handler struct {
	service *subAdapter.HTTPSubscriptionsAdapter
}

func NewHandler(service *subAdapter.HTTPSubscriptionsAdapter) *Handler {
	return &Handler{service: service}
}

func (h *Handler) CreateSubscription(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	input, err := subscriptions.ParseCreateSubscriptionRequest(r)
	if err != nil {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	var startDate time.Time
	if input.StartDate != nil {
		startDate = *input.StartDate
	} else {
		startDate = time.Now().UTC()
	}

	s := &subModels.Subscription{
		TenantID:  input.TenantID,
		PlanID:    input.PlanID,
		StartDate: startDate,
		EndDate:   input.EndDate,
		Status:    input.Status,
		AuditFields: auditModels.AuditFields{
			CreatedBy: input.CreatedBy,
		},
	}

	created, err := h.service.CreateSubscription(r.Context(), s)
	if err != nil {
		httpresponse.WriteError(w, messages.ExceptionMessage, http.StatusInternalServerError)
		return
	}

	httpresponse.WriteSuccess(w, messages.DataCreatedSuccessful, subscriptions.MapSubscriptionToResponse(created, time.RFC3339), http.StatusCreated)
}

func (h *Handler) GetSubscription(w http.ResponseWriter, r *http.Request) {
	id := mux.Vars(r)["id"]
	if id == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	sub, err := h.service.GetSubscription(r.Context(), id)
	if err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}
	if sub == nil {
		httpresponse.WriteError(w, messages.NoDataFound, http.StatusNotFound)
		return
	}
	httpresponse.WriteSuccess(
		w,
		messages.DataRetrieved,
		subscriptions.MapSubscriptionData(sub, time.RFC3339),
		http.StatusOK,
	)
}

func (h *Handler) ListSubscriptions(w http.ResponseWriter, r *http.Request) {
	subList, err := h.service.ListSubscriptions(r.Context())
	if err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}

	httpresponse.WriteSuccess(
		w,
		messages.DataRetrieved,
		subscriptions.MapSubscriptionData(subList, time.RFC3339),
		http.StatusOK,
	)
}

func (h *Handler) PartialUpdateSubscription(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPatch {
		httpresponse.WriteError(w, messages.RequestFailed, http.StatusMethodNotAllowed)
		return
	}

	id := mux.Vars(r)["id"]
	if id == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	updates, err := subscriptions.ParsePartialUpdateSubscriptionRequest(r)
	if err != nil {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	updated, err := h.service.PartialUpdateSubscription(r.Context(), id, updates)
	if err != nil {
		switch {
		case errors.Is(err, messages.NoDataFound), strings.Contains(err.Error(), messages.NoDataFound.Error()):
			httpresponse.WriteError(w, messages.NoDataFound, http.StatusNotFound)
		default:
			httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		}
		return
	}

	httpresponse.WriteSuccess(w, messages.DataUpdatedSuccessful, subscriptions.MapSubscriptionData(updated, time.RFC3339), http.StatusOK)
}

func (h *Handler) DeleteSubscription(w http.ResponseWriter, r *http.Request) {
	id := mux.Vars(r)["id"]
	if id == "" {
		httpresponse.WriteError(w, messages.InvalidData, http.StatusBadRequest)
		return
	}

	if err := h.service.DeleteSubscription(r.Context(), id); err != nil {
		httpresponse.WriteError(w, messages.DatabaseError, http.StatusInternalServerError)
		return
	}

	httpresponse.WriteSuccess(w, messages.DeleteSuccessful, nil, http.StatusOK)
}
