package di

import (
	"KirrhoAccounting/database"
	"KirrhoAccounting/kirrhosoft/pkg/adapter/healthcheck"
	"KirrhoAccounting/kirrhosoft/pkg/adapter/plans"
	"KirrhoAccounting/kirrhosoft/pkg/adapter/superuser"
	"database/sql"
	"log"
	"os"

	"github.com/joho/godotenv"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"

	// --- Superuser ---
	superusergrpc "KirrhoAccounting/kirrhosoft/api/grpc/superuser"
	superuserhttp "KirrhoAccounting/kirrhosoft/api/http/superuser"
	superuserpb "KirrhoAccounting/kirrhosoft/pb/superuser"
	superuserrepo "KirrhoAccounting/kirrhosoft/repositories/superuser"
	superuserservice "KirrhoAccounting/kirrhosoft/services/superuser"

	// --- Plans ---
	plansgrpc "KirrhoAccounting/kirrhosoft/api/grpc/plans"
	planshttp "KirrhoAccounting/kirrhosoft/api/http/plans"
	planspb "KirrhoAccounting/kirrhosoft/pb/plans"
	plansrepo "KirrhoAccounting/kirrhosoft/repositories/plans"
	plansservice "KirrhoAccounting/kirrhosoft/services/plans"

	// --- Tenants (HTTP only) ---
	tenantshttp "KirrhoAccounting/kirrhosoft/api/http/tenants"
	tenantrepo "KirrhoAccounting/kirrhosoft/repositories/tenants"
	tenantservice "KirrhoAccounting/kirrhosoft/services/tenants"

	// --- Settings (HTTP only) ---
	settingshttp "KirrhoAccounting/kirrhosoft/api/http/settings"
	settingrepo "KirrhoAccounting/kirrhosoft/repositories/settings"
	settingservice "KirrhoAccounting/kirrhosoft/services/settings"
	// --- Subscriptions (HTTP only) ---
	subshttp "KirrhoAccounting/kirrhosoft/api/http/subscriptions"
	subsadapter "KirrhoAccounting/kirrhosoft/pkg/adapter/subscriptions"
	subsrepo "KirrhoAccounting/kirrhosoft/repositories/subscriptions"
	subsservice "KirrhoAccounting/kirrhosoft/services/subscriptions"

	// --- HealthCheck ---
	healthgrpc "KirrhoAccounting/kirrhosoft/api/grpc/healthcheck"
	healthhttp "KirrhoAccounting/kirrhosoft/api/http/healthcheck"
	healthpb "KirrhoAccounting/kirrhosoft/pb/healthcheck"
	healthservice "KirrhoAccounting/kirrhosoft/services/healthcheck"

	// --- Users (REQUIRED for tenant seeding) ---
	userrepo "KirrhoAccounting/users/repositories/users"
)

type Container struct {
	SuperuserGRPCServer  superuserpb.SuperUserServiceServer
	SuperuserHTTPHandler *superuserhttp.Handler

	PlansGRPCServer  planspb.PlanServiceServer
	PlansHTTPHandler *planshttp.Handler

	SettingsHTTPHandler      *settingshttp.Handler
	TenantsHTTPHandler       *tenantshttp.Handler
	SubscriptionsHTTPHandler *subshttp.Handler

	HealthGRPCServer  healthpb.SystemHealthServer
	HealthHTTPHandler *healthhttp.Handler

	DB *sql.DB
}

func InitContainer() (*Container, error) {
	if err := godotenv.Load(); err != nil {
		log.Fatalf("Failed to load .env file: %v", err)
		return nil, err
	}

	db, err := database.GetPostgresDB()
	if err != nil {
		log.Fatalf("Failed to connect to DB: %v", err)
		return nil, err
	}

	// --- Superuser wiring ---
	superuserRepo := superuserrepo.New(db)
	superuserService := superuserservice.New(superuserRepo)
	superuserGRPCServer := superusergrpc.New(superuserService)

	// --- Plans wiring ---
	plansRepo := plansrepo.NewPlansRepo(db)
	plansService := plansservice.NewPlanService(plansRepo)
	plansGRPCServer := plansgrpc.New(plansService)

	tenantsRepo := tenantrepo.NewTenantsRepo(db)
	tenantsService := tenantservice.NewTenantService(tenantsRepo)
	tenantsHTTPHandler := tenantshttp.NewHandler(tenantsService)

	settingsRepo := settingrepo.NewSettingsRepo(db)
	settingsService := settingservice.NewSettingService(settingsRepo)
	settingsHTTPHandler := settingshttp.NewHandler(settingsService)

	subsRepo := subsrepo.NewSubscriptionsRepo(db)
	userRepo := userrepo.NewUsersRepo(db)
	subsService := subsservice.NewSubscriptionService(db, subsRepo, tenantsRepo, userRepo)
	subsAdapter := subsadapter.NewHTTPSubscriptionsAdapter(subsService)
	subsHTTPHandler := subshttp.NewHandler(subsAdapter)

	// --- Health check wiring (no repo needed) ---
	healthService := healthservice.NewService()
	healthGRPCServer := healthgrpc.NewGRPCServer(healthService)

	// --- gRPC Client connections for Adapters ---
	port := os.Getenv("GRPC_PORT")
	if port == "" {
		port = "50051"
	}

	conn, err := grpc.Dial("localhost:"+port, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalf("Failed to dial gRPC server: %v", err)
		return nil, err
	}

	// --- Superuser client and HTTP handler ---
	superuserClient := superuserpb.NewSuperUserServiceClient(conn)
	superuserGRPCAdapter := superuser.NewGRPCServiceAdapter(superuserClient)
	superuserHTTPHandler := superuserhttp.NewHandler(superuserGRPCAdapter)

	// --- Plan client and HTTP handler ---
	plansClient := planspb.NewPlanServiceClient(conn)
	plansGRPCAdapter := plans.NewGRPCServiceAdapter(plansClient)
	plansHTTPHandler := planshttp.NewHandler(plansGRPCAdapter)

	// --- Health check client and HTTP handler ---
	healthClient := healthpb.NewSystemHealthClient(conn)
	healthAdapter := healthcheck.NewGRPCHealthAdapter(healthClient)
	healthHTTPHandler := healthhttp.NewHandler(healthAdapter)

	return &Container{
		SuperuserGRPCServer:  superuserGRPCServer,
		SuperuserHTTPHandler: superuserHTTPHandler,

		PlansGRPCServer:  plansGRPCServer,
		PlansHTTPHandler: plansHTTPHandler,

		SettingsHTTPHandler: settingsHTTPHandler,

		TenantsHTTPHandler:       tenantsHTTPHandler,
		SubscriptionsHTTPHandler: subsHTTPHandler,

		HealthGRPCServer:  healthGRPCServer,
		HealthHTTPHandler: healthHTTPHandler,

		DB: db,
	}, nil
}
